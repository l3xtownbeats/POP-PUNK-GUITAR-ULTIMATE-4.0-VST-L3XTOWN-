# Структура библиотеки сэмплов (создаёт скрипт)

PPGU_SampleLibrary/
├── 01_Acoustic_Raw/        акустика необработанная: ноты, арпеджио, переборы
├── 02_DI_Clean/            прямой сигнал электрогитары — красится пресетами
├── 03_Distortion_PowerChords/
├── 04_PalmMute/            8th и 16th, по velocity
├── 05_Crunch_Riffs/
├── 06_Octaves/             октавные ходы blink-стиля
├── 07_Melody_Leads/        бенды, вибрато
├── 08_Release_Noises/      шумы струн и пальцев — без них звук мёртвый
├── 09_Loops_PPM/           palm-muted лупы с BPM-разметкой
├── 10_MIDI_Patterns/       CC0 MIDI под паттерн-движок
├── LICENSES.md             собирается скриптом автоматически
└── build_report.txt
