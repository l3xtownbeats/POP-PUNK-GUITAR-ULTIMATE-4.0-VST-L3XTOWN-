# SOURCES — легальные источники сэмплов поп-панк гитары

## A. Полноценные инструменты SFZ (категории: DI, clean, crunch)
| Источник | URL | Лицензия | Что внутри |
|---|---|---|---|
| Karoryfer Emilyguitar | github.com/sfzinstruments/karoryfer.emilyguitar | CC0-1.0, royalty-free | Power/minor/major barre chords с кейсвитчами, 4 velocity-слоя, 3 round-robin, release-сэмплы, шумы струн — готовая база под струм-движок |
| Karoryfer Black and Green Guitars | github.com/sfzinstruments/karoryfer.black-and-green-guitars | CC0-1.0 | Две халлоубоди-электрогитары (Gretsch Anniversary, Hofner Club), SFZ, ~500 МБ |
| FreePats FSBS direct (Fender) | github.com/freepats/e-guitar-FSBS-direct | CC0 | Прямая запись DI: clean / distorted / direct — сырой сигнал под наши пресеты |
| FreePats (все) | github.com/freepats | CC0 | Три варианта Fender-гитары |
| lotkey baritone Strat | github.com/lotkey/free-sample-libraries-sfz | лицензия в репо — проверить перед коммерцией | Humbucker + Split Coil DI, palm mute размаплен по velocity 0-32/33-63 |

## B. Freesound-паки (через API, токен бесплатный: freesound.org/apiv2/apply)
| Пак | Содержимое | Лицензия |
|---|---|---|
| Chem #1995 | Дисторшн ESP EC-300, 24bit/96kHz: power chords long/short + palm mute 2 варианта, ноты E/A/D | CC (у каждого звука своя — скрипт логирует) |
| Ax_Grinder #14939 | Drop D power chords D2-F3, open + PMute (Jackson Warrior -> Line6 POD XT) | CC |
| Поиск в API: "palm muted guitar", "pop punk guitar", "distorted guitar one shot" | Десятки одиночных сэмплов и паков | CC-фильтр в API |

## C. Лупы и риффы (категории: loops, riffs)
| Источник | Что | Лицензия |
|---|---|---|
| Looperman: /loops/tags/palm-muted | Сотни PM-лупов во всех тональностях | Royalty-free (условия Looperman) |
| Looperman: /loops/tags/punk-guitar | 411 панк/поп-панк риффов | Royalty-free |
| Looperman: /loops/tags/distorted-guitar | 212 дисторшн-риффов | Royalty-free |
| Sample Focus: Pop Punk type Guitar | Рифф в стиле Downfall, 160bpm Eb major; плюс Pop Punk Guitar Riff Crunch | Royalty-free Standard |
| Sample Focus: Drop C Metal Guitar Palm Mute | PM Drop C | Royalty-free Standard |

## D. MIDI-паттерны для паттерн-движка
| Источник | Что | Лицензия |
|---|---|---|
| Selekt Audio: selektaudio.com/free-midi/guitar | MIDI-транскрипции реальных исполнений: hammer-on, slide, palm mute, бенды как pitch-bend | CC0 / CC-BY с сертификатами происхождения |

## E. Аккаунтные (royalty-free, скачать вручную)
| Источник | Что | Лицензия |
|---|---|---|
| Splice: Mike Naran — Pop Punk Riffs (Signal Path) | 65 сэмплов ровно поп-панк: риффы, аккорды, октавы, clean+distorted | Royalty-free (подписка) |
| Splice: Rear View Mirror 50 Guitar Pack (Traktrain) | 59 живых сэмплов: SPLSH_guitar_palm_muted_power_chords_BPM_153_G и др. | Royalty-free (подписка) |
| LANDR Samples: Pop Punk Guitar LIVE | 105 лупов и one-shots в стиле Willow/MGK/Paramore | Royalty-free (подписка) |

## F. Флэнжер/хорус/кранч — НЕ сэмплы
Эти стилистики получаются DSP-обработкой сухих слоёв (цепочки drive/eq/comp/mod уже
зашиты в пресеты Tone_Palettes.json). Так устроен и Sunburst: записано чисто, покрашено пресетом.

## G. Свои записи — главный план
README_SAMPLING.md: 3 канала (BR/NK/MIC), 22 артикуляции, velocity 55/75/95/120, L/R-пары для дабл-трека.
