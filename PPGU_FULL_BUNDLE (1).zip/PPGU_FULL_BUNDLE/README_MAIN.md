# PPGU FULL BUNDLE — всё для плагина в одном пакете

## Состав
- Presets/ — 6 банков, 99 пресетов:
    Tone_Palettes.json (25 палитр с реальными цепочками эпохи),
    Bands2000_2005_Presets.json (20 групп, 44 пресета),
    Jerry_Finn_Presets.json (12), Travis_Barker_Presets.json (14),
    Section_Presets.json (28) + Section_Technique_Map.json (интро/куплет/припев/бридж/соло/кода).
- Samples/ — SOURCES.md (каталог легальных источников с прямыми ссылками, 10 категорий:
  акустика, DI, дисторшн, crunch, palm mute, октавы, лиды, шумы, лупы, MIDI)
  и FOLDER_STRUCTURE.md.
- Tools/ — ppgu_build_library.py (скрипт скачивания+упаковки), GPT_PROMPT.txt
  (промт «скачать всё без вопросов»), ONE_CLICK.md.
- Docs/ — свод анализов движков (Sunburst, Nexus 5), сравнение энергозатрат, ревью ThemeManager.
- LICENSES/ — правовая рамка.

## Быстрый старт
1. Tools/ONE_CLICK.md — собрать библиотеку одной командой или через AI-агента.
2. Presets/ — банки, которые движок читает напрямую (tone_ref, паттерн, velocity, дабл-трек).
3. Свои записи — по плану Samples/README_SAMPLING.md (BR/NK/MIC, 22 артикуляции).
