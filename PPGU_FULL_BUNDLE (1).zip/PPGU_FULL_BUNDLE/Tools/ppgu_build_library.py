#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PPGU Sample Library Builder — скачивает легальные сэмплы из открытых источников
и собирает PPGU_SampleLibrary.zip за один запуск.

Запуск:
  python3 ppgu_build_library.py                      # только GitHub-источники (без токена)
  python3 ppgu_build_library.py --token FS_API_KEY   # + паки Freesound
"""
import argparse, json, os, re, shutil, sys, urllib.request, zipfile, io

GITHUB_SOURCES = [
    ("karoryfer.emilyguitar", "https://github.com/sfzinstruments/karoryfer.emilyguitar/archive/refs/heads/master.zip", "02_DI_Clean"),
    ("karoryfer.black-green", "https://github.com/sfzinstruments/karoryfer.black-and-green-guitars/archive/refs/heads/master.zip", "02_DI_Clean"),
    ("freepats.fsbs.direct",  "https://github.com/freepats/e-guitar-FSBS-direct/archive/refs/heads/master.zip", "02_DI_Clean"),
    ("lotkey.sfz-libs",       "https://github.com/lotkey/free-sample-libraries-sfz/archive/refs/heads/master.zip", "02_DI_Clean"),
    ("sfz.mappings",          "https://github.com/sfzinstruments/mappings/archive/refs/heads/master.zip", "_SFZ_MAPPINGS"),
]

FREESOUND_PACKS = [(1995, "03_Distortion_PowerChords"), (14939, "04_PalmMute")]

CLASSIFY_RULES = [
    (re.compile(r"pmute|palm|pm_?chord", re.I), "04_PalmMute"),
    (re.compile(r"power.?chord|pchord", re.I), "03_Distortion_PowerChords"),
    (re.compile(r"octave", re.I), "06_Octaves"),
    (re.compile(r"bend|vibrato|lead|solo", re.I), "07_Melody_Leads"),
    (re.compile(r"release|noise|string", re.I), "08_Release_Noises"),
    (re.compile(r"acoustic", re.I), "01_Acoustic_Raw"),
    (re.compile(r"distort|crunch|grit", re.I), "05_Crunch_Riffs"),
    (re.compile(r"\.mid$", re.I), "10_MIDI_Patterns"),
]

CATEGORIES = ["01_Acoustic_Raw","02_DI_Clean","03_Distortion_PowerChords","04_PalmMute",
              "05_Crunch_Riffs","06_Octaves","07_Melody_Leads","08_Release_Noises",
              "09_Loops_PPM","10_MIDI_Patterns"]

def fetch(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "PPGU/1.0"})
    return urllib.request.urlopen(req, timeout=120).read()

def classify(name):
    for rx, cat in CLASSIFY_RULES:
        if rx.search(name):
            return cat
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--token", default=os.environ.get("FREESOUND_TOKEN", ""))
    ap.add_argument("--out", default="PPGU_SampleLibrary")
    args = ap.parse_args()

    if os.path.isdir(args.out):
        shutil.rmtree(args.out)
    for c in CATEGORIES:
        os.makedirs(f"{args.out}/{c}", exist_ok=True)
    licenses, report = [], []

    for name, url, cat in GITHUB_SOURCES:
        print(f"-> {name}")
        try:
            blob = fetch(url)
            with zipfile.ZipFile(io.BytesIO(blob)) as z:
                z.extractall(f"{args.out}/_{name}")
            report.append(f"[OK] {name}")
            licenses.append(f"{name}: см. LICENSE внутри архива источника ({url})")
        except Exception as e:
            report.append(f"[FAIL] {name}: {e}")

    if args.token:
        for pid, cat in FREESOUND_PACKS:
            print(f"-> freesound pack {pid}")
            try:
                meta = json.loads(fetch(
                    f"https://freesound.org/apiv2/packs/{pid}/?format=json&token={args.token}").decode())
                for s in meta.get("results", []):
                    snd = json.loads(fetch(
                        f"https://freesound.org/apiv2/sounds/{s['id']}/?format=json&token={args.token}").decode())
                    fname = s["name"]
                    url = snd.get("download") or snd["previews"]["preview-hq-mp3"]
                    blob = fetch(url)
                    dest_cat = classify(fname) or cat
                    ext = os.path.splitext(fname)[1] or ".wav"
                    with open(f"{args.out}/{dest_cat}/{fname}{ext}", "wb") as f:
                        f.write(blob)
                    licenses.append(f"{fname} (id {s['id']}): {snd.get('license','unknown')}")
                report.append(f"[OK] freesound pack {pid}")
            except Exception as e:
                report.append(f"[FAIL] freesound {pid}: {e}")
    else:
        report.append("[SKIP] Freesound: нет токена (бесплатный ключ: https://freesound.org/apiv2/apply)")

    with open(f"{args.out}/LICENSES.md", "w", encoding="utf-8") as f:
        f.write("# Лицензии скачанных сэмплов\n\n" + "\n".join("- " + l for l in licenses))
    with open(f"{args.out}/build_report.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(report))

    if os.path.exists(f"{args.out}.zip"):
        os.remove(f"{args.out}.zip")
    with zipfile.ZipFile(f"{args.out}.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(args.out):
            for fn in files:
                z.write(os.path.join(root, fn))
    print("\n".join(report))
    print(f"\nГотово: {args.out}.zip")

if __name__ == "__main__":
    main()
