# Запуск в один клик

## Вариант 1 — у себя (одна команда)
1. Python 3.8+ (есть на любой ОС).
2. В папке Tools: python3 ppgu_build_library.py
   (для Freesound-паков: ключ бесплатно на freesound.org/apiv2/apply, добавить --token КЛЮЧ)
3. На выходе PPGU_SampleLibrary.zip — готовая библиотека.

## Вариант 2 — через AI-агента (без вопросов)
1. Открой чат с агентом, умеющим исполнять код.
2. Отправь содержимое GPT_PROMPT.txt + файл ppgu_build_library.py.
3. Агент выполнит всё сам и отдаст архив.

## На выходе
PPGU_SampleLibrary/ — 10 категорий + LICENSES.md + build_report.txt,
упаковано в PPGU_SampleLibrary.zip. Объём 1.5-4 ГБ в зависимости от паков.
