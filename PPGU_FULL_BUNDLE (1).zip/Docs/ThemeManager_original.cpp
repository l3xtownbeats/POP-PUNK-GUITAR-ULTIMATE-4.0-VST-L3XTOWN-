/*
    ThemeManager.cpp
    POP PUNK GUITAR ULTIMATE 5.0
    LookAndFeel, рисующий все элементы по палитре темы:
    ручки, кнопки, слайдеры, LED, клавиатура, списки пресетов.

    Интеграция:
      1. Создать ppgu::PpguLookAndFeel lookAndFeel;
      2. lookAndFeel.setThemeManager(&themeManager);
      3. juce::LookAndFeel::setDefaultLookAndFeel(&lookAndFeel);
      4. themeManager.scanThemes(themesRoot);
      5. themeManager.applyTheme(savedThemeIdFromAPVTS);
*/

#include "ThemeManager.h"

namespace ppgu
{

//==============================================================================
// LookAndFeel: все цвета берутся ТОЛЬКО из текущей темы.
class PpguLookAndFeel : public juce::LookAndFeel_V4
{
public:
    void setThemeManager (ThemeManager* tm) { manager = tm; }

    Theme* theme() const
    {
        return manager ? manager->current() : nullptr;
    }

    juce::Colour col (const juce::String& key, juce::Colour fallback) const
    {
        auto* t = theme();
        return t ? t->palette.get (key, fallback) : fallback;
    }

    // ---- Ручки (круглые) -------------------------------------------------
    void drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h,
                           float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                           juce::Slider&) override
    {
        auto box = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (2.0f);
        auto radius = juce::jmin (box.getWidth(), box.getHeight()) / 2.0f;
        auto centre = box.getCentre();
        auto angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);

        // лицо ручки
        g.setColour (col ("knob.face", juce::Colours::darkgrey));
        g.fillEllipse (juce::Rectangle<float> (radius * 2.0f, radius * 2.0f).withCentre (centre));

        // акцентное кольцо
        juce::Path arc;
        arc.addCentredArc (centre.x, centre.y, radius, radius, 0.0f,
                           rotaryStartAngle, angle, true);
        g.setColour (col ("knob.ring", juce::Colours::pink));
        g.strokePath (arc, juce::PathStrokeType (3.0f));

        // указатель
        juce::Line<float> pointer (centre.x, centre.y,
                                   centre.x + std::cos (angle - juce::MathConstants<float>::halfPi) * radius * 0.8f,
                                   centre.y + std::sin (angle - juce::MathConstants<float>::halfPi) * radius * 0.8f);
        g.setColour (col ("knob.pointer", juce::Colours::white));
        g.drawLine (pointer, 2.0f);
    }

    // ---- Кнопки ----------------------------------------------------------
    void drawButtonBackground (juce::Graphics& g, juce::Button& button,
                               const juce::Colour&, bool highlighted, bool down) override
    {
        auto bounds = button.getLocalBounds().toFloat().reduced (1.0f);
        bool active = button.getToggleState();

        auto bg = active ? col ("button.active", juce::Colours::pink)
                         : (down || highlighted ? col ("button.hover", juce::Colours::darkgrey)
                                                : col ("button.normal", juce::Colours::grey));
        g.setColour (bg);
        g.fillRoundedRectangle (bounds, 6.0f);       // скругление, как в референсе
        g.setColour (col ("panel.border", juce::Colours::black));
        g.drawRoundedRectangle (bounds, 6.0f, 1.0f);
    }

    juce::Font getTextButtonFont (juce::TextButton&, int height) override
    {
        // жирный гротеск для заголовков кнопок
        return juce::Font (juce::FontOptions (juce::jmin (height * 0.55f, 20.0f), juce::Font::bold));
    }

    // ---- Слайдеры (вертикальные, панель PITCH/MOD, уровни) ---------------
    void drawLinearSlider (juce::Graphics& g, int x, int y, int w, int h,
                           float sliderPos, float, float,
                           const juce::Slider::SliderStyle style, juce::Slider&) override
    {
        if (style == juce::Slider::LinearVertical)
        {
            auto track = juce::Rectangle<float> ((float) x + w / 2.0f - 3.0f, (float) y, 6.0f, (float) h);
            g.setColour (col ("slider.track", juce::Colours::darkgrey));
            g.fillRoundedRectangle (track, 3.0f);
            auto fill = track.withBottom (sliderPos);
            g.setColour (col ("slider.fill", juce::Colours::pink));
            g.fillRoundedRectangle (fill, 3.0f);
        }
    }

    // ---- Клавиатура (нижняя панель) --------------------------------------
    void drawWhiteKey (juce::Graphics& g, int x, int y, int w, int h, bool down) override
    {
        auto key = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h);
        g.setColour (down ? col ("keyboard.active", juce::Colours::pink)
                          : col ("keyboard.white", juce::Colours::white));
        g.fillRect (key);
        g.setColour (col ("panel.border", juce::Colours::black));
        g.drawRect (key, 1.0f);
    }

    void drawBlackKey (juce::Graphics& g, int x, int y, int w, int h, bool down) override
    {
        auto key = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h);
        g.setColour (down ? col ("keyboard.active", juce::Colours::pink)
                          : col ("keyboard.black", juce::Colours::black));
        g.fillRect (key);
    }

private:
    ThemeManager* manager = nullptr;
};

//==============================================================================
// Хранение выбранной темы в состоянии плагина (APVTS), чтобы тема
// восстанавливалась вместе с проектом DAW — как в Nexus.
class ThemeSettings
{
public:
    static void attach (juce::AudioProcessorValueTreeState& apvts)
    {
        // создаётся один раз в конструкторе Processor:
        // apvts.state.addListener(...);
        themeId = apvts.state.getOrCreateChildWithName ("ui").getProperty ("themeId", "neon_riot").toString();
    }

    static void save (juce::AudioProcessorValueTreeState& apvts, const juce::String& id)
    {
        auto ui = apvts.state.getOrCreateChildWithName ("ui");
        ui.setProperty ("themeId", id, nullptr);
        themeId = id;
    }

    inline static juce::String themeId = "neon_riot";
};

} // namespace ppgu
