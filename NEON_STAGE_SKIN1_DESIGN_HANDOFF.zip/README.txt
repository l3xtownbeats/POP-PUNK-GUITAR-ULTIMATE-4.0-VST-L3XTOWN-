NEON STAGE DEFAULT — SKIN-1
PPGU REV.18 visual design handoff

This archive intentionally contains only two visible UI elements:
1. Main plugin console concept.
2. FX Edit concept.

IMPORTANT
These PNGs are visual references, not a compiled JUCE theme and not evidence
that the depicted controls are implemented. The original concept artwork may
contain illustrative or unapproved controls. Production conversion is gated
by the current Info.txt / Part B, authoritative REV.18 UI inventory,
control-ID map, and the repository's canonical theme manifest schema.

Canonical identity:
SKIN-1 = NEON STAGE DEFAULT = skin-053 / Skin_053

Do not add new APVTS IDs, do not invent controls, do not create separate
SOUND FORGE / SIGNAL FORGE themes, and do not present unimplemented features
as active. Keep the visual default in Minimalism mode; Effects remains an
explicit optional mode.
