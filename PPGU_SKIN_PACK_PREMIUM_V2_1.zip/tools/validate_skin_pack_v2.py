#!/usr/bin/env python3
"""PPGU Skin Pack validator V2.1 (локальный; репозиторный tools/validate_skin_pack.py остаётся авторитетным).
G1 контрасты (WCAG), G2 наличие 27 draft control IDs + sync_selector, G3 PNG-декод и точные размеры (урок CRC runs #954-962), G4 непрерывная нумерация."""
import json, os, sys
def lum(c):
    c = c/255.0
    l = c/12.92 if c <= 0.04045 else ((c+0.055)/1.055)**2.4
    return l
def L(h):
    h = h.lstrip("#"); rgb = [int(h[i:i+2],16) for i in (0,2,4)]
    return 0.2126*lum(rgb[0]) + 0.7152*lum(rgb[1]) + 0.0722*lum(rgb[2])
def ratio(a,b):
    la, lb = L(a), L(b); hi, lo = max(la,lb), min(la,lb)
    return (hi+0.05)/(lo+0.05)
TH = {"text_primary":("window_bg",10),"text_secondary":("window_bg",7),"text_disabled":("window_bg",4.5),"lcd_text":("lcd_bg",8),"accent":("panel",3)}
REQUIRED = 27 + 1  # 27 draft IDs + sync_selector
def main(root):
    errs = []
    skins = sorted(d for d in os.listdir(os.path.join(root,"Skins")) if d.startswith("Skin_"))
    prev = None
    for s in skins:
        idx = int(s.split("_")[1])
        if prev is not None and idx != prev + 1: errs.append(f"G4: разрыв нумерации {prev}->{idx}")
        prev = idx
        p = os.path.join(root,"Skins",s)
        try: t = json.load(open(os.path.join(p,"theme.json")))
        except Exception as e: errs.append(f"{s}: theme.json не читается: {e}"); continue
        if len(t.get("tokens",{})) != 21: errs.append(f"{s}: tokens != 21")
        for tok,(bgt,thr) in TH.items():
            r = ratio(t["tokens"][tok], t["tokens"][bgt])
            if r < thr: errs.append(f"G1 {s}: {tok} {r:.2f} < {thr}")
        n = len(t.get("layoutMap",{}).get("cells",{}))
        if n < REQUIRED: errs.append(f"G2 {s}: control cells {n} < {REQUIRED}")
        for f, (w,h) in [("preview.png",(360,240)),("hero.png",(800,450))]:
            fp = os.path.join(p,"assets",f)
            if not os.path.exists(fp): errs.append(f"G3 {s}: нет {f}"); continue
            with open(fp,"rb") as fh: data = fh.read()
            if data[:8] != b"\x89PNG\r\n\x1a\n": errs.append(f"G3 {s}: {f} не PNG-подпись"); continue
            from PIL import Image
            try:
                im = Image.open(fp); im.load()
                if im.size != (w,h): errs.append(f"G3 {s}: {f} размер {im.size} != {(w,h)}")
            except Exception as e: errs.append(f"G3 {s}: {f} декод не удался: {e}")
        for f in ["texture.svg","bezel.svg","crest.svg"]:
            if not os.path.exists(os.path.join(p,"assets",f)): errs.append(f"G3 {s}: нет {f}")
    print("\n".join(errs) if errs else "VALIDATION PASS")
    sys.exit(1 if errs else 0)
if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv)>1 else ".")
