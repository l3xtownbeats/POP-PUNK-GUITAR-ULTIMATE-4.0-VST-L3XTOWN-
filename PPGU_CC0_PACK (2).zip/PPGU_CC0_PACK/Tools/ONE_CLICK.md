# Одна кнопка — три пути

1) ЧАТ GPT: скопируй Tools/GPT_PROMPT.txt в чат -> получишь PPGU_SampleLibrary.zip
2) ЛОКАЛЬНО: python3 Tools/ppgu_build_library.py --token FREESOUND_TOKEN
   (без токена: --github-only)
3) GITHUB: Docs/GITHUB_UPLOAD.md — репозиторий -> кнопка Code -> Download ZIP
   = вечная ссылка «скачать одной кнопкой» для любого пользователя.
   Raw-ссылки пресетов: https://raw.githubusercontent.com/USER/ppgu-library/main/Presets/NAME.json
