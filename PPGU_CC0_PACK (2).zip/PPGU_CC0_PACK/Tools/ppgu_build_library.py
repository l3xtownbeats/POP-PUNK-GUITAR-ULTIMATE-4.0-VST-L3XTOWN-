#!/usr/bin/env python3
"""PPGU library builder — one command, no questions.
Usage: python3 ppgu_build_library.py [--token FREESOUND_TOKEN] [--github-only]"""
import sys, os, json, zipfile, subprocess, shutil, urllib.request
CATS = {"pm":["04_PalmMute"],"power":["03_Distortion_PowerChords"],"octave":["06_Octaves"],
        "lead":["07_Leads"],"clean":["02_DI_Clean"],"acoustic":["01_Acoustic_Raw"],
        "release":["08_Release_Noises"]}
ZIPS = [
 ("freepats_fender","https://github.com/freepats/e-guitar-FSBS-direct/archive/refs/heads/master.zip"),
 ("karoryfer","https://github.com/sfzinstruments/karoryfer.black-and-green-guitars/archive/refs/heads/main.zip"),
 ("freepats_classical","https://github.com/freepats/spanish-classical-guitar/archive/refs/heads/master.zip"),
 ("lotkey_sfz","https://github.com/lotkey/free-sample-libraries-sfz/archive/refs/heads/main.zip"),
]
def cat_for(name):
    n = name.lower()
    for k, c in CATS.items():
        if k in n: return c[0]
    if n.endswith(".mid"): return "10_MIDI_Patterns"
    if "loop" in n: return "09_Loops"
    return None
def main():
    github_only = "--github-only" in sys.argv
    token = None
    if "--token" in sys.argv:
        token = sys.argv[sys.argv.index("--token")+1]
    root = "PPGU_SampleLibrary"
    shutil.rmtree(root, ignore_errors=True)
    for c in list(CATS.values()) + ["09_Loops","10_MIDI_Patterns","11_SoundFonts","reject"]:
        os.makedirs(os.path.join(root,c), exist_ok=True)
    report = {}
    for name, url in ZIPS:
        try:
            zpath = f"{name}.zip"; urllib.request.urlretrieve(url, zpath)
            subprocess.run([sys.executable,"-m","zipfile","-e",zpath,f"_tmp_{name}"],check=True)
            for dirpath,_,files in os.walk(f"_tmp_{name}"):
                for f in files:
                    src = os.path.join(dirpath,f)
                    c = cat_for(f) or "reject"
                    shutil.copy2(src, os.path.join(root,c,f))
            report[name] = "OK"
        except Exception as e:
            report[name] = f"SKIP: {e}"
    if not github_only and token:
        try:
            import urllib.parse
            for q in ["guitar power chord distorted","palm muted guitar"]:
                u = "https://freesound.org/apiv2/search/text/?query=%s&filter=license:%22Creative+Commons+0%22&token=%s" % (urllib.parse.quote(q), token)
                data = json.load(urllib.request.urlopen(u))
                for r in data.get("results",[])[:20]:
                    dl = r.get("download","")
                    if dl:
                        fn = f"fs_{r['id']}.mp3"
                        try:
                            urllib.request.urlretrieve(dl+"?token="+token, os.path.join(root,cat_for(fn) or "09_Loops",fn))
                        except Exception: pass
            report["freesound_api"] = "OK"
        except Exception as e:
            report["freesound_api"] = f"SKIP: {e}"
    with open(os.path.join(root,"LICENSES.md"),"w") as fh:
        fh.write("# LICENSES\n\n")
        for k,v in report.items(): fh.write(f"- {k}: {v}\n")
    with zipfile.ZipFile("PPGU_SampleLibrary.zip","w",zipfile.ZIP_DEFLATED) as z:
        for dp,_,fs in os.walk(root):
            for f in fs:
                p = os.path.join(dp,f); z.write(p, os.path.relpath(p, root))
    print("REPORT:", report)
    print("DONE -> PPGU_SampleLibrary.zip")
if __name__ == "__main__": main()
