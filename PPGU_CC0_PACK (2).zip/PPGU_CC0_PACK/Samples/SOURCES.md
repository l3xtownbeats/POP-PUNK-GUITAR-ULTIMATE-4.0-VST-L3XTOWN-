# PPGU — КАТАЛОГ ИСТОЧНИКОВ (WAV / OGG / FLAC)

## УРОВЕНЬ 1 — CC0 / PUBLIC DOMAIN (без ограничений: коммерция, без атрибуции)
Скачивать ПЕРВЫМИ и ЦЕЛИКОМ.

### Прямые ZIP (GitHub, без авторизации, один клик)
- https://github.com/freepats/e-guitar-FSBS-direct/archive/refs/heads/master.zip — Fender DI: clean/distorted/direct, WAV, CC0-1.0
- https://github.com/sfzinstruments/karoryfer.black-and-green-guitars/archive/refs/heads/main.zip — 2 полуакустические электрогитары, WAV+SFZ, CC0 (качать из Releases!)
- https://github.com/freepats/spanish-classical-guitar/archive/refs/heads/master.zip — классика для акустических слоёв, WAV, CC0
- https://github.com/lotkey/free-sample-libraries-sfz/archive/refs/heads/main.zip — Baritone Strat DI, palm mute размаплен по velocity (0-32 медиум, 33-63 высокий), SFZ

### Каталоги CC0-паков (WAV/OGG, без регистрации)
- https://producerspace.com/ — FREE PACKS, CC0, ~18 паков, 2.3 ГБ
- https://signaturesounds.org/ — CC0 гитарные паки WAV
- https://sfzinstruments.github.io/guitars/ — обзор всех открытых гитар (фильтр по CC0)
- https://cc0.wf/ — поиск CC0-звуков, фильтр: guitar
- https://freemusicarchive.org/ — CC0/Public Domain треки и сэмплы

### Freesound (CC0-фильтр, API или вручную)
- https://freesound.org/people/Chem/packs/1995/ — дисторшн-гитара ESP EC-300: power chords long/short + palm mute, 96kHz
- https://freesound.org/people/Ax_Grinder/packs/14939/ — power chords Drop D: open + palm-muted
- API: https://freesound.org/apiv2/search/text/?query=QUERY&filter=license:"Creative Commons 0"
  QUERY: guitar power chord distorted / palm muted guitar / crunch guitar / clean electric guitar / acoustic guitar raw
- Ключ (бесплатный): https://freesound.org/apiv2/apply

## УРОВЕНЬ 2 — royalty-free (бесплатно, коммерция обычно разрешена; смотреть лицензию)
- https://github.com/lotkey/free-sample-libraries-sfz — лицензию проверить у автора
- https://www.looperman.com/loops/tags/free-guitar-loops-samples-sounds-wavs-download — лупы WAV
- https://samplefocus.com/ — запросы: pop punk guitar / power chord / palm muted guitar
- https://splice.com/sounds/packs/signal-path/mike-naran-pop-punk-riffs/samples — Mike Naran Pop Punk Riffs (нужен аккаунт Splice, trial доступен)

## УРОВЕНЬ 3 — платные, легальный доступ ( НЕ включать в дистрибутив без лицензии )
- Native Instruments Session Guitarist Electric Sunburst Deluxe / Vintage — https://www.native-instruments.com/
  Сэмплы NI в библиотеку копировать нельзя. Совместимость: Presets/NI_Sunburst_Compat.json + Docs/NI_SESSION_GUITARIST_COMPAT.md.
  Если у тебя есть лицензия NI — пресеты и MIDI работают поверх его библиотеки.

## ЗАПРЕЩЕНО (жёсткое правило промта и скрипта)
Пиратские ресурсы, торренты, варез, обход капч и платных стен. Ответственность и риск — на дистрибьюторе плагина.
