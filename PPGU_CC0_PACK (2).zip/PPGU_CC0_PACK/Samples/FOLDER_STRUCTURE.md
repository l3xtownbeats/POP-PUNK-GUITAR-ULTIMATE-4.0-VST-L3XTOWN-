# Структура библиотеки PPGU_SampleLibrary

01_Acoustic_Raw/      — сырые акустические WAV/OGG/FLAC
02_DI_Clean/          — DI и чистые электрогитары
03_Distortion_PowerChords/ — пауэр-аккорды (long/short)
04_PalmMute/          — palm mute по velocity-слоям
05_Crunch/            — кранч-слои
06_Octaves/           — октавные фразы
07_Leads/             — лиды, бенды, соло
08_Release_Noises/    — release-шумы, pick noise (для движка)
09_Loops/             — лупы
10_MIDI_Patterns/     — MIDI-паттерны
11_SoundFonts/        — SFZ/SF2 для прямого проба в любом плеере
LICENSES.md           — файл -> источник -> лицензия
