# GitHub за 3 минуты
1. https://github.com/new -> репозиторий ppgu-library, Public
2. Code -> Add file -> Upload files -> загрузи всю папку PPGU_CC0_PACK
3. Кнопка Code -> Download ZIP на странице репо — постоянная ссылка «одной кнопкой»
4. (Опционально) Releases -> New release -> приложи PPGU_SampleLibrary.zip
