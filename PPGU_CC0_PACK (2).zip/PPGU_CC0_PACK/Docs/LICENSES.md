# Лицензии источников
- FreePats (e-guitar-FSBS-direct, spanish-classical-guitar): CC0-1.0 — без ограничений
- Karoryfer Black and Green Guitars: CC0 — коммерция разрешена
- Producer Space FREE packs: CC0 — без ограничений
- Signature Sounds: CC0 — без ограничений
- Freesound CC0-фильтр: по файлам, проверять поле license в API
- lotkey: лицензия не заявлена — UNKNOWN до подтверждения автором
- Looperman / Sample Focus: royalty-free, условия на странице лупа
- Splice: подписной, в дистрибутив плагина нельзя без права распространять сэмплы
- Native Instruments Session Guitarist: платный продукт, сэмплы копировать нельзя;
  наша совместимость — только JSON-пресеты и MIDI поверх лицензированной библиотеки
