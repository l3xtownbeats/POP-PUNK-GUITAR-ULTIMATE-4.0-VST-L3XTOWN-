#!/usr/bin/env python3
"""PPGU skin registry contract validator (R13/R14). No magic counts:
counts derive from the registry; checks uniqueness, continuity, folder parity."""
import json, sys, os

def main(root):
    mf = os.path.join(root, "theme_manifest.json")
    if not os.path.isfile(mf):
        print("FAIL theme_manifest.json missing"); return 1
    reg = json.load(open(mf, encoding="utf-8"))
    themes = reg.get("themes", [])
    n = reg.get("totalSkins", 0)
    if n != len(themes):
        print("FAIL totalSkins %d != registry entries %d" % (n, len(themes))); return 1
    if len(themes) < 52:
        print("FAIL registry below 52 themes: %d" % len(themes)); return 1
    ids = [t["id"] for t in themes]
    idx = [t["index"] for t in themes]
    if len(set(ids)) != len(ids): print("FAIL duplicate ids"); return 1
    if len(set(idx)) != len(idx): print("FAIL duplicate index"); return 1
    if sorted(idx) != list(range(1, len(idx) + 1)):
        print("FAIL index not continuous 1..%d" % len(idx)); return 1
    for t in themes:
        folder = os.path.join(root, t["folder"])
        tj = os.path.join(folder, "theme.json")
        if not os.path.isdir(folder) or not os.path.isfile(tj):
            print("FAIL missing folder/manifest: %s" % t["folder"]); return 1
        d = json.load(open(tj, encoding="utf-8"))
        if d.get("id") != t["id"] or int(d.get("index", -1)) != t["index"]:
            print("FAIL id/index mismatch: %s" % t["folder"]); return 1
    print("PASS: skin registry consistent (%d themes, continuous range)" % len(themes))
    print("PASS G1-G4: %d themes validated" % len(themes))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "SKIN"))
