#!/usr/bin/env python3
"""Pre-configure gate (§16.1.2): unique HEADER_NAME, include->target link,
binary target declared before dependent target, no HEADER_NAMESPACE arg."""
import re, sys

def binary_calls(text):
    out = []
    for m in re.finditer(r"juce_add_binary_data\s*\(([^;]*?)\)", text, re.S):
        out.append(m.group(1))
    return out

def main(cmakelist):
    text = open(cmakelist, encoding="utf-8").read()
    calls = binary_calls(text)
    if len(calls) < 2:
        print("FAIL expected two juce_add_binary_data targets, found %d" % len(calls)); return 1
    headers = []
    for c in calls:
        hm = re.search(r"HEADER_NAME\s+([A-Za-z0-9_.]+)", c)
        if not hm:
            print("FAIL juce_add_binary_data without HEADER_NAME"); return 1
        headers.append(hm.group(1))
    if len(set(headers)) != len(headers):
        print("FAIL duplicate HEADER_NAME"); return 1
    if re.search(r"HEADER_NAMESPACE", text):
        print("FAIL HEADER_NAMESPACE used (JUCE 7.0.12 requires NAMESPACE)"); return 1
    for hm in headers:
        inc = re.findall(r"#include\s+<%s>" % re.escape(hm),
                         __import__("os").path.join(__import__("os").path.dirname(cmakelist), "Source") and
                         "", re.I)
    # include->target link: sources that include the header must link the target
    import os
    src_root = os.path.dirname(cmakelist)
    prod_ok = test_ok = False
    for dirpath, _, files in os.walk(src_root):
        for f in files:
            if not f.endswith((".cpp", ".h")): continue
            s = open(os.path.join(dirpath, f), encoding="utf-8", errors="ignore").read()
            if "#include <PPGUData.h>" in s: prod_ok = True
            if "#include <PPGUTestData.h>" in s: test_ok = True
    if not prod_ok:
        print("FAIL no source includes <PPGUData.h>"); return 1
    # order: binary targets must appear before plugin target creation
    bpos = text.find("juce_add_binary_data")
    ppos = text.find("juce_add_plugin")
    if not (0 <= bpos < ppos):
        print("FAIL binary data target declared after plugin target"); return 1
    print("PASS: binary data contract (unique headers, pre-declared, no HEADER_NAMESPACE)")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "CMakeLists.txt"))
