#!/usr/bin/env python3
"""300-preset catalog contract."""
import json, sys

def main(path):
    bank = json.load(open(path, encoding="utf-8"))
    presets = bank.get("presets", [])
    if len(presets) != 300:
        print("FAIL preset count %d != 300" % len(presets)); return 1
    ids = [p["id"] for p in presets]
    if len(set(ids)) != 300: print("FAIL duplicate preset ids"); return 1
    need = {"ampGain","eqLow","eqMid","eqHigh","velocity","dynamics","swing","humanize","accent"}
    for p in presets:
        if set(p.get("params", {}).keys()) != need:
            print("FAIL params mismatch in %s" % p["id"]); return 1
        if p.get("playMode") not in ("MELODY", "PATTERN"):
            print("FAIL playMode invalid in %s" % p["id"]); return 1
    print("PASS: preset catalog valid (300 definitions, unique ids, APVTS parity)")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "PRESETS/factory_bank_300.json"))
