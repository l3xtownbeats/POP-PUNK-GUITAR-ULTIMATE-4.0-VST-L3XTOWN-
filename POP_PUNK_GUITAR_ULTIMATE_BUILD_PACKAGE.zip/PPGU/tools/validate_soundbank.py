#!/usr/bin/env python3
"""SoundBank contract: >=100 WAV, SFZ present, sha256 integrity."""
import json, hashlib, os, sys

def main(root):
    wavs = [f for f in os.listdir(root) if f.lower().endswith(".wav")]
    if len(wavs) < 100:
        print("FAIL WAV count %d < 100" % len(wavs)); return 1
    if not os.path.isfile(os.path.join(root, "factory.sfz")):
        print("FAIL factory.sfz missing"); return 1
    man = json.load(open(os.path.join(root, "manifest.json"), encoding="utf-8"))
    by_file = {m["file"]: m for m in man["files"]}
    bad = 0
    for f in wavs:
        m = by_file.get(f)
        if not m: print("FAIL manifest missing entry for %s" % f); bad += 1; continue
        h = hashlib.sha256(open(os.path.join(root, f), "rb").read()).hexdigest()
        if h != m.get("sha256"):
            print("FAIL sha256 mismatch: %s" % f); bad += 1
    if bad: return 1
    print("PASS: SoundBank consistent (%d WAV, SFZ + SHA-256 manifest verified)" % len(wavs))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "SOUNDBANK"))
