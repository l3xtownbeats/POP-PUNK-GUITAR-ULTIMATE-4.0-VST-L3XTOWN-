#include <cstdio>
#include <cstdlib>
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)
#define CHECK_EQ(a,b) do { if (!((a) == (b))) { std::fprintf(stderr, "FAIL %s:%d: %s == %s\n", __FILE__, __LINE__, #a, #b); std::exit(1); } } while (0)

#include "Source/Engine/PatternScheduler.h"
#include <cmath>
using namespace ppgu;

int main() {
    PatternParams p; // defaults: 120 bpm, swing 0, humanize 0, accent 0.75, vel 1.0
    // 1: determinism
    auto a = PatternScheduler::buildPattern(p);
    auto b = PatternScheduler::buildPattern(p);
    CHECK_EQ(a.size(), b.size());
    for (size_t i = 0; i < a.size(); ++i) {
        CHECK_EQ(a[i].step, b[i].step);
        CHECK_EQ(a[i].velocity, b[i].velocity);
    }
    // 2: velocity in range and monotone accented
    for (auto& n : a) { CHECK(n.velocity >= 1 && n.velocity <= 127); }
    // 3: swing pushes odd steps
    PatternParams ps; ps.swing = 1.0f;
    double offEven = PatternScheduler::stepOffsetSamples(ps, 0, 44100.0, 4.0, 1);
    double offOdd  = PatternScheduler::stepOffsetSamples(ps, 1, 44100.0, 4.0, 1);
    CHECK(offOdd > offEven);
    // 4: humanize adds jitter only when enabled
    PatternParams ph; ph.humanize = 1.0f;
    auto withHum = PatternScheduler::buildPattern(ph);
    bool differs = false;
    for (size_t i = 0; i < a.size(); ++i) if (withHum[i].velocity != a[i].velocity) differs = true;
    CHECK(differs);
    // 5: velocityScale clamps into 1..127
    PatternParams pv; pv.velocityScale = 2.0f;
    for (auto& n : PatternScheduler::buildPattern(pv))
        CHECK(n.velocity >= 1 && n.velocity <= 127);
    // 6: pump covers exact step window
    auto pump = PatternScheduler::pumpNotes(p, 0.0, 4.0); // one bar at 4 ppq per step... ppq unit = 4/step
    CHECK(!pump.notes.empty());
    for (auto& n : pump.notes) CHECK(n.step >= 0 && n.step < p.stepsPerBar);
    // 7: empty window yields nothing
    CHECK(PatternScheduler::pumpNotes(p, 2.0, 2.0).notes.empty());
    // 8: zero bpm safe
    PatternParams pz; pz.bpm = 0.0;
    CHECK(PatternScheduler::pumpNotes(pz, 0.0, 1.0).notes.empty());
    std::printf("ppgu_pattern_scheduler_tests: PASS (8 cases)\n");
    return 0;
}
