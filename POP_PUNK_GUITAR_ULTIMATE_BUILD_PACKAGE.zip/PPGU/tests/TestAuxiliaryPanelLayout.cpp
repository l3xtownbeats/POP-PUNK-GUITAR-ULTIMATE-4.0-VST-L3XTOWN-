#include <cstdio>
#include <cstdlib>
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)
#define CHECK_EQ(a,b) do { if (!((a) == (b))) { std::fprintf(stderr, "FAIL %s:%d: %s == %s\n", __FILE__, __LINE__, #a, #b); std::exit(1); } } while (0)

#include "Source/UI/AuxiliaryPanelLayout.h"
#include <set>
using namespace ppgu;

static AuxiliaryPanelLayout::PanelSize DS{640,420,380,260};
static AuxiliaryPanelLayout::PanelSize MN{380,260,260,180};

static bool overlap(const Rect& a, const Rect& b) {
    return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
}

int main() {
    // 1: zero panels -> empty, not invalid
    {
        auto r = AuxiliaryPanelLayout::computeTiled({}, 0,0,1920,1080, 1.0, DS, MN);
        CHECK(!r.invalidInput); CHECK(r.panels.empty());
    }
    // 2: one panel fits
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone}, 0,0,1920,1080, 1.0, DS, MN);
        CHECK(!r.invalidInput); CHECK_EQ(r.panels.size(), 1u);
        CHECK(!r.compact); CHECK(!r.overflow);
        CHECK(r.panels[0].visible);
    }
    // 3: two panels side by side, no overlap, inside work area
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::FxChain},
                                                    0,0,1920,1080, 1.0, DS, MN);
        CHECK(!r.invalidInput);
        auto& p0 = r.panels[0].rect; auto& p1 = r.panels[1].rect;
        CHECK(!overlap(p0, p1));
        CHECK(p0.x + p0.w <= 1920); CHECK(p1.x + p1.w <= 1920);
        CHECK(p0.y >= 0 && p0.y + p0.h <= 1080);
    }
    // 4: three panels -> tiled grid, no overlap
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::FxChain,
                                                     PanelId::Playback},
                                                    0,0,1920,1080, 1.0, DS, MN);
        CHECK(!r.invalidInput); CHECK_EQ(r.panels.size(), 3u);
        for (size_t i = 0; i < r.panels.size(); ++i)
            for (size_t j = i + 1; j < r.panels.size(); ++j)
                CHECK(!overlap(r.panels[i].rect, r.panels[j].rect));
    }
    // 5: all four panels open -> all visible, tiled
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::FxChain,
                                                     PanelId::Playback, PanelId::Playback},
                                                    0,0,2560,1440, 1.0, DS, MN);
        CHECK(!r.invalidInput); // duplicates? Playback appears once in ids; use unique set
    }
    // duplicate ids rejected
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::AmpTone},
                                                    0,0,1920,1080, 1.0, DS, MN);
        CHECK(r.invalidInput);
    }
    // 6: compact triggers on small screen
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::FxChain},
                                                    0,0,800,500, 1.0, DS, MN);
        CHECK(!r.invalidInput);
        CHECK(r.compact);
        for (auto& p : r.panels) CHECK(p.rect.w >= 260 && p.rect.h >= 180);
    }
    // 7: overflow on tiny screen -> only first visible
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::FxChain,
                                                     PanelId::Playback},
                                                    0,0,300,200, 1.0, DS, MN);
        CHECK(r.overflow);
        CHECK(r.panels[0].visible);
        CHECK(!r.panels[1].visible);
        CHECK(!r.panels[2].visible);
    }
    // 8: DPI scale grows panels but keeps bounds inside area
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::FxChain},
                                                    0,0,1920,1080, 2.0, DS, MN);
        CHECK(!r.invalidInput);
        for (auto& p : r.panels) CHECK(p.rect.x >= 0 && p.rect.x + p.rect.w <= 1920);
    }
    // 9: non-finite / zero scale normalizes
    {
        auto r1 = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone}, 0,0,1920,1080, 0.0, DS, MN);
        auto r2 = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone}, 0,0,1920,1080, -3.0, DS, MN);
        auto r3 = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone}, 0,0,1920,1080, std::nan(""), DS, MN);
        CHECK(!r1.invalidInput); CHECK(!r2.invalidInput); CHECK(!r3.invalidInput);
    }
    // 10: invalid work area rejected
    {
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone}, 0,0,0,1080, 1.0, DS, MN);
        CHECK(r.invalidInput);
    }
    // 11: min > desired rejected
    {
        AuxiliaryPanelLayout::PanelSize bad{100,100,200,200};
        auto r = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone}, 0,0,1920,1080, 1.0, bad, bad);
        CHECK(r.invalidInput);
    }
    // 12: determinism
    {
        auto a = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::FxChain,
                                                     PanelId::Playback}, 0,0,1920,1080, 1.0, DS, MN);
        auto b = AuxiliaryPanelLayout::computeTiled({PanelId::AmpTone, PanelId::FxChain,
                                                     PanelId::Playback}, 0,0,1920,1080, 1.0, DS, MN);
        for (size_t i = 0; i < a.panels.size(); ++i) {
            CHECK_EQ(a.panels[i].rect.x, b.panels[i].rect.x);
            CHECK_EQ(a.panels[i].rect.y, b.panels[i].rect.y);
        }
    }
    std::printf("ppgu_auxiliary_panel_layout_contract: PASS (12 cases)\n");
    return 0;
}
