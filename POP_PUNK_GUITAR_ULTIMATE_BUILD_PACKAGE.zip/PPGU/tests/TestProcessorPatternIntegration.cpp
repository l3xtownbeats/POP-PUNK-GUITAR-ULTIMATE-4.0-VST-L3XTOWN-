#include <cstdio>
#include <cstdlib>
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)
#define CHECK_EQ(a,b) do { if (!((a) == (b))) { std::fprintf(stderr, "FAIL %s:%d: %s == %s\n", __FILE__, __LINE__, #a, #b); std::exit(1); } } while (0)

// Integration: parameter value -> PatternParams -> pump semantics (pure path).
#include "Source/Engine/PatternScheduler.h"
#include <cmath>
using namespace ppgu;

static PatternParams fromParamValues(float velocity, float dynamics, float swing,
                                     float humanize, float accent) {
    PatternParams p;
    p.velocityScale = velocity;
    p.swing = swing;
    p.humanize = humanize;
    p.accent = accent;
    (void)dynamics; // dynamics shapes note-off/release shaping in engine, not step grid
    return p;
}

int main() {
    // 1: APVTS defaults map to deterministic groove
    auto p = fromParamValues(1.0f, 0.5f, 0.0f, 0.0f, 0.75f);
    auto notes = PatternScheduler::buildPattern(p);
    CHECK_EQ(notes.size(), 16u); // 8 roots + 8 chugs
    CHECK_EQ(notes[0].step, 0);
    // 2: swing 0 -> even offsets
    double off = PatternScheduler::stepOffsetSamples(p, 0, 44100.0, 4.0, 7);
    CHECK(std::fabs(off) < 1e-9);
    // 3: velocity param scales pattern velocity
    auto pv = fromParamValues(0.5f, 0.5f, 0.0f, 0.0f, 0.75f);
    auto scaled = PatternScheduler::buildPattern(pv);
    bool anyLower = false;
    for (size_t i = 0; i < notes.size(); ++i)
        if (scaled[i].velocity < notes[i].velocity) anyLower = true;
    CHECK(anyLower);
    // 4: MELODY mode bypasses pump (pattern only when playMode == PATTERN)
    // playMode is host-side gating; verify pump contract here:
    auto pump = PatternScheduler::pumpNotes(p, 0.0, 8.0, 40, {0, 7, 12});
    CHECK(!pump.notes.empty());
    std::printf("ppgu_processor_pattern_integration: PASS (4 cases)\n");
    return 0;
}
