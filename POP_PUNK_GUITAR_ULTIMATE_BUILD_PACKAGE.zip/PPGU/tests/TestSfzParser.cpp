#include <cstdio>
#include <cstdlib>
#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)
#define CHECK_EQ(a,b) do { if (!((a) == (b))) { std::fprintf(stderr, "FAIL %s:%d: %s == %s\n", __FILE__, __LINE__, #a, #b); std::exit(1); } } while (0)

#include "Source/Engine/SfzParser.h"
using namespace ppgu;

int main() {
    // 1: basic region parse
    {
        auto d = SfzParser::parse(
            "<region> sample=a.wav lokey=36 hikey=48 lovel=0 hivel=64 seq_length=5 seq_position=3 loop_mode=loop loop_start=1000 loop_end=2000");
        CHECK(d.valid);
        CHECK_EQ(d.groups.size(), 1u);
        CHECK_EQ(d.groups[0].regions.size(), 1u);
        auto& r = d.groups[0].regions[0];
        CHECK_EQ(r.loKey, 36); CHECK_EQ(r.hiKey, 48);
        CHECK_EQ(r.loVel, 0); CHECK_EQ(r.hiVel, 64);
        CHECK_EQ(r.seqLength, 5); CHECK_EQ(r.seqPosition, 3);
        CHECK(r.loopMode == 1);
        CHECK_EQ(int(r.loopStart), 1000); CHECK_EQ(int(r.loopEnd), 2000);
    }
    // 2: group inheritance
    {
        auto d = SfzParser::parse(
            "<group> lovel=10 hivel=20\n"
            "<region> sample=a.wav key=40\n"
            "<region> sample=b.wav key=41\n");
        CHECK(d.valid);
        CHECK_EQ(d.groups.size(), 1u);
        CHECK_EQ(d.groups[0].regions.size(), 2u);
        CHECK_EQ(d.groups[0].regions[1].loVel, 10);
        CHECK_EQ(d.groups[0].regions[1].hiVel, 20);
    }
    // 3: comments and blank lines tolerated
    {
        auto d = SfzParser::parse("# comment\n\n<region> // inline\n sample=c.wav key=60\n");
        CHECK(d.valid);
        CHECK_EQ(d.groups[0].regions[0].sample, std::string("c.wav"));
    }
    // 4: unknown opcodes tolerated
    {
        auto d = SfzParser::parse("<region> sample=d.wav ampeg_release=0.34 some_future_opcode=7");
        CHECK(d.valid);
    }
    // 5: invalid doc flagged
    {
        auto d = SfzParser::parse("<control> default_path=samples/\n");
        CHECK(!d.valid);
        CHECK(d.error.find("no regions") != std::string::npos);
    }
    // 6: bad numerics fall back to defaults (no crash)
    {
        auto d = SfzParser::parse("<region> sample=e.wav lokey=abc hivel=xyz seq_length=-3");
        CHECK(d.valid);
        CHECK_EQ(d.groups[0].regions[0].seqLength, 1); // clamped
    }
    std::printf("ppgu_sfz_parser_tests: PASS (6 cases)\n");
    return 0;
}
