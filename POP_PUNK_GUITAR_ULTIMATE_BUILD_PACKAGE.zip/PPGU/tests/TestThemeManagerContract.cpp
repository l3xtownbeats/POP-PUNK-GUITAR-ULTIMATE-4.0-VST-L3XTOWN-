#include <cstdio>
#include <cstdlib>
#include <juce_core/juce_core.h>
#include "Source/UI/ThemeManager.h"

#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)

int main() {
    juce::ScopedJuceInitialiser_GUI init;
    using namespace ppgu;

    // 1: fallback palette always present and loadable
    ThemeManager tm;
    CHECK(tm.hasTheme(ThemeManager::fallbackThemeId()));
    CHECK(tm.loadTheme(ThemeManager::fallbackThemeId()));
    auto t = tm.tokens();
    CHECK(t.window.startsWith("#"));
    CHECK(t.accent.startsWith("#"));

    // 2: token count contract is 21
    CHECK(ThemeManager::kTokenCount == 21);

    // 3: control parity contract is 27 mandatory ids
    int n = 0;
    for (auto* c : ThemeManager::kControlIds) (void)c, ++n;
    CHECK(n == 27);

    // 4: validator rejects broken manifest
    {
        juce::String err;
        auto bad = juce::JSON::parse(juce::String(R"({"id":"x","index":99,"name":"n"})"));
        CHECK(!ThemeManager::validateManifestJson(bad, err, false));
        CHECK(err.isNotEmpty());
    }
    // 5: validator accepts a well-formed minimal manifest (palette-only runtime)
    {
        juce::String err;
        juce::DynamicObject::Ptr pal = new juce::DynamicObject();
        for (auto* tok : ThemeManager::kTokenNames)
            pal->setProperty(tok, juce::var(juce::String("#123456")));
        juce::DynamicObject::Ptr ctrl = new juce::DynamicObject();
        for (auto* c : ThemeManager::kControlIds)
            ctrl->setProperty(c, juce::var(new juce::DynamicObject()));
        juce::DynamicObject::Ptr m = new juce::DynamicObject();
        m->setProperty("id", juce::var("skin-001"));
        m->setProperty("index", juce::var(1));
        m->setProperty("name", juce::var("Test"));
        m->setProperty("palette", juce::var(pal));
        m->setProperty("controlLayout", juce::var(ctrl));
        CHECK(ThemeManager::validateManifestJson(juce::var(m), err, false));
    }
    // 6: embedded test BinaryData resource reachable via PPGUTestData
    CHECK(PPGUTestData::ppgu_test_data_txtSize > 0);

    std::printf("ppgu_theme_manager_contract: PASS (6 cases)\n");
    return 0;
}
