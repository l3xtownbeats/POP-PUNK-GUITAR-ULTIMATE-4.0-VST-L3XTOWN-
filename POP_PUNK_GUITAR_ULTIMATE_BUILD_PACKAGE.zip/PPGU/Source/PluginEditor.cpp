#include "PluginEditor.h"
#include <PPGUData.h>

namespace ppgu {

PluginEditor::PluginEditor(PluginProcessor& p)
    : AudioProcessorEditor(p), proc(p), panelManager(*this) {
    setResizeLimits(900, 560, 1600, 900);

    addAndMakeVisible(headerLabel);
    headerLabel.setText("POP PUNK GUITAR ULTIMATE", juce::dontSendNotification);

    addAndMakeVisible(skinButton);
    skinButton.onClick = [this] {
        juce::PopupMenu m;
        auto ids = themes.themeIds();
        if (ids.isEmpty()) ids.add(ThemeManager::fallbackThemeId());
        for (int i = 0; i < ids.size(); ++i)
            m.addItem(juce::String(i + 1) + ". " + ids[i], i + 1, ids[i] == themes.currentId());
        m.showMenuAsync(juce::PopupMenu::Options(), [this, ids](int r) {
            if (r > 0 && r <= ids.size()) applyTheme(ids[r - 1]);
        });
    };

    addAndMakeVisible(melodyBtn); addAndMakeVisible(patternBtn);
    melodyBtn.setClickingTogglesState(true); patternBtn.setClickingTogglesState(true);
    melodyBtn.setToggleState(true, juce::dontSendNotification);
    melodyBtn.onClick = [this] {
        patternBtn.setToggleState(false, juce::dontSendNotification);
        if (auto* pm = proc.apvts.getRawParameterValue("playMode")) pm->storeNotifying(0.0f);
    };
    patternBtn.onClick = [this] {
        melodyBtn.setToggleState(false, juce::dontSendNotification);
        if (auto* pm = proc.apvts.getRawParameterValue("playMode")) pm->storeNotifying(1.0f);
    };

    addAndMakeVisible(loadSfzBtn);
    loadSfzBtn.onClick = [this] {
        auto fc = std::make_shared<juce::FileChooser>("Select SFZ", juce::File(), "*.sfz");
        fc->launchAsync(juce::FileBrowserComponent::openMode
                        | juce::FileBrowserComponent::canSelectFiles,
                        [this, fc](const juce::FileChooser& c) {
            auto f = c.getResult();
            if (f.existsAsFile()) {
                auto err = proc.loadSfz(f);
                statusLabel.setText(err.isEmpty() ? "LOADED: " + f.getFileName()
                                                  : "SFZ ERROR: " + err,
                                    juce::dontSendNotification);
            }
        });
    };

    addAndMakeVisible(panelAmpBtn); addAndMakeVisible(panelFxBtn); addAndMakeVisible(panelPlayBtn);
    panelAmpBtn.onClick = [this] { openPanel(PanelId::AmpTone); };
    panelFxBtn.onClick  = [this] { openPanel(PanelId::FxChain); };
    panelPlayBtn.onClick = [this] { openPanel(PanelId::Playback); };

    addAndMakeVisible(presetSelector);
    presetSelector.setTextWhenNothingSelected("PRESET");
    presetSelector.onChange = [this] { loadSelectedPreset(); };
    addAndMakeVisible(categorySelector);
    categorySelector.addItemList({ "ALL", "CLEAN", "CRUNCH", "DRIVE", "LEAD",
                                   "AMBIENT", "POP PUNK", "EMO", "PUNK GROUP", "FX" }, 1);
    categorySelector.onChange = [this] { rebuildPresetList(); };
    addAndMakeVisible(searchBox);
    searchBox.setTextToShowWhenEmpty("search...", juce::Colour(0xff5c5c64));
    searchBox.onTextChange = [this] { rebuildPresetList(); };
    searchBox.onReturnKey = [this] { rebuildPresetList(); };

    addAndMakeVisible(statusLabel);
    statusLabel.setText("READY - LOAD SFZ OR USE FACTORY BANK", juce::dontSendNotification);
    addAndMakeVisible(keyboard);

    themes.scan(juce::File::getSpecialLocation(juce::File::currentExecutableFile)
                  .getParentDirectory().getParentDirectory().getChildFile("Skins"));
    applyTheme(ThemeManager::fallbackThemeId());

    loadFactoryPresets();
    startTimerHz(4);
}

PluginEditor::~PluginEditor() {
    stopTimer();
    panelManager.~AuxiliaryPanelManager(); // windows die before host teardown
}

void PluginEditor::timerCallback() {
    if (proc.engine().isBankReady())
        statusLabel.setText("FACTORY BANK READY", juce::dontSendNotification);
}

void PluginEditor::applyTheme(const juce::String& id) {
    themes.loadTheme(id);
    auto& T = themes.tokens();
    auto bg = T.colour("window", juce::Colour(0xff141416));
    auto fg = T.colour("textPrimary", juce::Colours::white);
    auto acc = T.colour("accent", juce::Colour(0xffb6f24d));
    auto btn = T.colour("buttonBg", juce::Colour(0xff2f2f36));
    for (juce::TextButton* b : { &skinButton, &melodyBtn, &patternBtn, &loadSfzBtn,
                                 &panelAmpBtn, &panelFxBtn, &panelPlayBtn }) {
        b->setColour(juce::TextButton::buttonColourId, btn);
        b->setColour(juce::TextButton::textColourOffId, fg);
        b->setColour(juce::TextButton::buttonOnColourId, acc);
    }
    for (juce::Component* c : { &presetSelector, &categorySelector })
        c->setColour(juce::ComboBox::backgroundColourId, T.colour("surface", juce::Colour(0xff26262b)));
    keyboard.setColour(juce::MidiKeyboardComponent::whiteNoteColourId, juce::Colour(0xffe8e8ec));
    keyboard.setColour(juce::MidiKeyboardComponent::keyDownOverlayColourId, acc);
    statusLabel.setColour(juce::Label::textColourId, T.colour("lcdText", acc));
    headerLabel.setColour(juce::Label::textColourId, fg);
    repaint();
}

void PluginEditor::openPanel(PanelId id) {
    switch (id) {
        case PanelId::AmpTone:
            panelManager.open(id, std::make_unique<AmpTonePanel>(themes, proc.apvts), "AMP & TONE");
            break;
        case PanelId::FxChain:
            panelManager.open(id, std::make_unique<FxChainPanel>(themes, proc.apvts), "FX CHAIN");
            break;
        case PanelId::Playback:
            panelManager.open(id, std::make_unique<PlaybackPanel>(themes, proc.apvts), "PLAYBACK");
            break;
        default: break;
    }
}

bool PluginEditor::keyPressed(const juce::KeyPress& k) {
    if (k.isKeyCurrentlyDown('k') && k.getModifiers().isCtrlDown()) {
        skinButton.triggerClick();
        return true;
    }
    return Component::keyPressed(k);
}

void PluginEditor::loadFactoryPresets() {
    // Built-in catalog ships in PPGUData; full 300-bank ships with Skins/Presets payload.
    presetNames.clear();
    for (int i = 0; i < BinaryData::namedResourceListSize; ++i)
        presetNames.add(BinaryData::namedResourceList[i]);
    rebuildPresetList();
}

void PluginEditor::rebuildPresetList() {
    presetSelector.clear(juce::dontSendNotification);
    auto cat = categorySelector.getText();
    auto q = searchBox.getText();
    for (int i = 0; i < presetNames.size(); ++i) {
        auto n = presetNames[i];
        if (cat != "ALL" && !n.contains(cat)) continue;
        if (q.isNotEmpty() && !n.containsIgnoreCase(q)) continue;
        presetSelector.addItem(n, i + 1);
    }
}

void PluginEditor::loadSelectedPreset() {
    int id = presetSelector.getSelectedId();
    if (id <= 0 || id > presetNames.size()) return;
    statusLabel.setText("PRESET: " + presetNames[id - 1], juce::dontSendNotification);
}

void PluginEditor::paint(juce::Graphics& g) {
    auto& T = themes.tokens();
    g.fillAll(T.colour("window", juce::Colour(0xff141416)));
    g.setColour(T.colour("bezel", juce::Colour(0xff3a3a42)));
    g.drawRect(getLocalBounds().reduced(2), 2);
    g.setColour(T.colour("accent", juce::Colour(0xffb6f24d)));
    g.fillRect(2, 2, getWidth() - 4, 3);
}

void PluginEditor::resized() {
    auto a = getLocalBounds().reduced(10);
    headerLabel.setBounds(a.removeFromTop(30));
    auto top = a.removeFromTop(40);
    skinButton.setBounds(top.removeFromRight(90));
    panelPlayBtn.setBounds(top.removeFromRight(110));
    panelFxBtn.setBounds(top.removeFromRight(110));
    panelAmpBtn.setBounds(top.removeFromRight(130));
    top.removeFromRight(8);
    melodyBtn.setBounds(top.removeFromLeft(90));
    patternBtn.setBounds(top.removeFromLeft(100));
    loadSfzBtn.setBounds(top.removeFromLeft(110));

    auto mid = a.removeFromTop(44);
    categorySelector.setBounds(mid.removeFromLeft(130));
    searchBox.setBounds(mid.removeFromLeft(180));
    presetSelector.setBounds(mid.removeFromLeft(260));

    statusLabel.setBounds(a.removeFromTop(28));
    keyboard.setBounds(a.removeFromBottom(90));
}

} // namespace ppgu
