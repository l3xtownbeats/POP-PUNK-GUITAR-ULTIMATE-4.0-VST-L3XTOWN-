#include "FxChain.h"
#include <cmath>
#include <algorithm>
#include <numeric>

namespace ppgu {

static void biquadLowShelf(float& b0, float& b1, float& b2, float& a1, float& a2,
                           double fs, float freq, float gainDb) {
    float A = std::pow(10.0f, gainDb / 40.0f);
    float w0 = float(2.0 * 3.14159265358979 * freq / fs);
    float cw = std::cos(w0), sw = std::sin(w0);
    float alpha = sw / (2.0f * std::sqrt(2.0f));
    float a0 = (A + 1) + (A - 1) * cw + 2.0f * std::sqrt(A) * alpha;
    b0 = (A * ((A + 1) - (A - 1) * cw + 2.0f * std::sqrt(A) * alpha)) / a0;
    b1 = (2.0f * A * ((A - 1) + (A + 1) * cw)) / a0;
    b2 = (A * ((A + 1) + (A - 1) * cw - 2.0f * std::sqrt(A) * alpha)) / a0;
    a1 = (-2.0f * ((A - 1) + (A + 1) * cw)) / a0;
    a2 = ((A + 1) + (A - 1) * cw - 2.0f * std::sqrt(A) * alpha) / a0;
}

void FxChain::updateEqCoefs() {
    for (int c = 0; c < 2; ++c) {
        biquadLowShelf(bq[c][0][0], bq[c][0][1], bq[c][0][2], bq[c][0][3], bq[c][0][4], sr, 150.0f, params.eqLow);
        biquadLowShelf(bq[c][1][0], bq[c][1][1], bq[c][1][2], bq[c][1][3], bq[c][1][4], sr, 2500.0f, params.eqMid);
        biquadLowShelf(bq[c][2][0], bq[c][2][1], bq[c][2][2], bq[c][2][3], bq[c][2][4], sr, 6000.0f, params.eqHigh);
    }
}

void FxChain::prepare(double sampleRate, int maxBlock) {
    sr = sampleRate > 0 ? sampleRate : 44100.0;
    (void)maxBlock;
    for (int c = 0; c < 2; ++c) {
        int delays[4] = { 1116, 1188, 1277, 1356 };
        for (int i = 0; i < 4; ++i) comb[c][i].buf.assign(size_t(delays[i]), 0.0f);
        ap[c][0].buf.assign(556, 0.0f); ap[c][1].buf.assign(441, 0.0f);
    }
    updateEqCoefs();
}

void FxChain::process(float* L, float* R, int n) {
    updateEqCoefs();
    const float pi = 3.14159265358979f;
    for (int i = 0; i < n; ++i) {
        float ch[2] = { L[i], R[i] };

        // --- EQ (always active) ---
        for (int c = 0; c < 2; ++c) {
            float x = ch[c];
            for (int b = 0; b < 3; ++b) {
                const auto& k = bq[c][b];
                float y = k[0] * x + k[1] * bqState[c][b][0] + k[2] * bqState[c][b][1]
                        - k[3] * bqState[c][b][0] - k[4] * bqState[c][b][1];
                bqState[c][b][1] = bqState[c][b][0];
                bqState[c][b][0] = y;
                x = y;
            }
            ch[c] = x;
        }

        // --- Distortion: DC block + tanh + tone ---
        if (params.distortion) {
            float drive = 1.0f + params.drive * 9.0f;
            for (int c = 0; c < 2; ++c) {
                float x = ch[c] * drive;
                float y = std::tanh(x);
                y = onepoleLP(y, dcZ[c], 0.25f); // tame fizz
                ch[c] = y;
            }
        }

        // --- CabSim: LP cascade ---
        if (params.cabSim) {
            static float z1[2] = { 0, 0 }, z2[2] = { 0, 0 };
            for (int c = 0; c < 2; ++c) {
                float coef = 0.18f;
                float y = onepoleLP(ch[c], z1[c], coef);
                ch[c] = onepoleLP(y, z2[c], coef);
            }
        }

        // --- Chorus ---
        if (params.chorus) {
            chorPhase += float(2.0 * pi * 0.6 / sr);
            if (chorPhase > 2.0f * pi) chorPhase -= 2.0f * pi;
            int d = int((0.002 + 0.0015 * std::sin(chorPhase)) * sr);
            for (int c = 0; c < 2; ++c) {
                float rd = chorBuf[c][(chorPos - d + 9600) % 9600];
                chorBuf[c][chorPos] = ch[c];
                ch[c] = 0.72f * ch[c] + 0.4f * rd;
            }
            chorPos = (chorPos + 1) % 9600;
        }

        // --- Delay (ping-pong) ---
        if (params.delay) {
            int d = int(0.25f * sr); // 250 ms
            float sendL = delBuf[1][(delPos - d + 192000) % 192000];
            float sendR = delBuf[0][(delPos - d + 192000) % 192000];
            delBuf[0][delPos] = ch[0] + 0.45f * sendL;
            delBuf[1][delPos] = ch[1] + 0.45f * sendR;
            ch[0] += 0.5f * sendR;
            ch[1] += 0.5f * sendL;
            delPos = (delPos + 1) % 192000;
        }

        // --- Reverb (stereo combs + allpass) ---
        if (params.reverb) {
            float wet[2] = { 0, 0 };
            for (int c = 0; c < 2; ++c) {
                float acc = 0.0f;
                for (int k = 0; k < 4; ++k) {
                    auto& cb = comb[c][k];
                    float y = cb.buf[size_t(cb.pos)];
                    acc += y;
                    cb.buf[size_t(cb.pos)] = ch[c] + cb.fb * y;
                    cb.pos = (cb.pos + 1) % int(cb.buf.size());
                }
                acc *= 0.25f;
                for (int k = 0; k < 2; ++k) {
                    auto& a = ap[c][k];
                    float bufv = a.buf[size_t(a.pos)];
                    float x2 = acc + (-0.5f) * bufv;
                    a.buf[size_t(a.pos)] = x2;
                    acc = bufv + 0.5f * x2;
                    a.pos = (a.pos + 1) % int(a.buf.size());
                }
                wet[c] = acc;
            }
            ch[0] = 0.7f * ch[0] + 0.4f * wet[0];
            ch[1] = 0.7f * ch[1] + 0.4f * wet[1];
        }

        // --- Compressor ---
        if (params.compressor) {
            for (int c = 0; c < 2; ++c) {
                float x = std::fabs(ch[c]);
                envRms[c] += 0.05f * (x - envRms[c]);
                float g = 1.0f;
                if (envRms[c] > 0.20f) g = 0.20f / envRms[c];
                ch[c] *= g;
            }
        }

        // --- Limiter (always engaged as safety stage) ---
        {
            for (int c = 0; c < 2; ++c) {
                float x = std::fabs(ch[c]);
                envPeak[c] = std::max(x, envPeak[c] * 0.9995f);
                if (envPeak[c] > 0.98f) ch[c] *= 0.98f / envPeak[c];
            }
        }

        L[i] = std::clamp(ch[0], -4.0f, 4.0f);
        R[i] = std::clamp(ch[1], -4.0f, 4.0f);
    }
}

} // namespace ppgu
