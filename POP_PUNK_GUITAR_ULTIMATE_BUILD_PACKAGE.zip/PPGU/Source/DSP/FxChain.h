#pragma once
// PPGU FX chain: Distortion, Chorus, Delay, Reverb, Compressor, Limiter, CabSim.
// Fixed order, APVTS-driven enable flags + depths. Realtime-safe.
#include <vector>
#include <array>

namespace ppgu {

struct FxParams {
    bool distortion = true, chorus = false, delay = false,
         reverb = true, compressor = false, limiter = true, cabSim = false;
    float drive = 0.5f;      // 0..1
    float eqLow = 0.0f, eqMid = 0.0f, eqHigh = 0.0f; // -12..12 dB
};

class FxChain {
public:
    void prepare(double sampleRate, int maxBlock);
    void setParams(const FxParams& p) { params = p; }
    void process(float* L, float* R, int n);
private:
    static float onepoleLP(float x, float& z, float coef) {
        z += coef * (x - z); return z;
    }
    FxParams params;
    double sr = 44100.0;
    // distortion
    float dcZ[2] = { 0, 0 };
    // chorus
    float chorBuf[2][9600] = {};
    int chorPos = 0;
    float chorPhase = 0.0f;
    // delay
    float delBuf[2][192000] = {};
    int delPos = 0;
    // reverb (4 combs + 2 allpass per channel)
    struct Comb { std::vector<float> buf; int pos = 0; float fb = 0.80f; };
    struct Ap    { std::vector<float> buf; int pos = 0; };
    Comb comb[2][4]; Ap ap[2][2];
    // compressor / limiter envelopes
    float envRms[2] = { 0, 0 }, envPeak[2] = { 0, 0 };
    // EQ (biquad coefficients)
    float bq[2][3][5] = {}; // [ch][band][b0 b1 b2 a1 a2]
    float bqState[2][3][2] = {};
    void updateEqCoefs();
};

} // namespace ppgu
