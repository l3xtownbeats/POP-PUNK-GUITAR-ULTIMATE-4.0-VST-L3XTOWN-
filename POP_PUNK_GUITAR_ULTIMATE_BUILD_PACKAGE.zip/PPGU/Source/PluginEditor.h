#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "UI/ThemeManager.h"
#include "UI/Panels.h"
#include "UI/AuxiliaryPanelWindow.h"

namespace ppgu {

class PluginEditor : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit PluginEditor(PluginProcessor& p);
    ~PluginEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
    bool keyPressed(const juce::KeyPress& k) override;
private:
    void timerCallback() override;
    void applyTheme(const juce::String& id);
    void openPanel(PanelId id);

    PluginProcessor& proc;
    ThemeManager themes;

    juce::TextButton skinButton{ "SKIN" }, melodyBtn{ "MELODY" }, patternBtn{ "PATTERN" },
                    loadSfzBtn{ "LOAD SFZ" }, panelAmpBtn{ "AMP & TONE" },
                    panelFxBtn{ "FX CHAIN" }, panelPlayBtn{ "PLAYBACK" };
    juce::ComboBox presetSelector, categorySelector;
    juce::TextEditor searchBox;
    juce::Label statusLabel, headerLabel;
    juce::MidiKeyboardComponent keyboard{ proc.apvts.keyboardState, juce::MidiKeyboardComponent::horizontalKeyboard };

    AuxiliaryPanelManager panelManager;
    std::vector<juce::String> presetNames;

    void loadFactoryPresets();
    void rebuildPresetList();
    void loadSelectedPreset();
};

} // namespace ppgu
