#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <PPGUData.h>

namespace ppgu {

static juce::AudioParameterFloat* rotary(juce::AudioProcessorValueTreeState::ParameterLayout& l,
                                         const char* id, const char* name,
                                         float lo, float hi, float def, const char* suffix = "") {
    auto p = std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ id, 1 }, name, juce::NormalisableRange<float>(lo, hi, 0.01f), def);
    if (suffix != juce::String("")) (void)suffix;
    auto* raw = p.get();
    l.add(std::move(p));
    return raw;
}

juce::AudioProcessorValueTreeState::ParameterLayout PluginProcessor::createParameterLayout() {
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "ampGain", 1 }, "AMP Gain",
        juce::NormalisableRange<float>(0.0f, 10.0f, 0.01f), 5.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "eqLow", 1 }, "EQ Low",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "eqMid", 1 }, "EQ Mid",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "eqHigh", 1 }, "EQ High",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "velocity", 1 }, "Velocity",
        juce::NormalisableRange<float>(0.0f, 2.0f, 0.01f), 1.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "dynamics", 1 }, "Dynamics",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.5f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "swing", 1 }, "Swing",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "humanize", 1 }, "Humanize",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "accent", 1 }, "Accent",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.75f));

    for (auto* id : { "fxDistortion", "fxChorus", "fxDelay", "fxReverb",
                      "fxCompressor", "fxLimiter", "fxCabSim" }) {
        juce::String n = juce::String(id).fromFirstOccurrenceOf("fx", false, false);
        layout.add(std::make_unique<juce::AudioParameterBool>(
            juce::ParameterID{ id, 1 }, n, id == juce::String("fxDistortion")
                                          || id == juce::String("fxReverb")
                                          || id == juce::String("fxLimiter")));
    }
    layout.add(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{ "playMode", 1 }, "Play Mode",
        juce::StringArray{ "MELODY", "PATTERN" }, 0));
    return layout;
}

PluginProcessor::PluginProcessor()
    : AudioProcessor(BusesProperties()
                       .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "PPGU_PARAMS", createParameterLayout()) {
    patternParams_.seed = 20261112u;
}

void PluginProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    engine_.prepare(sampleRate, samplesPerBlock);
    fx_.prepare(sampleRate, samplesPerBlock);
    ppqLast = -1.0;
}

juce::String PluginProcessor::loadSfz(const juce::File& f) {
    juce::String err;
    if (engine_.loadSfzAsync(f, err)) return {};
    return err;
}

void PluginProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi) {
    buffer.clear();
    auto* pmParam = apvts.getRawParameterValue("playMode");
    bool patternMode = pmParam != nullptr && int(pmParam->load()) == 1;
    patternMode_.store(patternMode);

    // --- MIDI source: host events or deterministic pattern pump ---
    if (patternMode) {
        auto* posInfo = getPlayHead() ? getPlayHead()->getPosition() : nullptr;
        if (posInfo.has_value() && posInfo->getIsPlaying()) {
            double ppq = posInfo->getPpqPosition().orFallback(0.0);
            double ppqEnd = ppq + double(buffer.getNumSamples()) / getSampleRate()
                          * (posInfo->getBpm().orFallback(120.0) / 60.0);
            if (ppqLast < 0.0 || ppq < ppqLast) ppqLast = ppq;
            auto pump = PatternScheduler::pumpNotes(patternParams_, ppqLast, ppqEnd, 40, { 0, 7, 12 });
            ppqLast = ppqEnd;
            for (auto& n : pump.notes) {
                auto* vel = apvts.getRawParameterValue("velocity");
                int v = juce::jlimit(1, 127, int(float(n.velocity) * (vel ? vel->load() : 1.0f)));
                midi.addEvent(juce::MidiMessage::noteOn(1, n.key, (juce::uint8) v),
                              juce::jlimit(0, buffer.getNumSamples() - 1, 0));
                midi.addEvent(juce::MidiMessage::noteOff(1, n.key),
                              juce::jlimit(0, buffer.getNumSamples() - 1, buffer.getNumSamples() - 1));
            }
        }
    }

    // --- voice allocation ---
    for (const auto metadata : midi) {
        const auto& m = metadata.getMessage();
        if (m.isNoteOn()) {
            auto* vel = apvts.getRawParameterValue("velocity");
            int v = juce::jlimit(1, 127, int(m.getVelocity() * (vel ? vel->load() : 1.0f)));
            engine_.noteOn(m.getChannel(), m.getNoteNumber(), v);
        } else if (m.isNoteOff()) {
            engine_.noteOff(m.getChannel(), m.getNoteNumber());
        } else if (m.isAllNotesOff() || m.isAllSoundOff()) {
            engine_.allNotesOff();
        }
    }

    // --- render + fx ---
    auto* L = buffer.getWritePointer(0);
    auto* R = buffer.getNumChannels() > 1 ? buffer.getWritePointer(1) : L;
    engine_.render(L, R, buffer.getNumSamples());

    FxParams fp;
    auto g = [&](const char* id) { auto* p = apvts.getRawParameterValue(id); return p ? p->load() : 0.0f; };
    fp.drive   = g("ampGain") / 10.0f;
    fp.eqLow   = g("eqLow"); fp.eqMid = g("eqMid"); fp.eqHigh = g("eqHigh");
    fp.distortion = apvts.getRawParameterValue("fxDistortion")->load() > 0.5f;
    fp.chorus  = apvts.getRawParameterValue("fxChorus")->load() > 0.5f;
    fp.delay   = apvts.getRawParameterValue("fxDelay")->load() > 0.5f;
    fp.reverb  = apvts.getRawParameterValue("fxReverb")->load() > 0.5f;
    fp.compressor = apvts.getRawParameterValue("fxCompressor")->load() > 0.5f;
    fp.limiter = apvts.getRawParameterValue("fxLimiter")->load() > 0.5f;
    fp.cabSim  = apvts.getRawParameterValue("fxCabSim")->load() > 0.5f;
    fx_.setParams(fp);
    fx_.process(L, R, buffer.getNumSamples());

    if (buffer.getNumChannels() == 1) buffer.applyGain(0, 0.5f);
}

void PluginProcessor::getStateInformation(juce::MemoryBlock& dest) {
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    if (xml) copyXmlToBinary(*xml, dest);
}

void PluginProcessor::setStateInformation(const void* data, int sizeInBytes) {
    auto xml = getXmlFromBinary(data, sizeInBytes);
    if (xml && xml->hasTagName(apvts.state.getType()))
        apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessorEditor* PluginProcessor::createEditor() {
    return new PluginEditor(*this);
}

} // namespace ppgu

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new ppgu::PluginProcessor();
}
