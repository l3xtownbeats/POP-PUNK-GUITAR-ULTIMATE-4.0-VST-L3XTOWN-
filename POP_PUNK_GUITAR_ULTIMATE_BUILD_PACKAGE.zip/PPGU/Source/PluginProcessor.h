#pragma once
#include <JuceHeader.h>
#include "Engine/SamplerEngine.h"
#include "Engine/PatternScheduler.h"
#include "DSP/FxChain.h"

namespace ppgu {

class PluginProcessor : public juce::AudioProcessor {
public:
    PluginProcessor();
    ~PluginProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override {
        return true; // fixed stereo out
    }
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "POP PUNK GUITAR ULTIMATE"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 3.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Factory"; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& dest) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;
    SamplerEngine& engine() { return engine_; }
    juce::String loadSfz(const juce::File& f);

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    juce::AudioProcessorValueTreeState::ParameterLayout layout_;
    SamplerEngine engine_;
    FxChain fx_;
    PatternParams patternParams_;
    double ppqLast = -1.0;
    juce::MidiBuffer pendingPatternNotes_;
    std::atomic<bool> patternMode_{ false };
};

} // namespace ppgu
