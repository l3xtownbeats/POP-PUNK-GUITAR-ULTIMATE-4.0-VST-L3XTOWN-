#include "ThemeManager.h"
#include <map>

namespace ppgu {

const char* const ThemeManager::kTokenNames[kTokenCount] = {
    "window","panel","surface","textPrimary","textSecondary","textDisabled",
    "lcdBg","lcdText","accent","accent2","meter","warning","bezel",
    "knobArc","knobBody","buttonBg","buttonText","buttonActive",
    "headerBg","shadow","highlight"
};

const char* const ThemeManager::kControlIds[27] = {
    "ampGain","eqHigh","eqMid","eqLow","velocity","dynamics","swing",
    "humanize","accent","fxDistortion","fxChorus","fxDelay","fxReverb",
    "fxCompressor","fxLimiter","fxCabSim","PUNK_GROUP","LED_indicator",
    "Auto_Discover","Curator","Settings","About","LCD_display","SKIN_button",
    "Import_Guitar","midi_keyboard","preset_selector"
};

ThemeTokens ThemeManager::fallbackTokens() {
    // Blackout Voltage reference palette
    return { "#141416", "#1d1d20", "#26262b", "#e8e8ec", "#9a9aa2", "#5c5c64",
             "#0c0c0e", "#b6f24d", "#b6f24d", "#2dd4bf", "#e5484d", "#f5a524",
             "#3a3a42", "#b6f24d", "#2a2a30", "#2f2f36", "#e8e8ec", "#b6f24d",
             "#191921", "#08080a", "#2dd4bf" };
}

juce::Colour ThemeTokens::colour(const juce::String& token, juce::Colour fallback) const {
    auto hex = [](const juce::String& h) {
        return juce::Colour::fromString(h.startsWith("#") ? "ff" + h.substring(1) : h);
    };
    if (token == "window") return hex(window);
    if (token == "panel") return hex(panel);
    if (token == "surface") return hex(surface);
    if (token == "textPrimary") return hex(textPrimary);
    if (token == "textSecondary") return hex(textSecondary);
    if (token == "textDisabled") return hex(textDisabled);
    if (token == "lcdBg") return hex(lcdBg);
    if (token == "lcdText") return hex(lcdText);
    if (token == "accent") return hex(accent);
    if (token == "accent2") return hex(accent2);
    if (token == "meter") return hex(meter);
    if (token == "warning") return hex(warning);
    if (token == "bezel") return hex(bezel);
    if (token == "knobArc") return hex(knobArc);
    if (token == "knobBody") return hex(knobBody);
    if (token == "buttonBg") return hex(buttonBg);
    if (token == "buttonText") return hex(buttonText);
    if (token == "buttonActive") return hex(buttonActive);
    if (token == "headerBg") return hex(headerBg);
    if (token == "shadow") return hex(shadow);
    if (token == "highlight") return hex(highlight);
    return fallback;
}

ThemeManager::ThemeManager() : current(fallbackTokens()), currentId_(fallbackThemeId()) {}

bool ThemeManager::validateManifestJson(const juce::var& json, juce::String& error,
                                        bool requireAssets) {
    if (!json.isObject()) { error = "manifest is not an object"; return false; }
    auto* o = json.getDynamicObject();
    if (o == nullptr) { error = "manifest has no properties"; return false; }

    auto id    = o->getProperty("id").toString();
    auto idxV  = o->getProperty("index");
    auto name  = o->getProperty("name").toString();
    auto pal   = o->getProperty("palette");
    if (id.isEmpty() || name.isEmpty()) { error = "missing id or name"; return false; }
    if (!idxV.isInt()) { error = "missing integer index"; return false; }
    int index = int(idxV);
    if (index < 1 || index > 52) { error = "index out of range 1..52"; return false; }
    if (!pal.isObject()) { error = "missing palette object"; return false; }

    auto* po = pal.getDynamicObject();
    int tokenCount = 0;
    for (auto t : kTokenNames)
        if (po->hasProperty(t) && po->getProperty(t).toString().startsWith("#")) ++tokenCount;
    if (tokenCount != kTokenCount) {
        error = juce::String::formatted("palette tokens: %d of 21", tokenCount);
        return false;
    }

    auto ctrl = o->getProperty("controlLayout");
    if (!ctrl.isObject()) { error = "missing controlLayout"; return false; }
    auto* co = ctrl.getDynamicObject();
    for (auto c : kControlIds)
        if (!co->hasProperty(c)) {
            error = juce::String::formatted("missing control id %s", c);
            return false;
        }
    if (requireAssets) {
        auto assets = o->getProperty("assets");
        if (!assets.isObject()) { error = "missing assets"; return false; }
    }
    return true;
}

void ThemeManager::scan(const juce::File& skinsRoot) {
    themes.clear();
    if (!skinsRoot.isDirectory()) return;
    auto dirs = skinsRoot.findChildFiles(juce::File::findDirectories, false, "Skin_*");
    for (auto& d : dirs) {
        auto mf = d.getChildFile("theme.json");
        if (!mf.existsAsFile()) continue;
        auto parsed = juce::JSON::parse(mf);
        ThemeInfo info;
        info.manifestFile = mf;
        if (auto* o = parsed.getDynamicObject()) {
            info.id = o->getProperty("id").toString();
            info.index = int(o->getProperty("index"));
            info.name = o->getProperty("name").toString();
            info.family = o->getProperty("family").toString();
            info.layout = o->getProperty("layout").toString();
            juce::String err;
            info.valid = validateManifestJson(parsed, err, false);
        }
        if (info.valid) themes.push_back(info);
    }
    std::sort(themes.begin(), themes.end(),
              [](const ThemeInfo& a, const ThemeInfo& b) { return a.index < b.index; });
}

juce::StringArray ThemeManager::themeIds() const {
    juce::StringArray out;
    for (auto& t : themes) out.add(t.id);
    return out;
}

bool ThemeManager::hasTheme(const juce::String& id) const {
    for (auto& t : themes) if (t.id == id) return true;
    return id == fallbackThemeId();
}

bool ThemeManager::loadTheme(const juce::String& id) {
    for (auto& t : themes) {
        if (t.id != id) continue;
        auto parsed = juce::JSON::parse(t.manifestFile);
        auto* o = parsed.getDynamicObject();
        if (o == nullptr) return false;
        auto* po = o->getProperty("palette").getDynamicObject();
        if (po == nullptr) return false;
        auto& T = current;
        T.window = po->getProperty("window").toString();
        T.panel = po->getProperty("panel").toString();
        T.surface = po->getProperty("surface").toString();
        T.textPrimary = po->getProperty("textPrimary").toString();
        T.textSecondary = po->getProperty("textSecondary").toString();
        T.textDisabled = po->getProperty("textDisabled").toString();
        T.lcdBg = po->getProperty("lcdBg").toString();
        T.lcdText = po->getProperty("lcdText").toString();
        T.accent = po->getProperty("accent").toString();
        T.accent2 = po->getProperty("accent2").toString();
        T.meter = po->getProperty("meter").toString();
        T.warning = po->getProperty("warning").toString();
        T.bezel = po->getProperty("bezel").toString();
        T.knobArc = po->getProperty("knobArc").toString();
        T.knobBody = po->getProperty("knobBody").toString();
        T.buttonBg = po->getProperty("buttonBg").toString();
        T.buttonText = po->getProperty("buttonText").toString();
        T.buttonActive = po->getProperty("buttonActive").toString();
        T.headerBg = po->getProperty("headerBg").toString();
        T.shadow = po->getProperty("shadow").toString();
        T.highlight = po->getProperty("highlight").toString();
        currentId_ = id;
        return true;
    }
    return id == fallbackThemeId(); // fallback is always loadable
}

} // namespace ppgu
