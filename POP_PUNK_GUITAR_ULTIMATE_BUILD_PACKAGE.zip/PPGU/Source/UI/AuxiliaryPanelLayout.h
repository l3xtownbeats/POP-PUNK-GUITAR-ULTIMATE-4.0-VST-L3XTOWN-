#pragma once
// PPGU auxiliary panel geometry - pure C++20, no JUCE, no window ownership.
// Deterministic tile/compact/overflow layout over a work area with DPI scale.
#include <cstdint>
#include <vector>

namespace ppgu {

enum class PanelId : int { AmpTone = 0, FxChain, Playback, Count };

struct Rect { int x = 0, y = 0, w = 0, h = 0; };

struct PanelPlacement {
    PanelId id;
    Rect rect;
    bool compact = false;
    bool visible = true;
};

struct LayoutResult {
    std::vector<PanelPlacement> panels;
    bool overflow = false;      // not all fit even at minimum size -> paging
    bool compact = false;       // at least one panel below desired size
    bool invalidInput = false;  // bad work area / sizes / duplicate ids
};

class AuxiliaryPanelLayout {
public:
    struct PanelSize { int desiredW, desiredH, minW, minH; };

    static LayoutResult computeTiled(const std::vector<PanelId>& ids,
                                     int workX, int workY, int workW, int workH,
                                     double dpiScale,
                                     const PanelSize& desired,
                                     const PanelSize& minimum,
                                     int gap = 12);
};

} // namespace ppgu
