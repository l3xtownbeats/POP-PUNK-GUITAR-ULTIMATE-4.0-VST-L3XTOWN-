#pragma once
// PPGU independent auxiliary panel window shell (top-level DocumentWindow).
#include <JuceHeader.h>
#include "AuxiliaryPanelLayout.h"

namespace ppgu {

class AuxiliaryPanelWindow : public juce::DocumentWindow {
public:
    AuxiliaryPanelWindow(PanelId id, const juce::String& title,
                         std::unique_ptr<juce::Component> content);
    ~AuxiliaryPanelWindow() override;

    PanelId panelId() const { return pid; }
    void saveState(juce::PropertiesFile& props) const;
    static void restoreState(juce::PropertiesFile& props, PanelId id,
                             AuxiliaryPanelWindow* w);
    void closeButtonPressed() override;
    void maximiseButtonPressed() override;
    bool wasClosedByUser() const { return closedByUser; }
private:
    PanelId pid;
    bool closedByUser = false;
    juce::Rectangle<int> restoredBounds;
};

// Owns all open panels; guarantees audio/APVTS/MIDI independence (UI-only).
class AuxiliaryPanelManager : public juce::Component::Listener {
public:
    AuxiliaryPanelManager(juce::Component& hostRoot);
    ~AuxiliaryPanelManager() override;

    void open(PanelId id, std::unique_ptr<juce::Component> content, const juce::String& title);
    void close(PanelId id);
    bool isOpen(PanelId id) const;
    void tileAll();     // auto-arrange all open panels over the screen work area
private:
    void componentVisibilityChanged(juce::Component&) override;
    juce::Component& host;
    std::map<PanelId, std::unique_ptr<AuxiliaryPanelWindow>> openPanels;
};

} // namespace ppgu
