#pragma once
// PPGU auxiliary panels: AMP & TONE / FX CHAIN / PLAYBACK. APVTS-bound, UI-only.
#include <JuceHeader.h>
#include "ThemeManager.h"

namespace ppgu {

class ThemedPanelBase : public juce::Component {
public:
    explicit ThemedPanelBase(const ThemeManager& tm, const juce::String& title);
    void paint(juce::Graphics& g) override;
protected:
    const ThemeManager& themes;
    juce::String title;
};

class AmpTonePanel : public ThemedPanelBase {
public:
    AmpTonePanel(const ThemeManager& tm, juce::AudioProcessorValueTreeState& s);
    void resized() override;
private:
    juce::Slider amp, eqL, eqM, eqH;
    juce::Label ampL{ {}, "AMP GAIN" }, eqLL{ {}, "EQ LOW" },
               eqML{ {}, "EQ MID" }, eqHL{ {}, "EQ HIGH" };
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> att;
};

class FxChainPanel : public ThemedPanelBase {
public:
    FxChainPanel(const ThemeManager& tm, juce::AudioProcessorValueTreeState& s);
    void resized() override;
private:
    juce::ToggleButton dist, chor, dly, rev, cmp, lim, cab;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> att;
};

class PlaybackPanel : public ThemedPanelBase {
public:
    PlaybackPanel(const ThemeManager& tm, juce::AudioProcessorValueTreeState& s);
    void resized() override;
private:
    juce::Slider vel, dyn, sw, hum, acc;
    juce::Label velL{ {}, "VELOCITY" }, dynL{ {}, "DYNAMICS" }, swL{ {}, "SWING" },
               humL{ {}, "HUMANIZE" }, accL{ {}, "ACCENT" };
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> att;
};

} // namespace ppgu
