#include "Panels.h"

namespace ppgu {

ThemedPanelBase::ThemedPanelBase(const ThemeManager& tm, const juce::String& t)
    : themes(tm), title(t) {}

void ThemedPanelBase::paint(juce::Graphics& g) {
    auto& T = themes.tokens();
    g.fillAll(T.colour("panel", juce::Colour(0xff1d1d20)));
    g.setColour(T.colour("headerBg", juce::Colour(0xff191921)));
    g.fillRect(0, 0, getWidth(), 36);
    g.setColour(T.colour("textPrimary", juce::Colours::white));
    g.setFont(juce::FontOptions(16.0f, juce::Font::bold));
    g.drawText(title, 12, 6, getWidth() - 24, 24, juce::Justification::left);
    g.setColour(T.colour("accent", juce::Colour(0xffb6f24d)));
    g.drawRect(getLocalBounds().reduced(1), 1);
}

AmpTonePanel::AmpTonePanel(const ThemeManager& tm, juce::AudioProcessorValueTreeState& s)
    : ThemedPanelBase(tm, "AMP & TONE") {
    auto add = [&](juce::Slider& sl, juce::Label& lb, const char* id) {
        addAndMakeVisible(sl); addAndMakeVisible(lb);
        sl.setSliderStyle(juce::Slider::RotaryVerticalDrag);
        sl.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 70, 18);
        att.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(s, id, sl));
    };
    add(amp, ampL, "ampGain");
    add(eqL, eqLL, "eqLow");
    add(eqM, eqML, "eqMid");
    add(eqH, eqHL, "eqHigh");
    setSize(560, 240);
}
void AmpTonePanel::resized() {
    auto a = getLocalBounds().removeFromBottom(getHeight() - 40).reduced(10);
    auto w = a.getWidth() / 4;
    amp.setBounds(a.removeFromLeft(w)); eqL.setBounds(a.removeFromLeft(w));
    eqM.setBounds(a.removeFromLeft(w)); eqH.setBounds(a.removeFromLeft(w));
    ampL.setBounds(amp.getBounds().removeFromBottom(20));
    eqLL.setBounds(eqL.getBounds().removeFromBottom(20));
    eqML.setBounds(eqM.getBounds().removeFromBottom(20));
    eqHL.setBounds(eqH.getBounds().removeFromBottom(20));
}

FxChainPanel::FxChainPanel(const ThemeManager& tm, juce::AudioProcessorValueTreeState& s)
    : ThemedPanelBase(tm, "FX CHAIN") {
    auto add = [&](juce::ToggleButton& b, const char* id, const char* label) {
        addAndMakeVisible(b); b.setButtonText(label);
        att.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(s, id, b));
    };
    add(dist, "fxDistortion", "DISTORTION");
    add(chor, "fxChorus", "CHORUS");
    add(dly,  "fxDelay", "DELAY");
    add(rev,  "fxReverb", "REVERB");
    add(cmp,  "fxCompressor", "COMP");
    add(lim,  "fxLimiter", "LIMITER");
    add(cab,  "fxCabSim", "CAB SIM");
    setSize(420, 300);
}
void FxChainPanel::resized() {
    auto a = getLocalBounds().removeFromBottom(getHeight() - 40).reduced(10);
    for (juce::ToggleButton* b : { &dist, &chor, &dly, &rev, &cmp, &lim, &cab })
        b->setBounds(a.removeFromLeft(a.getWidth() / 7).reduced(4));
}

PlaybackPanel::PlaybackPanel(const ThemeManager& tm, juce::AudioProcessorValueTreeState& s)
    : ThemedPanelBase(tm, "PLAYBACK") {
    auto add = [&](juce::Slider& sl, juce::Label& lb, const char* id) {
        addAndMakeVisible(sl); addAndMakeVisible(lb);
        sl.setSliderStyle(juce::Slider::RotaryVerticalDrag);
        sl.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 70, 18);
        att.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(s, id, sl));
    };
    add(vel, velL, "velocity");
    add(dyn, dynL, "dynamics");
    add(sw,  swL,  "swing");
    add(hum, humL, "humanize");
    add(acc, accL, "accent");
    setSize(620, 240);
}
void PlaybackPanel::resized() {
    auto a = getLocalBounds().removeFromBottom(getHeight() - 40).reduced(10);
    auto w = a.getWidth() / 5;
    vel.setBounds(a.removeFromLeft(w)); dyn.setBounds(a.removeFromLeft(w));
    sw.setBounds(a.removeFromLeft(w)); hum.setBounds(a.removeFromLeft(w));
    acc.setBounds(a.removeFromLeft(w));
    velL.setBounds(vel.getBounds().removeFromBottom(20));
    dynL.setBounds(dyn.getBounds().removeFromBottom(20));
    swL.setBounds(sw.getBounds().removeFromBottom(20));
    humL.setBounds(hum.getBounds().removeFromBottom(20));
    accL.setBounds(acc.getBounds().removeFromBottom(20));
}

} // namespace ppgu
