#pragma once
// PPGU theme manager: scans sibling "Skins" directory next to the .vst3 bundle,
// validates 21-token manifests + 27 control parity, applies palettes at runtime.
#include <JuceHeader.h>

namespace ppgu {

struct ThemeTokens {
    // 21 palette tokens
    juce::String window, panel, surface, textPrimary, textSecondary, textDisabled,
                 lcdBg, lcdText, accent, accent2, meter, warning, bezel,
                 knobArc, knobBody, buttonBg, buttonText, buttonActive,
                 headerBg, shadow, highlight;
    juce::Colour colour(const juce::String& token, juce::Colour fallback) const;
};

struct ThemeInfo {
    juce::String id;
    int index = 0;
    juce::String name, family, layout;
    juce::File manifestFile;
    bool valid = false;
};

class ThemeManager {
public:
    static constexpr int kTokenCount = 21;
    static const char* const kTokenNames[kTokenCount];
    static const char* const kControlIds[27];

    ThemeManager();

    // Scans Skins/ manifests; fallback = built-in Blackout Voltage (skin-052...).
    void scan(const juce::File& skinsRoot);
    int  themeCount() const { return int(themes.size()); }
    juce::StringArray themeIds() const;
    bool hasTheme(const juce::String& id) const;
    bool loadTheme(const juce::String& id);       // hot-swap; returns validity
    const ThemeTokens& tokens() const { return current; }
    juce::String currentId() const { return currentId_; }

    // Manifest validation shared with tools/validate_skin_manifests.py
    static bool validateManifestJson(const juce::var& json, juce::String& error,
                                     bool requireAssets = true);

    // Built-in fallback palette (always available, satisfies audio-invariance).
    static ThemeTokens fallbackTokens();
    static const char* fallbackThemeId() { return "skin-052"; }
private:
    std::vector<ThemeInfo> themes;
    ThemeTokens current;
    juce::String currentId_;
};

} // namespace ppgu
