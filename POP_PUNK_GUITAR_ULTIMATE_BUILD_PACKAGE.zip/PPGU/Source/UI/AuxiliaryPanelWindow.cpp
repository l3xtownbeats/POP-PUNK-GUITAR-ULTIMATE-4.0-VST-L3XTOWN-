#include "AuxiliaryPanelWindow.h"

namespace ppgu {

AuxiliaryPanelWindow::AuxiliaryPanelWindow(PanelId id, const juce::String& title,
                                           std::unique_ptr<juce::Component> content)
    : DocumentWindow(title, juce::Colour(0xff1d1d20), DocumentWindow::allButtons, true),
      pid(id) {
    setUsingNativeTitleBar(true);
    setResizable(true, false);
    if (content) {
        content_ = std::move(content);
        setContentNonOwned(content_.get(), true);
    }
    setBounds(80, 80, 640, 420);
    setVisible(true);
}

AuxiliaryPanelWindow::~AuxiliaryPanelWindow() = default;

void AuxiliaryPanelWindow::closeButtonPressed() {
    closedByUser = true;
    // Content is retained by the owner (manager) so state survives close/reopen.
    setVisible(false);
}

void AuxiliaryPanelWindow::maximiseButtonPressed() {
    if (isFullScreen()) setFullScreen(false);
    else setFullScreen(true);
}

void AuxiliaryPanelWindow::saveState(juce::PropertiesFile& props) const {
    auto b = getBounds();
    props.setValue("panel." + juce::String(int(pid)) + ".bounds",
                   juce::String(b.getX()) + "," + juce::String(b.getY()) + ","
                   + juce::String(b.getWidth()) + "," + juce::String(b.getHeight()));
}

void AuxiliaryPanelWindow::restoreState(juce::PropertiesFile& props, PanelId id,
                                        AuxiliaryPanelWindow* w) {
    auto v = props.getValue("panel." + juce::String(int(id)) + ".bounds");
    if (v.isEmpty() || w == nullptr) return;
    auto parts = juce::StringArray::fromTokens(v, ",", "");
    if (parts.size() == 4)
        w->setBounds(parts[0].getIntValue(), parts[1].getIntValue(),
                     parts[2].getIntValue(), parts[3].getIntValue());
}

AuxiliaryPanelManager::AuxiliaryPanelManager(juce::Component& h) : host(h) {
    host.addComponentListener(this);
}
AuxiliaryPanelManager::~AuxiliaryPanelManager() {
    host.removeComponentListener(this);
    openPanels.clear(); // windows destroyed after host teardown
}

void AuxiliaryPanelManager::open(PanelId id, std::unique_ptr<juce::Component> content,
                                 const juce::String& title) {
    auto& w = openPanels[id];
    if (w == nullptr)
        w = std::make_unique<AuxiliaryPanelWindow>(id, title, std::move(content));
    w->setVisible(true);
    w->toFront(true);
    tileAll();
}

void AuxiliaryPanelManager::close(PanelId id) {
    auto it = openPanels.find(id);
    if (it == openPanels.end()) return;
    it->second->closeButtonPressed();
}

bool AuxiliaryPanelManager::isOpen(PanelId id) const {
    auto it = openPanels.find(id);
    return it != openPanels.end() && it->second->isVisible();
}

void AuxiliaryPanelManager::tileAll() {
    std::vector<PanelId> ids;
    for (auto& [id, w] : openPanels)
        if (w->isVisible()) ids.push_back(id);
    if (ids.empty()) return;
    auto wa = juce::Desktop::getInstance()
                  .getDisplays().getPrimaryDisplay()->userArea;
    AuxiliaryPanelLayout::PanelSize desired{ 640, 420, 380, 260 };
    auto res = AuxiliaryPanelLayout::computeTiled(ids, wa.getX(), wa.getY(),
                                                  wa.getWidth(), wa.getHeight(),
                                                  double(juce::Desktop::getInstance().getGlobalScaleFactor()),
                                                  desired, { 380, 260, 260, 180 });
    if (res.invalidInput) return;
    size_t i = 0;
    for (auto& [id, w] : openPanels) {
        if (!w->isVisible() || i >= res.panels.size()) continue;
        auto& p = res.panels[i++];
        w->setBounds(p.rect.x, p.rect.y, p.rect.w, p.rect.h);
    }
}

void AuxiliaryPanelManager::componentVisibilityChanged(juce::Component&) { /* host teardown hook */ }

} // namespace ppgu
