#include "AuxiliaryPanelLayout.h"
#include <algorithm>
#include <cmath>
#include <set>
#include <limits>

namespace ppgu {

LayoutResult AuxiliaryPanelLayout::computeTiled(const std::vector<PanelId>& ids,
                                                int workX, int workY,
                                                int workW, int workH,
                                                double dpiScale,
                                                const PanelSize& desired,
                                                const PanelSize& minimum,
                                                int gap) {
    LayoutResult r;
    if (ids.empty()) return r;

    // --- input validation ---
    std::set<int> seen;
    for (auto id : ids) {
        if (!seen.insert(int(id)).second) { r.invalidInput = true; return r; }
    }
    if (workW <= 0 || workH <= 0 || workX + int64_t(workW) > int64_t(1) << 40
        || workY + int64_t(workH) > int64_t(1) << 40) {
        r.invalidInput = true; return r;
    }
    if (desired.desiredW <= 0 || desired.desiredH <= 0 || minimum.minW <= 0 || minimum.minH <= 0
        || minimum.minW > desired.desiredW || minimum.minH > desired.desiredH) {
        r.invalidInput = true; return r;
    }
    if (!(dpiScale > 0.0) || !std::isfinite(dpiScale)) dpiScale = 1.0;

    if (gap < 0) gap = 0;
    int g = int(std::min<int64_t>(int64_t(gap), int64_t(1) << 30));

    auto scaled = [dpiScale](int v) -> int {
        double s = v * dpiScale;
        return int(std::min<double>(std::max(1.0, s), 1.0e9));
    };
    int dw = scaled(desired.desiredW), dh = scaled(desired.desiredH);
    int mw = scaled(minimum.minW),       mh = scaled(minimum.minH);

    int n = int(ids.size());
    int availW = workW - std::min(workW, g * (n - 1));
    int availH = workH - std::min(workH, g * (n - 1));
    if (availW <= 0 || availH <= 0) { r.invalidInput = true; return r; }

    // Choose grid: prefer single row; wrap when width insufficient.
    int cols = n, rows = 1;
    int cellW = (availW - g * (cols - 1)) / cols;
    if (cellW < mw || cols > 4) {
        // try 2x2 and portrait stacks
        if (n <= 4) { cols = 2; rows = (n + 1) / 2; }
        else        { cols = 2; rows = (n + 1) / 2; }
    }
    int cellH = (availH - g * (rows - 1)) / rows;
    if (cellW < mw || cellH < mh) {
        // overflow: single visible page
        r.overflow = true;
        cols = 1; rows = 1;
        cellW = std::min(availW, dw); cellH = std::min(availH, dh);
    }
    if (cellW < dw || cellH < dh) r.compact = true;

    for (int i = 0; i < n; ++i) {
        int col = i % cols, row = i / cols;
        PanelPlacement p;
        p.id = ids[size_t(i)];
        p.rect = { workX + col * (cellW + g),
                   workY + row * (cellH + g),
                   cellW, cellH };
        p.compact = r.compact;
        p.visible = !(r.overflow && i > 0);
        r.panels.push_back(p);
    }
    return r;
}

} // namespace ppgu
