#pragma once
// PPGU pattern scheduler - pure deterministic logic, no JUCE, no audio thread state.
#include <cstdint>
#include <vector>

namespace ppgu {

enum class PlayMode : int { Melody = 0, Pattern = 1 };

struct PatternParams {
    double bpm = 120.0;          // 20..999 clamped
    int stepsPerBar = 16;        // 16th notes
    float swing = 0.0f;          // 0..1  (delay every odd 16th)
    float humanize = 0.0f;       // 0..1  (timing jitter + velocity jitter)
    float accent = 0.75f;        // 0..1  (accent amount on strong steps)
    float velocityScale = 1.0f;  // 0..2
    uint32_t seed = 20261112u;   // deterministic per preset id
};

struct ScheduledNote {
    int step = 0;        // 0..stepsPerBar-1
    int key = 0;         // MIDI note 0..127
    int velocity = 100;  // 1..127 (already includes humanize/accent)
};

class PatternScheduler {
public:
    // Deterministic pop-punk pattern: power-chord roots on 8ths, palm-mute
    // chugs on the 'and', accents on downbeats of bars 1 and 3.
    static std::vector<ScheduledNote> buildPattern(const PatternParams& p);

    // Transport pump: returns notes scheduled between sample positions.
    // ppqPos: current position in quarter notes; samplesPerBlock for lookahead.
    struct Pump { std::vector<ScheduledNote> notes; };
    static Pump pumpNotes(const PatternParams& p,
                          double ppqPosStart, double ppqPosEnd,
                          int rootKey = 40, // E2
                          const std::vector<int>& chordDegrees = {0, 7, 12});

    // humanize/accent/velocity resolve for a raw step
    static int resolveVelocity(const PatternParams& p, int step, uint32_t rngState);
    static double stepOffsetSamples(const PatternParams& p, int step,
                                   double sampleRate, double ppq,
                                   uint32_t rngState);
};

} // namespace ppgu
