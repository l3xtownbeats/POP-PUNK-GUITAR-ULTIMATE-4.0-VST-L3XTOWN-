#include "PatternScheduler.h"
#include <cmath>
#include <algorithm>

namespace ppgu {

static uint32_t lcg(uint32_t& s) {
    s = s * 1664525u + 1013904223u;
    return s >> 8;
}

static float clamp01(float v) { return std::min(1.0f, std::max(0.0f, v)); }

int PatternScheduler::resolveVelocity(const PatternParams& p, int step, uint32_t rngState) {
    // base groove: eighth-note feel, stronger on downbeats
    int base = (step % 2 == 0) ? 104 : 82;
    bool strong = (step % 8 == 0) || (step % 16 == 4);
    if (strong) base = 118;
    float acc = clamp01(p.accent);
    if (strong) base = int(base + 9.0f * acc);
    if (step % 2 == 1) base = int(base - 6.0f * acc);

    float hum = clamp01(p.humanize);
    if (hum > 0.0f) {
        uint32_t r = lcg(rngState) % 2001u;
        float jitter = (float(r) - 1000.0f) / 1000.0f; // -1..1
        base += int(jitter * 14.0f * hum);
    }
    base = int(float(base) * clamp01(p.velocityScale) );
    return std::min(127, std::max(1, base));
}

double PatternScheduler::stepOffsetSamples(const PatternParams& p, int step,
                                           double sampleRate, double ppq,
                                           uint32_t rngState) {
    double offset = 0.0;
    float sw = clamp01(p.swing);
    if (sw > 0.0f && (step % 2 == 1))
        offset += (ppq * 0.5) * (sw * 0.5); // up to a 16th triplet feel
    float hum = clamp01(p.humanize);
    if (hum > 0.0f) {
        uint32_t r = lcg(rngState) % 2001u;
        float jit = (float(r) - 1000.0f) / 1000.0f;
        offset += double(jit) * (ppq * 0.03) * hum; // +-3% of a 16th
    }
    return offset * (sampleRate * 60.0 / std::max(1.0, p.bpm));
}

std::vector<ScheduledNote> PatternScheduler::buildPattern(const PatternParams& p) {
    std::vector<ScheduledNote> out;
    const int steps = std::max(1, p.stepsPerBar);
    // groove map: root chugs on 8ths, open accents on 1 and 3(+) of each half
    static const int grooveRootSteps[]  = {0, 2, 4, 6, 8, 10, 12, 14};
    static const int grooveChugSteps[]  = {1, 3, 5, 7, 9, 11, 13, 15};
    for (int s : grooveRootSteps) {
        if (s >= steps) break;
        ScheduledNote n; n.step = s; n.key = 40; // E2 root
        n.velocity = resolveVelocity(p, s, p.seed + uint32_t(s));
        out.push_back(n);
    }
    for (int s : grooveChugSteps) {
        if (s >= steps) break;
        ScheduledNote n; n.step = s; n.key = 40; // palm-mute chug (engine maps low vel band)
        n.velocity = resolveVelocity(p, s, p.seed + 77u + uint32_t(s));
        out.push_back(n);
    }
    std::sort(out.begin(), out.end(),
              [](const ScheduledNote& a, const ScheduledNote& b) { return a.step < b.step; });
    return out;
}

PatternScheduler::Pump PatternScheduler::pumpNotes(const PatternParams& p,
                                                   double ppqStart, double ppqEnd,
                                                   int rootKey,
                                                   const std::vector<int>& chordDegrees) {
    Pump result;
    if (ppqEnd <= ppqStart || p.bpm <= 0.0) return result;
    const double ppq = 4.0; // 16 sixteenths per bar
    long startStep = long(std::floor(ppqStart / ppq * double(p.stepsPerBar)));
    long endStep   = long(std::ceil (ppqEnd   / ppq * double(p.stepsPerBar)));
    auto pattern = buildPattern(p);
    if (pattern.empty()) return result;
    for (long s = startStep; s < endStep; ++s) {
        int idx = int(s % p.stepsPerBar);
        for (const auto& n : pattern) {
            if (n.step != idx) continue;
            ScheduledNote out = n;
            // chord-following: alternate root/fifth/octave per quarter
            if (!chordDegrees.empty()) {
                int deg = chordDegrees[size_t(s / 4) % chordDegrees.size()];
                out.key = std::min(127, std::max(0, rootKey + deg));
            }
            result.notes.push_back(out);
        }
    }
    return result;
}

} // namespace ppgu
