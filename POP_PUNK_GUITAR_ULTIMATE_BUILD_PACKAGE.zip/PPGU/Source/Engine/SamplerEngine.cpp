#include "SamplerEngine.h"
#include <algorithm>
#include <cmath>

namespace ppgu {

void SamplerEngine::prepare(double sr, int) {
    sampleRate = sr > 0.0 ? sr : 44100.0;
}

void SamplerEngine::reset() {
    for (auto& v : voices) v = Voice{};
}

juce::String SamplerEngine::lastError() const {
    std::lock_guard<std::mutex> lk(errorMutex);
    return loadError;
}

void SamplerEngine::stopLoader() {
    loaderRunning.store(false);
    if (loader.joinable()) loader.join();
}

float SamplerEngine::velocityToGain(int velocity) {
    // factory mapping: 0-25 palm mute, 26-50 power chord, 51-100 open chord,
    // 101-127 single note (see SOUNDBANK/factory.sfz)
    return 1.0f;
}

bool SamplerEngine::loadSfzAsync(const juce::File& sfzFile, juce::String& error) {
    stopLoader();
    bankReady.store(false);
    auto docPath = sfzFile.getFullPathName().toStdString();
    auto doc = SfzParser::parseFile(docPath);
    if (!doc.valid) {
        std::lock_guard<std::mutex> lk(errorMutex);
        loadError = juce::String(doc.error);
        error = loadError;
        return false;
    }

    auto* threadData = new SfzDocument(std::move(doc));
    auto* parentDir = new juce::File(sfzFile.getParentDirectory());
    loaderRunning.store(true);
    loader = std::thread([this, threadData, parentDir]() {
        std::unique_ptr<SfzDocument> doc(threadData);
        std::unique_ptr<juce::File> dir(parentDir);
        auto newBank = std::make_shared<Bank>();
        juce::AudioFormatManager fmt;
        fmt.registerBasicFormats();

        for (auto& g : doc->groups) {
            for (auto& r : g.regions) {
                if (!loaderRunning.load()) return;
                auto f = dir->getChildFile(juce::String(r.sample));
                std::unique_ptr<juce::AudioFormatReader> rd(fmt.createReaderFor(f));
                if (rd == nullptr) continue;
                auto buf = std::make_shared<SampleBuffer>();
                buf->sampleRate = int(rd->sampleRate);
                juce::AudioBuffer<float> tmp;
                rd->read(&tmp, 0, int(rd->lengthInSamples));
                auto n = tmp.getNumSamples();
                buf->dataL.resize(size_t(n));
                if (tmp.getNumChannels() > 1) buf->dataR.resize(size_t(n));
                for (int i = 0; i < n; ++i) {
                    buf->dataL[size_t(i)] = tmp.getSample(0, i);
                    if (!buf->dataR.empty()) buf->dataR[size_t(i)] = tmp.getSample(1, i);
                }
                Region reg;
                reg.sampleIndex = int(newBank->samples.size());
                reg.loKey = r.loKey; reg.hiKey = r.hiKey;
                reg.loVel = r.loVel; reg.hiVel = r.hiVel;
                reg.seqLength = r.seqLength; reg.seqPosition = r.seqPosition;
                reg.looping = r.loopMode == 1;
                if (r.loopStart >= 0 && r.loopEnd > r.loopStart) {
                    reg.loopStart = int(r.loopStart);
                    reg.loopEnd = int(r.loopEnd);
                }
                reg.gain = r.gain;
                newBank->samples.push_back(*buf);
                newBank->regions.push_back(reg);
            }
        }
        if (!loaderRunning.load()) return;
        // Atomic publication: audio thread acquires the new immutable Bank.
        published.store(newBank, std::memory_order_release);
        bankReady.store(true, std::memory_order_release);
    });
    return true;
}

void SamplerEngine::startVoice(int note, int velocity) {
    auto b = published.load(std::memory_order_acquire);
    if (b == nullptr) return;
    // RR rotation
    static std::atomic<uint32_t> rr{ 0 };
    uint32_t slot = rr.fetch_add(1) % 5u;
    int best = -1;
    for (int i = 0; i < int(b->regions.size()); ++i) {
        const auto& r = b->regions[size_t(i)];
        if (note < r.loKey || note > r.hiKey) continue;
        if (velocity < r.loVel || velocity > r.hiVel) continue;
        if (r.seqLength <= 1 || (uint32_t(r.seqPosition - 1) == slot)) { best = i; break; }
    }
    if (best < 0) return;
    for (auto& v : voices) {
        if (!v.active) {
            v.active = true; v.region = best; v.note = note;
            v.pos = 0.0;
            v.velocityGain = velocityToGain(velocity);
            return;
        }
    }
    // voice stealing: replace oldest (first) voice
    voices[0] = Voice{ true, best, note, 0, 0.0, velocityToGain(velocity), false };
}

void SamplerEngine::noteOn(int, int note, int velocity) {
    startVoice(note, velocity);
}

void SamplerEngine::noteOff(int, int note) {
    for (auto& v : voices)
        if (v.active && v.note == note) v.active = false;
}

void SamplerEngine::allNotesOff() { reset(); }

int SamplerEngine::activeVoiceCount() const {
    int n = 0;
    for (auto& v : voices) if (v.active) ++n;
    return n;
}

void SamplerEngine::render(float* outL, float* outR, int numSamples) {
    auto b = published.load(std::memory_order_acquire);
    if (b == nullptr) return;
    const double srRatio = sampleRate / double(b->samples.empty() ? 44100 : b->samples[0].sampleRate);
    for (auto& v : voices) {
        if (!v.active) continue;
        const Region& r = b->regions[size_t(v.region)];
        const SampleBuffer& s = b->samples[size_t(r.sampleIndex)];
        const size_t n = s.dataL.size();
        if (n == 0) { v.active = false; continue; }
        for (int i = 0; i < numSamples; ++i) {
            size_t idx = size_t(v.pos);
            if (idx >= n - 1) {
                if (r.looping && r.loopEnd > r.loopStart) { v.pos = r.loopStart; continue; }
                v.active = false; break;
            }
            float frac = float(v.pos - double(idx));
            float l = s.dataL[idx] + (s.dataL[idx + 1] - s.dataL[idx]) * frac;
            float rr = s.dataR.empty() ? l : s.dataR[idx] + (s.dataR[idx + 1] - s.dataR[idx]) * frac;
            float g = v.velocityGain * r.gain;
            outL[i] += l * g;
            outR[i] += rr * g;
            v.pos += srRatio;
        }
    }
}

} // namespace ppgu
