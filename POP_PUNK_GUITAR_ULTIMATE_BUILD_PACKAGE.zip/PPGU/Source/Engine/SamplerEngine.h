#pragma once
// PPGU sampler engine - 64 voice slots, RR selection, loop/one-shot,
// atomic bank publication (cache-miss never blocks audio thread).
#include <JuceHeader.h>
#include <atomic>
#include <memory>
#include <vector>
#include "SfzParser.h"

namespace ppgu {

class SamplerEngine {
public:
    static constexpr int kMaxVoices = 64;

    struct SampleBuffer {
        std::vector<float> dataL, dataR;
        int sampleRate = 44100;
    };

    struct Region {
        int sampleIndex = -1;
        int loKey = 0, hiKey = 127, loVel = 0, hiVel = 127;
        int seqLength = 1, seqPosition = 1;
        int loopStart = -1, loopEnd = -1;
        bool looping = false;
        float gain = 1.0f;
    };

    struct Bank {                       // immutable once published
        std::vector<SampleBuffer> samples;
        std::vector<Region> regions;
    };

    SamplerEngine() = default;
    ~SamplerEngine() { stopLoader(); }

    void prepare(double sampleRate, int maxBlock);
    void reset();

    // Non-blocking: parses SFZ synchronously (cheap), decodes WAVs on a
    // background thread, publishes a complete immutable Bank atomically.
    bool loadSfzAsync(const juce::File& sfzFile, juce::String& error);
    bool isBankReady() const { return bankReady.load(std::memory_order_acquire); }
    juce::String lastError() const;

    // Audio thread API - no locks, no allocations.
    void noteOn(int channel, int note, int velocity);
    void noteOff(int channel, int note);
    void allNotesOff();
    void render(float* outL, float* outR, int numSamples);
    int  activeVoiceCount() const;

private:
    struct Voice {
        bool active = false;
        int region = -1;
        int note = -1, channel = -1;
        double pos = 0.0;
        float velocityGain = 1.0f;
        int sustainHold = false;
    };
    void stopLoader();
    void startVoice(int note, int velocity);
    static float velocityToGain(int velocity); // SFZ-style velocity band mapping

    Voice voices[kMaxVoices];
    double sampleRate = 44100.0;
    std::atomic<std::shared_ptr<const Bank>> published{ nullptr };
    std::atomic<bool> bankReady{ false };
    juce::String loadError;
    std::thread loader;
    std::atomic<bool> loaderRunning{ false };
    std::mutex errorMutex;
};

} // namespace ppgu
