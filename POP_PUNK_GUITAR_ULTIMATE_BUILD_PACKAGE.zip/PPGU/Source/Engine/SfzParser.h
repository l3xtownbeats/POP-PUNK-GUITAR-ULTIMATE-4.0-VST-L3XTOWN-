#pragma once
// PPGU SFZ parser - pure C++20, no JUCE dependency (audio/UI independent).
#include <string>
#include <vector>
#include <unordered_map>

namespace ppgu {

struct SfzOpcode { std::string key; std::string value; };

struct SfzRegion {
    std::string sample;
    int loKey = 0, hiKey = 127;
    int loVel = 0, hiVel = 127;
    int seqLength = 1, seqPosition = 1;
    double offset = 0.0, loopStart = -1.0, loopEnd = -1.0;
    float gain = 1.0f, pitch = 0.0f;
    int loopMode = 0; // 0 = no_loop, 1 = loop
};

struct SfzGroup {
    SfzRegion base;                       // inherited defaults
    std::vector<SfzRegion> regions;
};

struct SfzDocument {
    std::vector<SfzGroup> groups;
    bool valid = false;
    std::string error;
};

class SfzParser {
public:
    static SfzDocument parse(const std::string& sfzText);
    static SfzDocument parseFile(const std::string& path); // returns doc; error set on failure
private:
    static void applyOpcode(SfzRegion& r, const SfzOpcode& op, bool inControl);
};

} // namespace ppgu
