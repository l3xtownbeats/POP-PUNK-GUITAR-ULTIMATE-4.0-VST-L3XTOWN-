#include "SfzParser.h"
#include <fstream>
#include <sstream>
#include <cmath>
#include <algorithm>

namespace ppgu {

static std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return {};
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static int toInt(const std::string& v, int dflt) {
    if (v.empty()) return dflt;
    try { return std::stoi(v); } catch (...) { return dflt; }
}

static float toFloat(const std::string& v, float dflt) {
    if (v.empty()) return dflt;
    try { return std::stof(v); } catch (...) { return dflt; }
}

void SfzParser::applyOpcode(SfzRegion& r, const SfzOpcode& op, bool inControl) {
    const std::string& k = op.key;
    const std::string& v = op.value;
    if (inControl) {
        if (k == "key") { r.loKey = r.hiKey = toInt(v, 60); return; }
    }
    if      (k == "sample")        r.sample = v;
    else if (k == "lokey")         r.loKey = toInt(v, r.loKey);
    else if (k == "hikey")         r.hiKey = toInt(v, r.hiKey);
    else if (k == "key")           { r.loKey = r.hiKey = toInt(v, 60); }
    else if (k == "lovel")         r.loVel = toInt(v, r.loVel);
    else if (k == "hivel")         r.hiVel = toInt(v, r.hiVel);
    else if (k == "seq_length")    r.seqLength = std::max(1, toInt(v, 1));
    else if (k == "seq_position")  r.seqPosition = std::max(1, toInt(v, 1));
    else if (k == "offset")        r.offset = toFloat(v, 0.0f);
    else if (k == "loop_start")    r.loopStart = toFloat(v, -1.0f);
    else if (k == "loop_end")      r.loopEnd = toFloat(v, -1.0f);
    else if (k == "loop_mode")     r.loopMode = (v == "loop" || v == "loop_continuous") ? 1 : 0;
    else if (k == "gain")          r.gain = toFloat(v, 1.0f);
    else if (k == "pitch_keycenter") { /* accepted, stored as center implicitly */ }
    // Unknown opcodes are tolerated (forward compatibility).
}

SfzDocument SfzParser::parse(const std::string& sfzText) {
    SfzDocument doc;
    SfzGroup current;
    bool haveGroup = false;
    bool inControl = false;
    std::istringstream in(sfzText);
    std::string line;
    while (std::getline(in, line)) {
        // strip comments
        auto hash = line.find('#');
        if (hash != std::string::npos) line = line.substr(0, hash);
        line = trim(line);
        if (line.empty()) continue;

        if (line.front() == '<' && line.back() == '>') {
            std::string tag = line.substr(1, line.size() - 2);
            if (tag == "control") { inControl = true; continue; }
            inControl = false;
            if (tag == "group") {
                if (haveGroup && !current.regions.empty()) doc.groups.push_back(current);
                current = SfzGroup{};
                haveGroup = true;
                continue;
            }
            if (tag == "region") {
                SfzRegion r = current.base;
                current.regions.push_back(r); // opcodes appended below
                continue;
            }
            continue;
        }

        // opcode line: key=value pairs separated by whitespace
        size_t pos = 0;
        while (pos < line.size()) {
            size_t eq = line.find('=', pos);
            if (eq == std::string::npos) break;
            size_t ks = line.find_last_of(" \t", eq);
            ks = (ks == std::string::npos || ks < pos) ? pos : ks + 1;
            std::string key = line.substr(ks, eq - ks);
            size_t vs = eq + 1;
            size_t ve = line.find_first_of(" \t", vs);
            if (ve == std::string::npos) ve = line.size();
            std::string val = line.substr(vs, ve - vs);
            pos = ve;
            if (!current.regions.empty())
                applyOpcode(current.regions.back(), {key, val}, inControl);
            else if (haveGroup)
                applyOpcode(current.base, {key, val}, inControl);
        }
    }
    if (haveGroup && !current.regions.empty()) doc.groups.push_back(current);
    for (auto& g : doc.groups)
        for (auto& r : g.regions)
            if (!r.sample.empty()) doc.valid = true;
    if (!doc.valid) doc.error = "no regions with sample opcodes found";
    return doc;
}

SfzDocument SfzParser::parseFile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return SfzDocument{ {}, false, "cannot open file: " + path };
    std::ostringstream ss; ss << f.rdbuf();
    SfzDocument d = parse(ss.str());
    if (d.valid) {
        // resolve relative sample paths against SFZ location
        std::string dir;
        size_t slash = path.find_last_of("/\\");
        if (slash != std::string::npos) dir = path.substr(0, slash + 1);
        for (auto& g : d.groups)
            for (auto& r : g.regions)
                if (!r.sample.empty() && r.sample.find(':') == std::string::npos
                    && r.sample.find('/') == std::string::npos
                    && r.sample.find('\\') == std::string::npos)
                    r.sample = dir + r.sample;
    }
    return d;
}

} // namespace ppgu
