PPGU SKIN PACK PREMIUM V2 — OPTIMIZED
=====================================
20 тем (Skin_053..072) + исправленный эталон SKIN-1 (SIGNAL FORGE / NEON).

Оптимизация по CPU/RAM:
  - PNG переквантованы в палитру <=128 цветов (preview <=40KB, hero <=120KB)
  - texture/bezel/crest — векторные SVG (масштабируются без роста RAM по DPI)
  - LRU-кэш: в памяти максимум 2 темы (активная + предыдущая для fade)
  - Lazy loading: декодируется только preview до применения темы
  - Кэш глоу-слоёв: путь строится один раз на resize, не на каждый paint()
  - ECO-режим: reduceInEco=true (глоу без блюра, fade 150ms -> мгновенный)
  - Ноль hardcoded HEX в UI: только token(name) из ThemeManager (RSK-02/03)
  - Аудио-поток никогда не читает assets/палитры (audio invariance)

Содержимое:
  Skins/Skin_053..Skin_072  — темы (theme.json 21 токен + assets)
  _reference/               — исправленный SKIN-1 (НЕ заменять вручную!)
  theme_pack_manifest.json  — манифест + perf-политика
  PERFORMANCE_BUDGET.md     — лимиты CPU/RAM и правила рендера
  ECO_POLICY.md             — политика экономии ресурсов
  VALIDATION_REPORT.txt     — контрасты WCAG (проверено кодом, все PASS)
  PERF_REPORT.txt           — фактические размеры ассетов по темам
  INSTALL.txt, CHANGELOG.txt

СТАТУС: PACK SPEC / NOT MERGED / NOT RUNTIME-INTEGRATED.
Merge только через tools/merge_skin_pack.py (с backup) + G1-G4 в CI.
Референсы стилистики палитр известных VST — не копирование интерфейсов.
