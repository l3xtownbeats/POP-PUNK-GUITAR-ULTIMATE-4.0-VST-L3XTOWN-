#pragma once
#include <JuceHeader.h>
#include "Engine/VoiceManager.h"
#include "Engine/PatternScheduler.h"
#include "Engine/FXChain.h"
#include "Engine/PresetManager.h"
#include "Engine/LibraryManager.h"
#include "Engine/MidiLearn.h"

class PpguAudioProcessor : public juce::AudioProcessor
{
public:
    PpguAudioProcessor();
    ~PpguAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "PPGU"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 4.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "PPGU"; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    juce::AudioProcessorValueTreeState apvts;
    ppgu::VoiceManager     voices;
    ppgu::FXChain          fx;
    ppgu::PatternScheduler scheduler;
    ppgu::ChordDetector    chords;
    ppgu::StyleEngine      style;
    ppgu::PresetManager    presets;
    ppgu::LibraryManager   libraries;
    ppgu::MidiLearn        midiLearn;

    std::atomic<float> cpuPercent { 0.0f };
    std::atomic<int>   currentArticulation { 0 }; // 0 open, 1 muted, 2 flageolet, 3 tremolo
    juce::String lastLibraryLog;

    void applyPreset(const ppgu::Preset& p);

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    void handleMidi(const juce::MidiBuffer& midi);
    std::atomic<bool> panicRequested { false };
    juce::UndoManager undo;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PpguAudioProcessor)
};
