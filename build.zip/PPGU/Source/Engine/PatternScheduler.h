#pragma once
#include <JuceHeader.h>
#include <vector>
#include <functional>
#include "ChordDetector.h"
#include "StyleEngine.h"

namespace ppgu {

// Фраза = записанное исполнение (1/2/4 такта), события в 16-х долях.
struct PhraseEvent
{
    int step = 0;        // индекс 16-й доли внутри фразы
    int degree = 0;      // 0 корень, 1 терция, 2 квинта, 3 септима, 4 октава
    float vel = 0.8f;
    int artic = 0;       // 0 open, 1 muted, 3 tremolo, 4 skank(высокий открытый)
    bool strum = false;  // аккорд целиком (веер)
};

struct Phrase { int bars = 1; std::vector<PhraseEvent> events; };

// Встроенный банк фраз: 8 слотов, стиль поп-панк
class PhraseBank
{
public:
    static const Phrase& slot(int idx); // 0..7
    static const char* slotName(int idx);
};

class PatternScheduler
{
public:
    void prepare(double sampleRate, int blockSize);
    void setStyle(const Style& s) { style = s; }

    // Смена аккорда квантуется к ближайшей 1/16 — ловушка №11 чек-листа
    void requestChordChange(const Chord& c);

    void setSlot(int slotIndex) { activeSlot = juce::jlimit(0, 7, slotIndex); }
    int  getSlot() const { return activeSlot; }

    // Превью: один такт, отдельный путь (PreviewBus) — не трогает транспорт
    void previewSlot(int slotIndex);

    void setSwing(float s01)      { swing = juce::jlimit(0.0f, 0.6f, s01); }
    void setHumanize(float h01)   { humanize = juce::jlimit(0.0f, 1.0f, h01); }
    void setAccent(float a01)     { accent = juce::jlimit(0.0f, 1.0f, a01); }

    // Движок вперёд на numSamples; колбэк вызывает trigger по событиям
    void advance(int numSamples, bool playing, double bpm, const ChordDetector& chords,
                 std::function<void(int artic, float vel, float freq, float pan)> trigger);

    int pendingCount() const { return (int) pending.size(); }

private:
    struct Pending { int offset; PhraseEvent ev; };
    Style style;
    Chord currentChord, nextChord;
    bool hasNext = false;
    int samplesToNextSixteenth = 0;
    int phraseStep = 0;
    int activeSlot = 0;
    float swing = 0.0f, humanize = 0.0f, accent = 0.0f;
    double sampleRate = 48000.0;
    std::vector<Pending> pending;
};

} // namespace ppgu
