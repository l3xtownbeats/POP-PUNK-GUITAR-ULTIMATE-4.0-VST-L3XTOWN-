#pragma once
#include <JuceHeader.h>
#include <vector>

namespace ppgu {

struct LibraryEntry
{
    juce::String name;
    juce::String path;
    juce::String format;  // "wav-folder" | "ppgb"
    bool active = false;
    int sampleCount = 0;
};

// Менеджер библиотек: добавление (фоновое сканирование), список, активность, сохранение user-библиотек.
class LibraryManager
{
public:
    void addLibrary(const juce::File& dirOrPpgb, juce::String& log);
    void removeLibrary(int index);
    juce::Array<LibraryEntry> list() const { return entries; }

    juce::File userLibrariesDir() const;
    bool saveUserManifest(juce::String& error);
    bool loadUserManifest(juce::String& error);

private:
    juce::Array<LibraryEntry> entries;
};

} // namespace ppgu
