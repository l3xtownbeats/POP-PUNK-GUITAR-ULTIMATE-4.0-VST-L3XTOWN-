#pragma once
namespace ppgu {
// MIDI-карта канонического промта (Часть 13.2)
constexpr int kArtOpen      = 36; // C1
constexpr int kArtMuted     = 37; // C#1 palm-mute
constexpr int kArtFlageolet = 38; // D1
constexpr int kArtTremolo   = 39; // D#1
constexpr int kPatSlot1     = 40; // E1 .. G1 (8 слотов: 40..47 зарезервировано ниже)
constexpr int kPatSlotHi    = 42; // G1
constexpr int kEndShort     = 44; // G#1
constexpr int kEndMid       = 45; // A1
constexpr int kEndLong      = 46; // Bb1
constexpr int kSlideMod     = 47; // B1
constexpr int kCcAllSoundOff = 120;
constexpr int kCcResetAll    = 123;
constexpr int kCcSyncOffset  = 111;
constexpr int kCcAccent      = 11;
constexpr int kPitchBend     = 224; // channel 1
} // namespace ppgu
