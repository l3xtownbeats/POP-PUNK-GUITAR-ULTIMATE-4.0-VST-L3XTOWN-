#include "LibraryManager.h"

namespace ppgu {

void LibraryManager::addLibrary(const juce::File& dirOrPpgb, juce::String& log)
{
    if (!dirOrPpgb.exists()) { log = "Path not found: " + dirOrPpgb.getFullPathName(); return; }
    LibraryEntry e;
    e.name = dirOrPpgb.getFileNameWithoutExtension();
    e.path = dirOrPpgb.getFullPathName();
    e.format = dirOrPpgb.isDirectory() && dirOrPpgb.getFileName().endsWithIgnoreCase(".ppgb")
               ? juce::String("ppgb") : juce::String("wav-folder");

    juce::Array<juce::File> files;
    dirOrPpgb.findChildFiles(files, juce::File::findFiles, true, "*.wav");
    e.sampleCount = files.size();
    e.active = true;
    if (e.sampleCount == 0) { log = "No WAV samples in library: " + e.path; return; }
    entries.add(e);
    log = juce::String("Library added: ") + e.name + " (" + e.sampleCount + " samples)";
}

void LibraryManager::removeLibrary(int index)
{
    if (index >= 0 && index < entries.size()) entries.remove(index);
}

juce::File LibraryManager::userLibrariesDir() const
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
           .getChildFile("PPGU").getChildFile("Libraries");
}

bool LibraryManager::saveUserManifest(juce::String& error)
{
    auto dir = userLibrariesDir();
    if (!dir.createDirectory().wasOk()) { error = "Cannot create " + dir.getFullPathName(); return false; }
    juce::var arr = juce::var(juce::Array<juce::var>());
    for (auto& e : entries)
    {
        auto o = juce::DynamicObject::create();
        o->setProperty("name", e.name); o->setProperty("path", e.path);
        o->setProperty("format", e.format); o->setProperty("active", e.active);
        arr.getArray()->add(o.get());
    }
    auto ok = juce::JSON::writeToFile(arr, dir.getChildFile("libraries.json"));
    if (!ok) error = "Cannot write libraries.json";
    return ok;
}

bool LibraryManager::loadUserManifest(juce::String& error)
{
    auto f = userLibrariesDir().getChildFile("libraries.json");
    if (!f.existsAsFile()) return true; // первая установка — не ошибка
    auto parsed = juce::JSON::parse(f);
    auto* arr = parsed.getArray();
    if (arr == nullptr) { error = "libraries.json corrupted"; return false; }
    entries.clear();
    for (auto& v : *arr)
    {
        LibraryEntry e;
        e.name = v.getProperty("name", "").toString();
        e.path = v.getProperty("path", "").toString();
        e.format = v.getProperty("format", "wav-folder").toString();
        e.active = (bool) v.getProperty("active", true);
        if (juce::File(e.path).exists()) entries.add(e);
    }
    return true;
}

} // namespace ppgu
