#pragma once
#include <JuceHeader.h>

namespace ppgu {

// Style DNA: живость тайминга/velocity, перекраска фраз по пресету.
struct Style
{
    float timingOffsetMs = 0.0f; // сдвиг тайминга фразы
    float velScale      = 1.0f;  // масштаб velocity
    float velVar        = 0.10f; // случайная вариация
    float humanize      = 0.0f;  // доля оригинального тайминга записи
};

class StyleEngine
{
public:
    void setStyle(const Style& s) { style = s; }
    const Style& getStyle() const { return style; }

    // Кэшируемый расчёт: смещение и velocity для события (детерминированно от seed события)
    int   timingSamples(int stepIndex, double sampleRate) const;
    float velocityOf(float baseVel, int stepIndex) const;

private:
    static float hash01(int seed) { auto x = (juce::uint32) (seed * 2654435761u); x ^= x >> 16; x *= 2654435761u; x ^= x >> 16; return (x & 0xffffff) / 16777215.0f; }
    Style style;
};

} // namespace ppgu
