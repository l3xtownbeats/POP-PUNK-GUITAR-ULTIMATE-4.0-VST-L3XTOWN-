#include "StyleEngine.h"

namespace ppgu {

int StyleEngine::timingSamples(int stepIndex, double sampleRate) const
{
    // humanize: 0% = полная квантизация, 100% = оригинал записи; между — пропорционально
    float jitterMs = (hash01(stepIndex * 7 + 13) - 0.5f) * (2.0f + 18.0f * style.humanize);
    return (int) (sampleRate * (style.timingOffsetMs + jitterMs) / 1000.0);
}

float StyleEngine::velocityOf(float baseVel, int stepIndex) const
{
    float v = baseVel * style.velScale;
    v += (hash01(stepIndex * 31 + 7) - 0.5f) * 2.0f * style.velVar;
    return juce::jlimit(0.05f, 1.0f, v);
}

} // namespace ppgu
