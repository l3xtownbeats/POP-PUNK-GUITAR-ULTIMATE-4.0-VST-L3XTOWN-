#pragma once
#include <JuceHeader.h>
#include <map>

class MidiLearn
{
public:
    void beginLearn(const juce::String& paramId) { learnTarget = paramId; }
    void cancelLearn() { learnTarget.clear(); }
    bool isLearning() const { return learnTarget.isNotEmpty(); }

    // Возвращает paramId, если CC назначен
    juce::String onController(int cc)
    {
        if (isLearning()) { mapping[(juce::uint8) cc] = learnTarget; learnTarget.clear(); return mapping[(juce::uint8) cc]; }
        auto it = mapping.find((juce::uint8) cc);
        return it != mapping.end() ? it->second : juce::String();
    }

    const std::map<juce::uint8, juce::String>& getMap() const { return mapping; }

private:
    juce::String learnTarget;
    std::map<juce::uint8, juce::String> mapping;
};
