#pragma once
#include <JuceHeader.h>
#include "SamplePool.h"
#include "GuitarVoice.h"

namespace ppgu {

class VoiceManager
{
public:
    void prepare(double sr, int blockSize);
    void trigger(int artic, float velocity01, float targetFreq, float pan, float gain = 1.0f);
    void panic(); // CC120/CC123: fade-out всех голосов, не срез
    void render(juce::AudioBuffer<float>& out);
    int activeCount() const;

private:
    static constexpr int kMaxVoices = 16;
    GuitarVoice voices[kMaxVoices];
    SamplePool* pool = nullptr; // статически установлен в конструкторе процессора
    double sampleRate = 48000.0;
    int oldest = 0;
};

} // namespace ppgu
