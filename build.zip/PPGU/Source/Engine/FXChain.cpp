#include "FXChain.h"

namespace ppgu {

void FXChain::prepare(double sr, int maxBlock, int channels)
{
    spec = { sr, (juce::uint32) maxBlock, (juce::uint32) channels };
    chain.get<1>().setRatio(3.0f);
    chain.get<1>().setAttack(5.0f);
    chain.get<1>().setRelease(120.0f);
    chain.get<2>().setRateHz(0.8f);
    chain.get<2>().setDepth(0.35f);
    chain.get<3>().setMaximumDelayInSamples((int) (sr * 1.5) + 1);
    chain.get<4>().getParameters().roomSize = 0.45f;
    chain.get<5>().coefficients = juce::dsp::IIR::Coefficients<float>::makeLowPass(sr, 6000.0f);
    chain.prepare(spec);
    prepared = true;
}

void FXChain::setParams(float driveAmt, float compAmt, float chorusAmt, float delayMix,
                        float delayTimeSec, float reverbMix, float toneHz, float masterDb)
{
    const float driveGain = 1.0f + 6.0f * driveAmt;
    chain.get<0>().setFunction([driveGain](float x) { return std::tanh(x * driveGain); });
    chain.get<1>().setThreshold(juce::jmap(juce::jlimit(0.0f, 1.0f, compAmt), 0.0f, -24.0f));
    chain.get<2>().setMix(chorusAmt);
    chain.get<3>().setMix(delayMix);
    chain.get<3>().setDelay((int) juce::jlimit(1.0f,
        (float) chain.get<3>().getMaximumDelayInSamples() - 1.0f,
        (float) spec.sampleRate * juce::jlimit(0.01f, 1.2f, delayTimeSec)));
    auto rp = chain.get<4>().getParameters();
    rp.wetLevel = reverbMix; rp.dryLevel = 1.0f - 0.4f * reverbMix;
    chain.get<4>().setParameters(rp);
    chain.get<5>().coefficients = juce::dsp::IIR::Coefficients<float>::makeLowPass(
        spec.sampleRate, juce::jlimit(1200.0f, 12000.0f, toneHz));
    chain.get<6>().setGainDecibels(masterDb);
}

void FXChain::process(juce::AudioBuffer<float>& buffer)
{
    if (!prepared) return;
    juce::dsp::AudioBlock<float> block(buffer);
    juce::dsp::ProcessContextReplacing<float> ctx(block);
    chain.process(ctx);
}

} // namespace ppgu
