#include "GuitarVoice.h"
#include <cmath>

namespace ppgu {

static inline float hermite(float p0, float p1, float p2, float p3, float t)
{
    const float c0 = p1, c1 = 0.5f * (p2 - p0), c2 = p0 - 2.5f * p1 + 2.0f * p2 - 0.5f * p3,
                c3 = 0.5f * (p3 - p0) + 1.5f * (p1 - p2);
    return ((c3 * t + c2) * t + c1) * t + c0;
}

void GuitarVoice::start(const SampleLayer* l, float vel, float targetFreq, float pl, float pr, float g)
{
    if (l == nullptr || l->data == nullptr || l->length <= 0) return;
    layer = l;
    rate = targetFreq > 1.0f ? (double) (targetFreq / l->baseFreq) : 1.0;
    rate = juce::jlimit(0.25, 4.0, rate);
    pos = 0.0;
    gain = g * juce::jmap(juce::jlimit(0.0f, 1.0f, vel), 0.25f, 1.0f);
    panL = pl; panR = pr;
    fadeInLeft = fadeIn = (int) (0.010 * sampleRate); // атака 10 мс — защита от клика
    releasing = false; active = true;
}

void GuitarVoice::release(float fadeSeconds)
{
    releasing = true;
    relCountdown = (int) juce::jmax(1.0f, fadeSeconds * (float) sampleRate);
}

void GuitarVoice::render(juce::AudioBuffer<float>& out, int start, int n)
{
    if (!active || layer == nullptr) return;
    auto* L = out.getWritePointer(0);
    auto* R = out.getNumChannels() > 1 ? out.getWritePointer(1) : nullptr;
    const auto* data = layer->data;
    const int len = layer->length;
    const float lg = gain * layer->gain;

    for (int i = 0; i < n; ++i)
    {
        if (pos >= (double) len - 4.0) { active = false; break; }

        float env = 1.0f;
        if (fadeInLeft > 0) { env = 1.0f - (float) fadeInLeft / (float) fadeIn; --fadeInLeft; }

        if (releasing)
        {
            env *= (float) relCountdown / juce::jmax(1.0f, 0.02f * (float) sampleRate);
            if (--relCountdown <= 0) { active = false; break; }
        }

        if (vibDepth > 0.0f)
        {
            vibPhase += 2.0f * juce::MathConstants<float>::pi * 5.5f / (float) sampleRate;
            pos += (double) (vibDepth * 0.3f * std::sin(vibPhase));
        }

        const int ip = (int) pos;
        const float t = (float) (pos - (double) ip);
        const float p0 = ip > 0 ? data[ip - 1] : data[ip];
        const float p1 = data[ip], p2 = data[ip + 1 < len ? ip + 1 : len - 1], p3 = data[ip + 2 < len ? ip + 2 : len - 1];
        const float s = hermite(p0, p1, p2, p3, t) * env * lg;

        L[start + i] += s * panL;
        if (R != nullptr) R[start + i] += s * panR;

        pos += rate;
    }
}

} // namespace ppgu
