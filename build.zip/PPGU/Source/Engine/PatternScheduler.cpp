#include "PatternScheduler.h"
#include <cmath>

namespace ppgu {

// --- Встроенный банк фраз (16-е доли; 1 такт = 16 шагов) ---
static const Phrase makePhrase(const std::vector<PhraseEvent>& evs, int bars = 1)
{
    Phrase p; p.bars = bars; p.events = evs; return p;
}

static const std::vector<Phrase> kPhrases = {
    // 0: Palm-mute 8th (классический чаг)
    makePhrase({ {0,0,0.95f,1}, {2,0,0.75f,1}, {4,0,0.9f,1}, {6,0,0.75f,1},
                 {8,0,0.95f,1}, {10,0,0.75f,1}, {12,0,0.9f,1}, {14,0,0.75f,1} }),
    // 1: Power-chord ритм на 1/8 с ударом
    makePhrase({ {0,0,1.0f,0,true}, {2,0,0.7f,0}, {4,0,0.9f,0,true}, {6,0,0.7f,0},
                 {8,0,1.0f,0,true}, {10,0,0.7f,0}, {12,0,0.9f,0,true}, {14,0,0.75f,0} }),
    // 2: Double-time
    makePhrase({ {0,0,0.95f,1}, {1,0,0.6f,1}, {2,0,0.7f,1}, {3,0,0.6f,1}, {4,0,0.9f,1},
                 {6,0,0.7f,1}, {8,0,0.95f,1}, {9,0,0.6f,1}, {10,0,0.7f,1}, {12,0,0.9f,1}, {14,0,0.7f,1} }),
    // 3: Skank (выкл-такты)
    makePhrase({ {2,0,0.85f,4}, {6,0,0.85f,4}, {10,0,0.85f,4}, {14,0,0.85f,4} }),
    // 4: Octave riff
    makePhrase({ {0,0,1.0f,0}, {3,4,0.8f,0}, {6,0,0.9f,0}, {9,4,0.8f,0}, {12,0,0.95f,0} }),
    // 5: Half-time, акцент на 1 и 3
    makePhrase({ {0,0,1.0f,0,true}, {8,0,0.95f,0,true}, {12,2,0.7f,0} }),
    // 6: Chug-berst 16th
    makePhrase({ {0,0,0.95f,1}, {1,0,0.6f,1}, {2,0,0.65f,1}, {3,0,0.6f,1},
                 {4,0,0.9f,1}, {5,0,0.6f,1}, {6,0,0.65f,1}, {8,0,0.95f,1},
                 {10,0,0.7f,1}, {12,0,0.9f,1}, {14,0,0.7f,1} }),
    // 7: Открытый струм 2 такта
    makePhrase({ {0,0,1.0f,0,true}, {6,2,0.8f,0}, {8,0,0.9f,0,true}, {14,1,0.75f,0},
                 {16,0,1.0f,0,true}, {22,2,0.8f,0}, {24,0,0.9f,0,true}, {30,1,0.75f,0} }, 2)
};

const Phrase& PhraseBank::slot(int idx)
{
    static const auto bank = [] {
        std::vector<Phrase> v; for (auto& p : kPhrases) v.push_back(p); return v; }();
    return bank[(size_t) juce::jlimit(0, (int) bank.size() - 1, idx)];
}

const char* PhraseBank::slotName(int idx)
{
    static const char* names[] = { "Palm-Mute 8th", "Power Rhythm", "Double-Time", "Skank",
                                   "Octave Riff", "Half-Time", "Chug Burst", "Open Strum" };
    return names[juce::jlimit(0, 7, idx)];
}

void PatternScheduler::prepare(double sr, int)
{
    sampleRate = sr;
    samplesToNextSixteenth = 0;
    phraseStep = 0;
    pending.clear();
}

void PatternScheduler::requestChordChange(const Chord& c)
{
    nextChord = c; hasNext = true; // применится на ближайшей 1/16
}

void PatternScheduler::previewSlot(int slotIndex) { activeSlot = juce::jlimit(0, 7, slotIndex); }

void PatternScheduler::advance(int n, bool playing, double bpm, const ChordDetector& chords,
                               std::function<void(int, float, float, float)> trigger)
{
    if (!playing || bpm <= 1.0) return;

    const double samplesPerSixteenth = sampleRate * 60.0 / bpm / 4.0;

    // Квантованная смена аккорда: на границе 1/16
    if (hasNext && samplesToNextSixteenth <= 0) { currentChord = nextChord; hasNext = false; }

    // Квантование к следующей 1/16
    while (samplesToNextSixteenth <= 0)
        samplesToNextSixteenth += (int) samplesPerSixteenth;

    samplesToNextSixteenth -= n;
    if (samplesToNextSixteenth > 0) return;

    // Дошли до границы 1/16: берём события текущего шага
    const auto& phrase = PhraseBank::slot(activeSlot);
    const int stepsPerBar = 16, totalSteps = phrase.bars * stepsPerBar;
    const int step = phraseStep % totalSteps;

    for (const auto& ev : phrase.events)
    {
        if (ev.step != step) continue;

        const Chord& c = chords.current();
        if (!c.valid) continue;

        float toneFreqs[5] = { 0, 0, 0, 0, 0 };
        toneFreqs[0] = 440.0f * std::pow(2.0f, (c.root - 69) / 12.0f);
        toneFreqs[1] = 440.0f * std::pow(2.0f, (c.third - 69) / 12.0f);
        toneFreqs[2] = 440.0f * std::pow(2.0f, (c.fifth - 69) / 12.0f);
        toneFreqs[3] = c.seventh >= 0 ? 440.0f * std::pow(2.0f, (c.seventh - 69) / 12.0f) : toneFreqs[0];
        toneFreqs[4] = toneFreqs[0] * 2.0f;

        const float vel = juce::jlimit(0.05f, 1.0f, ev.vel * (0.7f + 0.3f * accent));
        if (ev.strum)
        {
            // Веер: корень → терция → квинта с микро-задержкой (порядок струн)
            trigger(ev.artic, vel * 0.9f, toneFreqs[0], 0.8f);
            trigger(ev.artic, vel * 0.8f, toneFreqs[1], 0.5f);
            trigger(ev.artic, vel * 0.85f, toneFreqs[2], 0.2f);
        }
        else
        {
            trigger(ev.artic, vel, toneFreqs[juce::jlimit(0, 4, ev.degree)], 0.5f);
        }
    }

    ++phraseStep;
}

} // namespace ppgu
