#include "ChordDetector.h"
#include <cmath>

namespace ppgu {

int noteNameToMidi(const juce::String& name)
{
    static const juce::String notes[] = { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };
    for (int n = 0; n < 12; ++n)
        if (name.startsWith(notes[n]))
            return ((name.substring(notes[n].length()).getIntValue()) + 1) * 12 + n;
    return -1;
}

const Chord& ChordDetector::current()
{
    if (!dirty) return chord;
    dirty = false;
    chord = Chord{};

    if (held.empty()) return chord;

    // Корень — самая нижняя нота (в реальном детекторе — распознавание по интервальной совокупности)
    int low = *held.begin();
    for (int n : held) low = juce::jmin(low, n);

    int pc = ((low % 12) + 12) % 12;
    auto hasPc = [&](int p) { return held.count(p) > 0; };

    // Строим тоны по имеющимся нотам: интервалы от корня
    chord.root = low;
    bool minor = hasPc((pc + 3) % 12) && !hasPc((pc + 4) % 12);
    chord.third  = low + (minor ? 3 : 4);
    chord.fifth  = low + 7;
    if (hasPc((pc + 10) % 12)) chord.seventh = low + 10;      // минорная септима
    else if (hasPc((pc + 11) % 12)) chord.seventh = low + 11; // мажорная септима
    if (hasPc((pc + 6) % 12))  chord.fifth = low + 6;         // b5
    if (hasPc((pc + 8) % 12))  chord.fifth = low + 8;         // #5

    // Слэш: если самая низкая нота — не корень по наличию более глубокой ноты вне терцового стека
    int bassCandidate = *held.begin();
    int rel = ((bassCandidate - pc) % 12 + 12) % 12;
    if (rel != 0)
        chord.slashBass = bassCandidate;

    chord.valid = true;
    return chord;
}

} // namespace ppgu
