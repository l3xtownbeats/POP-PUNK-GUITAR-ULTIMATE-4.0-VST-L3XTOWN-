#pragma once
#include <JuceHeader.h>
#include <vector>

namespace ppgu {

// Распознавание аккордов со слэшами: C/E, Dmi7/F, Ami/E — Часть 7 промта.
struct Chord
{
    int root = 0;                 // MIDI нота тоники (в октаве контекста)
    int third = 0, fifth = 0, seventh = -1;
    int slashBass = -1;           // бас != корень
    bool valid = false;
};

class ChordDetector
{
public:
    void noteOn(int midiNote)  { held.insert(midiNote); dirty = true; }
    void noteOff(int midiNote) { held.erase(midiNote); dirty = true; }
    void clear()               { held.clear(); dirty = true; }

    const Chord& current(); // пересчитывает при dirty

private:
    std::set<int> held;
    Chord chord;
    bool dirty = true;
};

// Название ноты → MIDI ("E2" → 40)
int noteNameToMidi(const juce::String& name);

} // namespace ppgu
