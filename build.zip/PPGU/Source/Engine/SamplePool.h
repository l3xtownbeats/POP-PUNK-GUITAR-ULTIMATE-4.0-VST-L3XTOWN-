#pragma once
#include <JuceHeader.h>
#include <vector>

namespace ppgu {

struct SampleLayer
{
    const float* data = nullptr;   // моно; стерео берём канал L
    int length = 0;
    float velLo = 0.0f, velHi = 1.0f;
    float gain = 1.0f;
    float baseFreq = 82.41f;       // базовая высота записи (E2)
};

// Единый интерфейс источников сэмплов: аудиодвижок не знает, откуда данные
// (WAV-папка или .ppgb-контейнер) — Часть 11 промта.
class SamplePool
{
public:
    static constexpr int kNumArticulations = 6; // open, muted, flageolet, tremolo, HO/PO, noise
    enum Artic { AOpen = 0, AMuted, AFlageolet, ATremolo, AHoPo, ANoise };

    void prepare(double sampleRate);
    void loadWavFolder(const juce::File& dir, juce::String& log);
    void loadPpgb(const juce::File& manifestFile, juce::String& log);

    // RR без повторов вариаций: счётчик общий на артикуляцию
    const SampleLayer* pick(int artic, float velocity) const;

    bool hasLibrary() const { return !layersByArt[AOpen].empty(); }

private:
    void addLayer(int artic, juce::AudioBuffer<float>&& buf, float velLo, float velHi, float baseFreq);
    void buildFallback(); // синтетические заглушки: плагин звучит и без библиотеки

    juce::AudioFormatManager formats;
    std::vector<juce::AudioBuffer<float>> owned;       // владение данными
    std::vector<std::vector<SampleLayer>> layersByArt { kNumArticulations };
    mutable std::array<int, kNumArticulations> rrCounter {};
    double sampleRate = 48000.0;
};

} // namespace ppgu
