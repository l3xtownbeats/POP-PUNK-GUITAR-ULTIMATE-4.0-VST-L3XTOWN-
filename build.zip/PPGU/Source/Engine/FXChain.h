#pragma once
#include <JuceHeader.h>
#include <juce_dsp/juce_dsp.h>

namespace ppgu {

// Фиксированная цепочка: Drive → Comp → Chorus → Delay → Reverb (+ Tone lowpass, Master gain)
class FXChain
{
public:
    void prepare(double sampleRate, int maxBlock, int channels);
    void process(juce::AudioBuffer<float>& buffer);
    void setParams(float driveAmt, float compAmt, float chorusAmt, float delayMix,
                   float delayTimeSec, float reverbMix, float toneHz, float masterDb);

private:
    juce::dsp::ProcessorChain<
        juce::dsp::WaveShaper<float>,
        juce::dsp::ProcessorDuplicator<juce::dsp::Compressor<float>, juce::dsp::IIR::Coefficients<float>>,
        juce::dsp::Chorus<float>,
        juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear>,
        juce::dsp::Reverb<float>,
        juce::dsp::IIR::Filter<float>,
        juce::dsp::Gain<float>
    > chain;
    juce::dsp::ProcessSpec spec {};
    bool prepared = false;
};

} // namespace ppgu
