#include "SamplePool.h"
#include <cmath>

namespace ppgu {

void SamplePool::prepare(double sr)
{
    sampleRate = sr > 8000.0 ? sr : 48000.0;
    formats.registerBasicFormats();
    if (!hasLibrary()) buildFallback();
}

void SamplePool::buildFallback()
{
    // Синтетический "чаг": атака 10 мс, экспоненциальный спад.
    // Цель — 100 ударов разной velocity без единого клика (критерий М2).
    const int artCount[kNumArticulations] = { 2, 2, 1, 1, 1, 1 };
    for (int art = 0; art < kNumArticulations; ++art)
    {
        for (int variant = 0; variant < artCount[art]; ++variant)
        {
            const double dur = (art == ANoise) ? 0.12 : 1.6;
            const int len = (int) (dur * sampleRate);
            juce::AudioBuffer<float> buf(1, len);
            auto* d = buf.getWritePointer(0);
            const double attack = 0.010 * sampleRate;
            const double decay = (art == AMuted) ? 0.18 : 1.1;
            for (int i = 0; i < len; ++i)
            {
                double t = i / sampleRate;
                double env = i < attack ? (i / attack) : std::exp(-t / decay);
                double ph = 2.0 * juce::MathConstants<double>::pi * 110.0 * t;
                double s = std::sin(ph) + 0.5 * std::sin(2.0 * ph) + 0.25 * std::sin(3.0 * ph);
                if (art == ATremolo)
                    s *= (0.7 + 0.3 * std::sin(2.0 * juce::MathConstants<double>::pi * 18.0 * t));
                d[i] = (float) juce::jlimit(-1.0, 1.0, s * 0.4 * env);
            }
            addLayer(art, std::move(buf), variant * 0.5f, 1.0f, 82.41f);
        }
    }
}

void SamplePool::addLayer(int artic, juce::AudioBuffer<float>&& buf, float velLo, float velHi, float baseFreq)
{
    owned.push_back(std::move(buf));
    SampleLayer l;
    l.data = owned.back().getReadPointer(0);
    l.length = owned.back().getNumSamples();
    l.velLo = velLo; l.velHi = velHi;
    l.baseFreq = baseFreq;
    layersByArt[(size_t) artic].push_back(l);
}

static int parseArtFromName(const juce::String& stem)
{
    const juce::String s = stem.toLowerCase();
    if (s.contains("mute") || s.contains("chug"))      return SamplePool::AMuted;
    if (s.contains("flag") || s.contains("harm"))      return SamplePool::AFlageolet;
    if (s.contains("trem"))                            return SamplePool::ATremolo;
    if (s.contains("ho") || s.contains("po"))          return SamplePool::AHoPo;
    if (s.contains("noise") || s.contains("fret"))     return SamplePool::ANoise;
    return SamplePool::AOpen;
}

static float baseFreqFromName(const juce::String& stem)
{
    // Ищем токен вида "E2", "Ab3" и т.п.
    auto parts = juce::StringArray::fromTokens(stem, "_", "");
    static const juce::String notes[] = { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };
    for (auto& p : parts)
    {
        for (int n = 0; n < 12; ++n)
        {
            if (p.startsWith(notes[n]))
            {
                int octave = p.substring(notes[n].length()).getIntValue();
                int midi = (octave + 1) * 12 + n;
                if (midi >= 0 && midi <= 127)
                    return (float) (440.0 * std::pow(2.0, (midi - 69) / 12.0));
            }
        }
    }
    return 82.41f;
}

void SamplePool::loadWavFolder(const juce::File& dir, juce::String& log)
{
    if (!dir.isDirectory()) { log = "Folder not found: " + dir.getFullPathName(); return; }
    juce::Array<juce::File> files;
    dir.findChildFiles(files, juce::File::findFiles, true, "*.wav;*.wave");
    if (files.isEmpty()) { log = "No WAV files in " + dir.getFullPathName(); return; }

    juce::AudioFormat* wav = formats.findFormatForFileExtension("wav");
    if (wav == nullptr) { log = "WAV format unavailable"; return; }

    int added = 0;
    for (auto& f : files)
    {
        std::unique_ptr<juce::AudioFormatReader> r(wav->createReaderFor(f));
        if (r == nullptr) continue;
        juce::AudioBuffer<float> buf(1, (int) r->lengthInSamples);
        r->read(&buf, 0, (int) r->lengthInSamples, 0, true, false);

        const auto stem = f.getFileNameWithoutExtension();
        // Соглашение имён: "<высота>_<артикуляция>_v<NN>_rr<NN>", напр. "E2_muted_v03_rr01"
        addLayer(parseArtFromName(stem), std::move(buf), 0.0f, 1.0f, baseFreqFromName(stem));
        ++added;
    }
    log = juce::String("Loaded ") + juce::String(added) + " samples from " + dir.getFullPathName();
}

void SamplePool::loadPpgb(const juce::File& manifestFile, juce::String& log)
{
    // .ppgb = папка-контейнер: manifest.json + WAV. Упаковка zstd — опция этапа М2+.
    if (!manifestFile.isDirectory()) { log = "Not a .ppgb folder: " + manifestFile.getFullPathName(); return; }
    loadWavFolder(manifestFile, log);
}

const SampleLayer* SamplePool::pick(int artic, float velocity) const
{
    if (artic < 0 || artic >= kNumArticulations) return nullptr;
    auto& layers = layersByArt[(size_t) artic];
    if (layers.empty()) return nullptr;

    // RR без повторов: счётчик всегда двигается вперёд (никогда не повторяет вариацию дважды подряд)
    int idx = rrCounter[(size_t) artic]++;
    auto* chosen = &layers[(size_t) (idx % (int) layers.size())];

    for (auto& l : layers)
        if (velocity >= l.velLo && velocity <= l.velHi) { chosen = &l; break; }
    return chosen;
}

} // namespace ppgu
