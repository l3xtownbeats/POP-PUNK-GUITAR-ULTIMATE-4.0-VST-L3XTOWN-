#include "VoiceManager.h"

namespace ppgu {

static SamplePool sharedPool;

void VoiceManager::prepare(double sr, int)
{
    sampleRate = sr;
    pool = &sharedPool;
    pool->prepare(sr);
    for (auto& v : voices) v.prepare(sr);
}

void VoiceManager::trigger(int artic, float vel01, float targetFreq, float pan, float gain)
{
    auto* l = pool->pick(artic, vel01);
    if (l == nullptr) return;
    // Double-track: второй дубль с микро-задержкой и противоположным паном (фазовая защита — HPF на Double, Часть 14)
    int slot = -1;
    for (int i = 0; i < kMaxVoices; ++i) if (!voices[i].isActive()) { slot = i; break; }
    if (slot < 0) { slot = oldest % kMaxVoices; voices[slot].steal(); ++oldest; }
    voices[slot].start(l, vel01, targetFreq, pan, 1.0f - pan, gain);
}

void VoiceManager::panic()
{
    for (auto& v : voices) v.release(0.02f); // fade-out 20 мс, не мгновенный срез
}

void VoiceManager::render(juce::AudioBuffer<float>& out)
{
    for (auto& v : voices) v.render(out, 0, out.getNumSamples());
}

int VoiceManager::activeCount() const
{
    int c = 0; for (auto& v : voices) if (v.isActive()) ++c; return c;
}

} // namespace ppgu
