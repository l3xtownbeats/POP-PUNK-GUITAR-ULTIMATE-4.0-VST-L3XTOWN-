#pragma once
#include <JuceHeader.h>
#include "SamplePool.h"

namespace ppgu {

// Один голос: Hermite-интерполяция, атака 10 мс, release-хвост с fade-out (ловушка №1 и №6 чек-листа).
class GuitarVoice
{
public:
    void prepare(double sr) { sampleRate = sr; }
    bool isActive() const { return active; }

    void start(const SampleLayer* layer, float velocityNorm, float targetFreq, float panL, float panR, float gain);
    void release(float fadeSeconds = 0.02f);
    void steal() { releasing = true; relCountdown = (int) (0.01 * sampleRate); } // 10 мс fade-out
    void setVibrato(float depthNorm) { vibDepth = depthNorm; }
    void render(juce::AudioBuffer<float>& out, int startSample, int numSamples);

private:
    bool active = false, releasing = false;
    const SampleLayer* layer = nullptr;
    double pos = 0.0, rate = 1.0, sampleRate = 48000.0;
    float gain = 1.0f, panL = 0.7f, panR = 0.7f, vibPhase = 0.0f, vibDepth = 0.0f;
    int fadeIn = 0, fadeInLeft = 0, relCountdown = 0;
};

} // namespace ppgu
