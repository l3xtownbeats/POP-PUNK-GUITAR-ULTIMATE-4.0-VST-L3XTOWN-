#include "PresetManager.h"

namespace ppgu {

bool PresetManager::loadFromJson(const juce::String& jsonText, juce::String& error)
{
    auto parsed = juce::JSON::parse(jsonText);
    auto* arr = parsed.getArray();
    if (arr == nullptr) { error = "presets.json: ожидается массив"; return false; }

    presets.clear();
    for (auto& v : *arr)
    {
        Preset p;
        p.id    = v.getProperty("id", "").toString();
        p.name  = v.getProperty("name", "").toString();
        p.group = v.getProperty("group", "").toString();
        p.ref   = v.getProperty("ref", "").toString();
        p.level = (int) v.getProperty("level", 1);
        if (auto* prm = v.getProperty("params", {}).getDynamicObject())
            for (auto& kv : prm->getProperties()) p.params[kv.name.toString()] = (float) (double) kv.value;
        auto st = v.getProperty("style", {});
        p.timingMs = (float) (double) st.getProperty("timingMs", 0.0);
        p.velScale = (float) (double) st.getProperty("velScale", 1.0);
        p.velVar   = (float) (double) st.getProperty("velVar", 0.1);
        if (p.name.isNotEmpty()) presets.push_back(std::move(p));
    }

    if (presets.size() < 300)
    {
        error = juce::String("Валидатор пресетов: найдено ") + presets.size()
                + " < 300 — веха М7 не принимается";
        return false;
    }
    selected = presets.size() > 0 ? 0 : -1;
    return true;
}

const Preset* PresetManager::preset(int index) const
{
    return index >= 0 && index < (int) presets.size() ? &presets[(size_t) index] : nullptr;
}

juce::StringArray PresetManager::names() const
{
    juce::StringArray a;
    for (auto& p : presets) a.add(p.name + "  [" + p.group + "]");
    return a;
}

juce::StringArray PresetManager::groupNames() const
{
    juce::StringArray a;
    for (auto& p : presets) if (!a.contains(p.group)) a.add(p.group);
    return a;
}

void PresetManager::select(int index)
{
    if (auto* p = preset(index))
    {
        selected = index;
        if (listener) listener(*p);
    }
}

} // namespace ppgu
