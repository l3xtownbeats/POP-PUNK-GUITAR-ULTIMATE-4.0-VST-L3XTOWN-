#pragma once
#include <JuceHeader.h>
#include "PatternScheduler.h"

namespace ppgu {

// Экспорт текущего паттерна в .mid для Drag & Drop из плагина в Channel Rack FL.
bool exportPhraseToMidiFile(const ppgu::Phrase& phrase, const ppgu::Chord& chord,
                            double bpm, const juce::File& target);

} // namespace ppgu
