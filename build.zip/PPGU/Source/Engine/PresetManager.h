#pragma once
#include <JuceHeader.h>

namespace ppgu {

struct Preset
{
    juce::String id, name, group, ref;
    int level = 1;
    std::map<juce::String, float> params;
    float timingMs = 0.0f, velScale = 1.0f, velVar = 0.1f;
};

class PresetManager
{
public:
    bool loadFromJson(const juce::String& jsonText, juce::String& error);

    int size() const { return (int) presets.size(); }
    const Preset* preset(int index) const;
    juce::StringArray names() const;
    juce::StringArray groupNames() const;

    void select(int index); // внутри уведомляет слушателя
    int  selectedIndex() const { return selected; }
    void onChange(std::function<void(const Preset&)> cb) { listener = std::move(cb); }

private:
    std::vector<Preset> presets;
    int selected = -1;
    std::function<void(const Preset&)> listener;
};

} // namespace ppgu
