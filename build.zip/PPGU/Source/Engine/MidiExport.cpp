#include "MidiExport.h"
#include <cmath>

namespace ppgu {

bool exportPhraseToMidiFile(const Phrase& phrase, const Chord& chord, double bpm, const juce::File& target)
{
    if (!chord.valid) return false;
    juce::MidiMessageSequence seq;
    const double tickPerSixteenth = 120.0; // 480 PPQ / 4

    for (const auto& ev : phrase.events)
    {
        const double tick = ev.step * tickPerSixteenth;
        int pitch = chord.root;
        if (ev.degree == 1) pitch = chord.third;
        else if (ev.degree == 2) pitch = chord.fifth;
        else if (ev.degree == 3 && chord.seventh >= 0) pitch = chord.seventh;
        else if (ev.degree == 4) pitch = chord.root + 12;
        pitch = juce::jlimit(0, 127, pitch);

        const int vel = juce::jlimit(1, 127, (int) (ev.vel * 127.0f));
        seq.addEvent(juce::MidiMessage::noteOn(1, pitch, (juce::uint8) vel).withTimeStamp(tick));
        seq.addEvent(juce::MidiMessage::noteOff(1, pitch).withTimeStamp(tick + tickPerSixteenth * 0.9));
    }
    seq.sort();

    juce::MidiFile mf;
    mf.setTicksPerQuarterNote(480);
    mf.addTrack(seq);

    juce::FileOutputStream out(target);
    if (!out.openedOk()) return false;
    return mf.writeToStream(out), true;
}

} // namespace ppgu
