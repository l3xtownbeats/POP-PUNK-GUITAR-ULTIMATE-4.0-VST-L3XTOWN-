#include "PluginEditor.h"
#include "Engine/MidiExport.h"
#include "Engine/PatternScheduler.h"

PpguAudioProcessorEditor::PpguAudioProcessorEditor(PpguAudioProcessor& p)
    : AudioProcessorEditor(p), proc(p)
{
    setSize(720, 460);

    presetBox.onChange = [this] { proc.presets.select(presetBox.getSelectedItemIndex()); };
    presetBox.setTextWhenNothingSelected("PRESETS");
    for (auto& n : proc.presets.names()) presetBox.addItem(n, presetBox.getNumItems() + 1);
    addAndMakeVisible(presetBox);

    auto wireMode = [this](juce::TextButton& b, int mode)
    {
        b.setClickingTogglesState(true);
        b.onClick = [this, &b, mode]
        {
            if (auto* r = proc.apvts.getRawParameterValue("mode")) r->store((float) mode);
            modeMelody.setToggleState(mode == 0, juce::dontSendNotification);
            modePattern.setToggleState(mode == 1, juce::dontSendNotification);
        };
        addAndMakeVisible(b);
    };
    wireMode(modeMelody, 0); wireMode(modePattern, 1);
    modeMelody.setToggleState(true, juce::dontSendNotification);

    auto attach = [&](juce::Slider& s, const juce::String& id, juce::Label** lbl, const char* name)
    {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        atts.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc.apvts, id, s));
        addAndMakeVisible(s);
        auto* l = new juce::Label(name, name); l->setJustificationType(juce::Justification::centred);
        l->setColour(juce::Label::textColourId, juce::Colours::white);
        addAndMakeVisible(l); *lbl = l;
        l->setSize(60, 14);
    };
    attach(sTone,   "tone",   nullptr, "TONE");
    attach(sDrive,  "drive",  nullptr, "DRIVE");
    attach(sComp,   "comp",   nullptr, "COMP");
    attach(sChorus, "chorus", nullptr, "CHORUS");
    attach(sDelay,  "delayMix", nullptr, "DELAY");
    attach(sReverb, "reverb", nullptr, "REVERB");
    attach(sSwing,  "swing",  nullptr, "SWING");
    attach(sHuman,  "humanize", nullptr, "HUMAN");
    attach(sAccent, "accent", nullptr, "ACCENT");

    for (int i = 0; i < 8; ++i)
    {
        auto& b = slotButtons[i];
        b.setButtonText(juce::String(i + 1));
        b.onClick = [this, i] { proc.scheduler.setSlot(i); };
        addAndMakeVisible(b);
    }
    slotLabel.setText("PATTERN SLOTS", juce::dontSendNotification);
    slotLabel.setJustificationType(juce::Justification::centred);
    slotLabel.setColour(juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible(slotLabel);

    cpuLabel.setText("CPU 0%", juce::dontSendNotification);
    cpuLabel.setColour(juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible(cpuLabel);
    startTimerHz(4);
}

void PpguAudioProcessorEditor::timerCallback()  // нужен juce::Timer — см. ниже в классе
{
    cpuLabel.setText(juce::String("CPU ") + (int) proc.cpuPercent.load() + juce::String("%"), juce::dontSendNotification);
}

void PpguAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff1a1a20));
    g.setColour(magenta);
    g.fillRect(0, 0, getWidth(), 44);
    g.setColour(juce::Colours::white);
    g.setFont(20.0f);
    g.drawText("POP PUNK GUITAR UNIT", 14, 0, 300, 44, juce::Justification::centredLeft);

    auto drawBlock = [&](juce::Rectangle<int> r, const char* title)
    {
        g.setColour(juce::Colour(0xff24242c));
        g.fillRect(r);
        g.setColour(juce::Colours::white);
        g.setFont(14.0f);
        g.drawText(title, r.reduced(6), juce::Justification::topLeft);
    };
    drawBlock({ 8, 52, 704, 110 }, "AMP & TONE");
    drawBlock({ 8, 170, 340, 150 }, "FX CHAIN");
    drawBlock({ 360, 170, 352, 150 }, "PLAYBACK");
}

void PpguAudioProcessorEditor::resized()
{
    presetBox.setBounds(8, 52, 240, 24);
    modeMelody.setBounds(260, 52, 90, 24);
    modePattern.setBounds(356, 52, 90, 24);
    cpuLabel.setBounds(620, 52, 80, 24);

    auto* sliders[] = { &sTone, &sDrive, &sComp };
    for (int i = 0; i < 3; ++i) sliders[i]->setBounds(40 + i * 110, 78, 70, 70);

    auto* fxSliders[] = { &sChorus, &sDelay, &sReverb };
    for (int i = 0; i < 3; ++i) fxSliders[i]->setBounds(40 + i * 100, 196, 70, 70);

    auto* pbSliders[] = { &sSwing, &sHuman, &sAccent };
    for (int i = 0; i < 3; ++i) pbSliders[i]->setBounds(400 + i * 105, 196, 70, 70);

    slotLabel.setBounds(8, 330, 200, 20);
    for (int i = 0; i < 8; ++i) slotButtons[i].setBounds(10 + i * 46, 356, 40, 26);
}

void PpguAudioProcessorEditor::filesDropped(const juce::StringArray& files, int, int)
{
    // Drag & Drop MIDI в плагин: импорт .mid → паттерн текущего слота (Часть 13.4)
    for (auto& f : files)
    {
        juce::File file(f);
        if (file.getFileExtension().equalsIgnoreCase(".mid"))
        {
            juce::FileInputStream in(file);
            juce::MidiFile mf; mf.readFrom(in);
            DBG("MIDI imported: " << file.getFileName() << " tracks=" << mf.getNumTracks());
            // конвертация в Phrase: TODO Часть 13.4 (аккорды по нижней ноте, стиль по ритму)
        }
    }
}
