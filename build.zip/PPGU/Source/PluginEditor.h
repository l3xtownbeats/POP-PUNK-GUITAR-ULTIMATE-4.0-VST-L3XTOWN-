#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class PpguAudioProcessorEditor : public juce::AudioProcessorEditor,
                                 private juce::Timer,
                                 private juce::FileDragAndDropTarget
{
public:
    explicit PpguAudioProcessorEditor(PpguAudioProcessor&);
    ~PpguAudioProcessorEditor() override = default;

    void paint(juce::Graphics&) override;
    void timerCallback() override;
    void resized() override;

private:
    bool isInterestedInFileDrag(const juce::StringArray&) override { return true; }
    void filesDropped(const juce::StringArray&, int, int) override;

    PpguAudioProcessor& proc;
    juce::ComboBox presetBox;
    juce::TextButton modeMelody { "MELODY" }, modePattern { "PATTERN" };
    juce::Slider sTone, sDrive, sComp, sChorus, sDelay, sReverb, sSwing, sHuman, sAccent;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> atts;
    juce::Label cpuLabel, slotLabel;
    juce::TextButton slotButtons[8];

    juce::Colour magenta { 0xffff2d78 };
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PpguAudioProcessorEditor)
};
