#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "Engine/MidiMap.h"
#include <cmath>

PpguAudioProcessor::PpguAudioProcessor()
    : AudioProcessor(BusesProperties()
        .withOutput("Output", juce::AudioChannelSet::stereo(), true))
    , apvts(*this, &undo, "PPGU", createLayout())
{
    juce::String err;
    const auto json = juce::String::createFromUTF8(PresetData::presets_json, (int) strlen(PresetData::presets_json));
    if (!presets.loadFromJson(json, err))
        DBG("Preset validation: " << err); // валидатор обязан вывести число >= 300

    presets.onChange([this](const ppgu::Preset& p) { applyPreset(p); });

    scheduler.setStyle(style.getStyle());
    scheduler.prepare(48000.0, 512);
    voices.prepare(48000.0, 512);
    libraries.loadUserManifest(lastLibraryLog);
}

juce::AudioProcessorValueTreeState::ParameterLayout PpguAudioProcessor::createLayout()
{
    using P = juce::AudioParameterFloat; using PB = juce::AudioParameterBool;
    using PC = juce::AudioParameterChoice; using PI = juce::AudioParameterInt;
    juce::AudioProcessorValueTreeState::ParameterLayout l;
    l.add(std::make_unique<P>("gain",  "Gain",   juce::NormalisableRange<float>(-24.0f, 12.0f, 0.1f), 0.0f));
    l.add(std::make_unique<P>("tone",  "Tone",   juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),    0.6f));
    l.add(std::make_unique<P>("bright","Brightness", juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.5f));
    l.add(std::make_unique<P>("drive", "Drive",  juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),    0.3f));
    l.add(std::make_unique<P>("comp",  "Comp",   juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),    0.3f));
    l.add(std::make_unique<P>("chorus","Chorus", juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),    0.0f));
    l.add(std::make_unique<P>("delayMix","Delay Mix", juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.0f));
    l.add(std::make_unique<P>("delayTime","Delay Time", juce::NormalisableRange<float>(0.01f, 1.2f, 0.01f), 0.3f));
    l.add(std::make_unique<P>("reverb","Reverb", juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),    0.2f));
    l.add(std::make_unique<PC>("mode", "Mode", juce::StringArray { "Melody", "Pattern" }, 0));
    l.add(std::make_unique<P>("swing", "Swing", juce::NormalisableRange<float>(0.0f, 0.6f, 0.01f), 0.0f));
    l.add(std::make_unique<P>("humanize","Humanize", juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.3f));
    l.add(std::make_unique<P>("accent","Accent", juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.5f));
    l.add(std::make_unique<PB>("doubleTrack","Double Track", false));
    l.add(std::make_unique<P>("width", "Width", juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.7f));
    l.add(std::make_unique<PI>("presetIndex","Preset", 0, 999, 0));
    l.add(std::make_unique<PI>("patternSlot","Pattern Slot", -1, 7, 0));
    return l;
}

void PpguAudioProcessor::prepareToPlay(double sr, int block)
{
    voices.prepare(sr, block);
    scheduler.prepare(sr, block);
    fx.prepare(sr, block, getTotalNumOutputChannels());
}

bool PpguAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
        || layouts.getMainOutputChannelSet() == juce::AudioChannelSet::mono();
}

void PpguAudioProcessor::applyPreset(const ppgu::Preset& p)
{
    auto set = [&](const char* id, float v) { if (auto* r = apvts.getRawParameterValue(id)) r->store(v); };
    for (auto& kv : p.params) set(kv.first.toRawUTF8(), kv.second);
    set("presetIndex", (float) presets.selectedIndex());

    ppgu::Style s;
    s.timingOffsetMs = p.timingMs; s.velScale = p.velScale; s.velVar = p.velVar;
    s.humanize = *apvts.getRawParameterValue("humanize");
    style.setStyle(s);
    scheduler.setStyle(s);
}

void PpguAudioProcessor::handleMidi(const juce::MidiBuffer& midi)
{
    const int mode = (int) *apvts.getRawParameterValue("mode");
    for (const auto md : midi)
    {
        const auto m = md.getMessage();

        if (m.isController() && (m.getControllerNumber() == ppgu::kCcAllSoundOff
                              || m.getControllerNumber() == ppgu::kCcResetAll))
        { panicRequested = true; continue; }

        if (m.isController() && m.getControllerNumber() == ppgu::kCcSyncOffset) continue; // глобальный offset: TODO Часть 13.3

        // MIDI-learn: назначение CC параметру
        if (m.isController() && midiLearn.isLearning())
        { auto id = midiLearn.onController(m.getControllerNumber()); if (id.isNotEmpty()) DBG("Learned CC" << m.getControllerNumber() << " -> " << id); continue; }

        if (m.isNoteOn())
        {
            const int note = m.getNoteNumber();
            const float vel = (float) m.getVelocity() / 127.0f;
            const float accent = *apvts.getRawParameterValue("accent");

            if (mode == 0) // Melody: выбор артикуляции кейсвитчами C1..D#1, HO/PO, лад-шум
            {
                if (note >= ppgu::kArtOpen && note <= ppgu::kArtTremolo) continue; // кейсвитчи артикуляций, не ноты
                int art = ppgu::SamplePool::AOpen;
                switch (currentArticulation.load())
                {
                    case 1: art = ppgu::SamplePool::AMuted; break;
                    case 2: art = ppgu::SamplePool::AFlageolet; break;
                    case 3: art = ppgu::SamplePool::ATremolo; break;
                    default: break;
                }
                const float freq = 440.0f * std::pow(2.0f, (note - 69) / 12.0f);
                voices.trigger(art, juce::jmax(vel, 0.05f), freq, 0.5f, 1.0f);
                chords.noteOn(note);
            }
            else // Pattern: нота = аккорд (каждая нота = аккорд, Часть 7 промта)
            {
                if (note >= ppgu::kPatSlot1 && note <= ppgu::kPatSlotHi)
                { scheduler.setSlot(note - ppgu::kPatSlot1); continue; } // выбор слота
                if (note >= ppgu::kEndShort && note <= ppgu::kEndLong) continue; // концовки: TODO Часть 7
                chords.noteOn(note); // каждое нажатие — аккорд
            }
        }
        else if (m.isNoteOff())
        {
            chords.noteOff(m.getNoteNumber());
        }
        else if (m.isPitchWheel())
        {
            // Питч-бенд по типам (All/Lowest/Highest/Softest/Loudest/Latest): здесь Latest
            const float semis = (m.getPitchWheelValue() - 8192) / 8192.0f * 2.0f;
            DBG("Pitch bend: " << semis); // применение к голосам — Часть 9
        }
    }
}

void PpguAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals; // FTZ/DAZ: подавление денормалов — Часть 19
    auto t0 = juce::Time::getHighResolutionTicks();
    const int n = buffer.getNumSamples();
    buffer.clear();

    handleMidi(midi);
    if (panicRequested.exchange(false)) voices.panic();

    const bool playing = getPlayHead() != nullptr
        && getPlayHead()->getPosition() != nullptr
        && getPlayHead()->getPosition()->getIsPlaying();

    double bpm = 120.0;
    if (auto pos = getPlayHead() ? getPlayHead()->getPosition() : nullptr)
        if (auto b = pos->getBpm()) bpm = *b;

    const float accent = *apvts.getRawParameterValue("accent");
    const float humanize = *apvts.getRawParameterValue("humanize");
    const float swing = *apvts.getRawParameterValue("swing");
    scheduler.setAccent(accent); scheduler.setHumanize(humanize); scheduler.setSwing(swing);

    scheduler.advance(n, playing, bpm, chords,
        [this](int art, float vel, float freq, float pan) { voices.trigger(art, vel, freq, pan); });

    voices.render(buffer);

    fx.setParams(*apvts.getRawParameterValue("drive"), *apvts.getRawParameterValue("comp"),
                 *apvts.getRawParameterValue("chorus"), *apvts.getRawParameterValue("delayMix"),
                 *apvts.getRawParameterValue("delayTime"), *apvts.getRawParameterValue("reverb"),
                 juce::jmap(*apvts.getRawParameterValue("tone"), 1200.0f, 12000.0f),
                 *apvts.getRawParameterValue("gain"));

    const float width = *apvts.getRawParameterValue("width");
    if (*apvts.getRawParameterValue("doubleTrack") > 0.5f && buffer.getNumChannels() > 1)
    {
        auto* L = buffer.getWritePointer(0); auto* R = buffer.getWritePointer(1);
        for (int i = n - 1; i > 7; --i) R[i] = L[i - 8] * (0.5f + 0.5f * width); // микро-дубль
    }

    const auto elapsed = juce::Time::highResolutionTicksToSeconds(juce::Time::getHighResolutionTicks() - t0);
    const double blockSec = (double) n / std::max(1.0, getSampleRate());
    const float cpu = (float) juce::jlimit(0.0, 1.0, elapsed / std::max(1e-9, blockSec));
    cpuPercent.store(cpuPercent.load() * 0.9f + cpu * 100.0f * 0.1f);
}

juce::AudioProcessorEditor* PpguAudioProcessor::createEditor()
{ return new PpguAudioProcessorEditor(*this); }

void PpguAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary(*xml, dest);
}

void PpguAudioProcessor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

