# PPGU — сборка

## Требования
- Windows 10+, CMake 3.22+, Visual Studio 2022 (Desktop development with C++).
- JUCE 7: `git clone --depth 1 https://github.com/juce-framework/JUCE.git` в папку `PPGU/JUCE`.

## Сборка
```
cd PPGU
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```
VST3 копируется в %APPDATA%\VST3 автоматически (COPY_PLUGIN_AFTER_BUILD).
Standalone-версия — в build/PPGU_artefacts/Release/Standalone.

## Headless-тест
```
PPGU_HeadlessTest.exe
```
Ожидается: `100 hits, clicks=0 -> PASS`.

## Библиотеки звуков
- Формат на выбор: папка WAV или .ppgb-контейнер (папка с manifest.json и WAV).
- Имена файлов: `<высота>_<артикуляция>_v<NN>_rr<NN>.wav`, напр. `E2_muted_v03_rr01.wav`.
- Редактирование и сохранение: user-манифест в %APPDATA%\PPGU\Libraries.

## Пресеты
- Source/Resources/presets.json: 390 пресетов (240 уровня 1 + 150 уровня 2).
- Валидатор требует >= 300, иначе М7 не принимается.

## Цикл исправления ошибок
Любые ошибки сборки/запуска: см. docs/SELF_REPAIR_LOOP.md — исправляются итеративно до работоспособности.
