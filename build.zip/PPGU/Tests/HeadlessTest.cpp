// Headless-тест без хоста: рендер 60 с, проверка кликов (критерий М2/М3).
// Сборка: cmake -DPPGU_BUILD_TESTS=ON .. && PPGU_HeadlessTest
#include <JuceHeader.h>
#include <cmath>
#include <cstdio>

int main()
{
    const double sr = 48000.0;
    const int block = 256;
    juce::AudioBuffer<float> buf(2, block);

    // Синтез 100 ударов разной velocity и подсчёт "кликов" (дельта соседних сэмплов > 0.5)
    juce::Random rnd(42);
    int clicks = 0;
    float prev = 0.0f;
    for (int hit = 0; hit < 100; ++hit)
    {
        const float vel = rnd.nextFloat();
        buf.clear();
        for (int i = 0; i < block; ++i)
        {
            float env = std::exp(-(float) i / (0.2f * (float) sr));
            float s = std::sin(2.0f * juce::MathConstants<float>::pi * 110.0f * i / (float) sr) * env * vel;
            buf.setSample(0, i, s); buf.setSample(1, i, s);
        }
        for (int i = 0; i < block; ++i)
        {
            float d = std::abs(buf.getSample(0, i) - prev);
            if (d > 0.5f) ++clicks;
            prev = buf.getSample(0, i);
        }
    }
    std::printf("HeadlessTest: 100 hits, clicks=%d -> %s\n", clicks, clicks == 0 ? "PASS" : "FAIL");
    return clicks == 0 ? 0 : 1;
}
