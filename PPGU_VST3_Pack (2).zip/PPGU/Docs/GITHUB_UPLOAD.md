# Загрузка PPGU на GitHub — 3 минуты

1. Создай репозиторий Public с именем ppgu-library.
2. Загрузи все папки: Presets/, Samples/, Guitar_Library/, Tools/, Docs/.
3. Добавь README.md (уже есть) — описание и инструкции.
4. Опционально: создай GitHub Release -> загрузи PPGU_VST3_Pack.zip как asset
   -> получится прямая ссылка "скачать одной кнопкой".
5. Raw-ссылки на JSON (ChatGPT может читать их напрямую):
   https://raw.githubusercontent.com/<USER>/ppgu-library/main/Presets/Tone_Palettes.json

LICENSES.md обязательно держи в корне — так потребители видят правовой статус.
