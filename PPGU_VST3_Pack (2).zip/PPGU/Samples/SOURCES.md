# PPGU SOURCES — Каталог легальных источников сэмплов (Pop-Punk Guitar)

## GitHub — прямые ZIP (без авторизации)
| Источник | Что внутри | Лицензия | Ссылка |
|---|---|---|---|
| FreePats e-guitar FSBS direct | Fender DI: clean/distorted/direct | CC0 | https://github.com/freepats/e-guitar-FSBS-direct/archive/refs/heads/master.zip |
| Karoryfer Black & Green Guitars | 2 полуакустики (Gretsch, Hofner), SFZ | CC0-1.0 | https://github.com/sfzinstruments/karoryfer.black-and-green-guitars/archive/refs/heads/main.zip |
| lotkey free-sample-libraries-sfz | Baritone Strat DI + SFZ (palm mute по velocity) | проверить в репо | https://github.com/lotkey/free-sample-libraries-sfz/archive/refs/heads/main.zip |
| Каталог SFZ гитар | обзор всех открытых библиотек | разное | https://sfzinstruments.github.io/guitars/ |

## Freesound (API, нужен бесплатный токен: https://freesound.org/apiv2/apply/)
| Pack | Содержимое | Ссылка |
|---|---|---|
| Chem #1995 | Дисторшн ESP EC-300: power chords long/short + palm mute, 96kHz | https://freesound.org/people/Chem/packs/1995/ |
| Ax_Grinder #14939 | Power chords Drop D: open + palm-muted | https://freesound.org/people/Ax_Grinder/packs/14939/ |
| Поиск CC0 | query: guitar power chord distorted / palm muted guitar / clean electric guitar / crunch guitar / acoustic guitar raw | https://freesound.org/apiv2/search/text/?query=guitar+power+chord&filter=license:%22Creative%20Commons%200%22 |

## Лупы и MIDI
| Источник | Что внутри | Ссылка |
|---|---|---|
| Looperman | гитарные лупы (free WAV) | https://www.looperman.com/loops/tags/free-guitar-loops-samples-sounds-wavs-download |
| Selekt Audio | free MIDI рифы (CC0/CC-BY) | https://selektaudio.com/free-midi/guitar |
| Splice Mike Naran | Pop Punk Riffs, 65 семплов (нужен аккаунт) | https://splice.com/sounds/packs/signal-path/mike-naran-pop-punk-riffs/samples |

## Референс-библиотеки (учёба, НЕ для коммерции)
| Источник | Что внутри | Лицензия |
|---|---|---|
| Unreal Standard Guitar | 716 МБ, ~2400 семплов | Custom — только прослушивание |
| Unreal Metal GTX | 1.3 ГБ | Custom — только прослушивание |

## Флейнджер/хорус/кранч — это НЕ отдельные сэмплы
Это DSP-обработка поверх DI-слоёв из наших пресетов (см. Presets/Tone_Palettes.json).
Библиотека даёт сухие слои; пресеты красят — как в Sunburst Deluxe.
