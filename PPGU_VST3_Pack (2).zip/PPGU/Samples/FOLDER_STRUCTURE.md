# Структура папок библиотеки (совпадает с маппингом движка)

```
PPGU_SampleLibrary/
├── 01_Acoustic_Raw/          # сырая акустика, без обработки
├── 02_DI_Clean/              # чистая DI электрогитара
│   ├── BR/  NK/  MIC/        # 3 канала записи
│   └── RR/                   # round-robin вариации
├── 03_Distortion_PowerChords/# пауэр-аккорды с дисторшном
├── 04_PalmMute/              # PM по velocity: 0-32 medium, 33-63 hard
├── 05_Crunch/                # кранч-слой
├── 06_Octaves/               # октавные ходы
├── 07_Leads/                 # бенды, вибрато, соло
├── 08_Release_Noises/        # release-шумы струн, скрипы
├── 09_Loops/                 # лупы
├── 10_MIDI_Patterns/         # .mid скелеты паттернов
├── LICENSES.md
└── SFZ/                      # готовые .sfz маппинги
```
