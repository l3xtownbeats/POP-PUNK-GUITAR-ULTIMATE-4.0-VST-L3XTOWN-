#!/usr/bin/env python3
"""
PPGU Build Library — автосборщик библиотеки сэмплов поп-панк гитары.
Запуск: python3 ppgu_build_library.py --token FREESOUND_TOKEN
        python3 ppgu_build_library.py --github-only
"""
import argparse, json, os, shutil, sys, tempfile, urllib.request, zipfile

FOLDER_MAP = [
    ("04_PalmMute", ["pm","palm","mute"]),
    ("03_Distortion_PowerChords", ["power_chord","powerchord","distort","drop d"]),
    ("06_Octaves", ["octave"]),
    ("02_DI_Clean", ["clean","direct","di"]),
    ("05_Crunch", ["crunch","overdrive"]),
    ("07_Leads", ["lead","solo","bend","squeal"]),
    ("01_Acoustic_Raw", ["acoustic","nylon"]),
    ("10_MIDI_Patterns", [".mid"]),
    ("08_Release_Noises", ["release","noise","squeak","scratch"]),
]
GITHUB_SOURCES = [
    ("FreePats_FSBS_Direct", "https://github.com/freepats/e-guitar-FSBS-direct/archive/refs/heads/master.zip", "CC0"),
    ("Karoryfer_BlackAndGreen", "https://github.com/sfzinstruments/karoryfer.black-and-green-guitars/archive/refs/heads/main.zip", "CC0-1.0"),
    ("lotkey_free_sfz", "https://github.com/lotkey/free-sample-libraries-sfz/archive/refs/heads/main.zip", "LICENSE-CHECK-REQUIRED"),
]
FREESOUND_PACKS = [("Chem1995", 1995), ("AxGrinder14939", 14939)]
FREESOUND_QUERIES = ["guitar power chord distorted", "palm muted guitar",
                     "clean electric guitar", "crunch guitar", "acoustic guitar raw"]
FREESOUND_FILTER = 'license:"Creative Commons 0"'

def classify(name):
    n = name.lower()
    for cat, keys in FOLDER_MAP:
        if any(k in n for k in keys):
            return cat
    return "09_Loops"

def download(url, dest):
    print(f"  ↓ {url}")
    try:
        urllib.request.urlretrieve(url, dest)
        return True
    except Exception as e:
        print(f"  ✗ пропущен: {e}")
        return False

def unzip(zpath, outdir, prefix):
    with zipfile.ZipFile(zpath) as z:
        for m in z.namelist():
            if m.endswith((".wav",".flac",".mid",".sfz",".md",".txt",".json")):
                parts = m.split("/", 1)
                rel = parts[1] if len(parts) > 1 else parts[0]
                if not rel or rel.startswith("."): continue
                target = os.path.join(outdir, classify(rel))
                os.makedirs(target, exist_ok=True)
                with z.open(m) as src, open(os.path.join(target, os.path.basename(rel)), "wb") as dst:
                    shutil.copyfileobj(src, dst)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--token", default=os.environ.get("FREESOUND_TOKEN",""))
    ap.add_argument("--github-only", action="store_true")
    args = ap.parse_args()
    out = "PPGU_SampleLibrary"
    if os.path.exists(out): shutil.rmtree(out)
    for cat, _ in FOLDER_MAP + [("09_Loops",[])]:
        os.makedirs(f"{out}/{cat}", exist_ok=True)
    licenses = ["# PPGU Sample Library — Licenses\n"]
    tmp = tempfile.mkdtemp()
    print("== GitHub sources ==")
    for name, url, lic in GITHUB_SOURCES:
        z = os.path.join(tmp, f"{name}.zip")
        if download(url, z):
            unzip(z, out, name)
            licenses.append(f"- {name}: {lic} ({url})")
    if not args.github_only and args.token:
        print("== Freesound API ==")
        for name, pid in FREESOUND_PACKS:
            url = f"https://freesound.org/apiv2/packs/{pid}/sounds/?token={args.token}"
            try:
                data = json.loads(urllib.request.urlopen(url).read())
                for item in data.get("results", []):
                    sid = item["id"]
                    dl = f"https://freesound.org/apiv2/sounds/{sid}/download/?token={args.token}"
                    fn = os.path.join(tmp, f"fs_{sid}")
                    if download(dl, fn):
                        cat = classify(item.get("name","sound"))
                        dst = os.path.join(out, cat, f"fs_{sid}.wav")
                        shutil.copy(fn, dst)
                licenses.append(f"- Freesound pack {pid}: per-sound CC licenses, see freesound.org")
            except Exception as e:
                print(f"  ✗ pack {pid}: {e}")
        for q in FREESOUND_QUERIES:
            try:
                uq = urllib.parse.quote(q)
                url = f"https://freesound.org/apiv2/search/text/?query={uq}&filter={urllib.parse.quote(FREESOUND_FILTER)}&token={args.token}"
                data = json.loads(urllib.request.urlopen(url).read())
                print(f"  найдено {len(data.get('results',[]))} по: {q}")
            except Exception as e:
                print(f"  ✗ поиск {q}: {e}")
    else:
        print("== Freesound пропущен (нет токена). Получить: https://freesound.org/apiv2/apply/ ==")
    open(f"{out}/LICENSES.md","w").write("\n".join(licenses))
    zipname = "PPGU_SampleLibrary.zip"
    print(f"== Упаковка {zipname} ==")
    with zipfile.ZipFile(zipname, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fn in os.walk(out):
            for f in fn:
                full = os.path.join(dp, f)
                z.write(full, os.path.relpath(full, os.path.dirname(out) or "."))
    print(f"ГОТОВО: {zipname}")

import urllib.parse
if __name__ == "__main__":
    main()
