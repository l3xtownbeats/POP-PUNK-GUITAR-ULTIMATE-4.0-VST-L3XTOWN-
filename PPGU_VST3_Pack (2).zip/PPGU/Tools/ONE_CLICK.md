# PPGU — сборка библиотеки одной кнопкой

## Вариант A — локально (python3)
```
python3 Tools/ppgu_build_library.py --token ТВОЙ_КЛЮЧ_FREESOUND
python3 Tools/ppgu_build_library.py --github-only   # без токена
```
Результат: PPGU_SampleLibrary.zip — готовая библиотека по категориям.

## Вариант B — через ChatGPT
1. Открой Tools/GPT_PROMPT.txt, скопируй целиком в ChatGPT.
2. ChatGPT скачает всё сам, разложит по папкам и отдаст архив.

## Вариант C — GitHub (одна кнопка для любого человека)
1. Создай репозиторий: https://github.com/new (имя ppgu-library, Public).
2. Code -> Add file -> Upload files — перетащи всю папку PPGU.
3. На странице репо: Code -> Download ZIP — это кнопка "скачать одной кнопкой".
4. Raw-ссылки на пресеты: https://raw.githubusercontent.com/ИМЯ/ppgu-library/main/Presets/...
